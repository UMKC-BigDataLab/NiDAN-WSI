Using Spark's default log4j profile: org/apache/spark/log4j-defaults.properties
Setting default log level to "WARN".
To adjust logging level use sc.setLogLevel(newLevel).
17/06/10 07:22:48 WARN NativeCodeLoader: Unable to load native-hadoop library for your platform... using builtin-java classes where applicable
17/06/10 07:22:51 WARN SparkContext: Use an existing SparkContext, some configuration may not take effect.
Spark context Web UI available at http://128.110.152.156:4040
Spark context available as 'sc' (master = spark://ctl:7077, app id = app-20170610072250-0063).
Spark session available as 'spark'.
Welcome to
      ____              __
     / __/__  ___ _____/ /__
    _\ \/ _ \/ _ `/ __/  '_/
   /___/ .__/\_,_/_/ /_/\_\   version 2.0.2
      /_/
         
Using Scala version 2.11.8 (OpenJDK 64-Bit Server VM, Java 1.8.0_131)
Type in expressions to have them evaluated.
Type :help for more information.

scala>  
     | import java.io.File
import java.io.File

scala> import java.io.FileOutputStream
import java.io.FileOutputStream

scala> import org.apache.spark.sql._
import org.apache.spark.sql._

scala> 

scala> def show_timing[T](proc: => T): T = {
     |     val start=System.nanoTime()
     |     val res = proc
     |     val end = System.nanoTime()
     |     println("Time elapsed: " + (end-start)/1000000000.0 + " seconds")
     |     res
     | }
show_timing: [T](proc: => T)T

scala> 

scala> val writeToLocal = (in:(Array[Byte], Long, String)) =>{
     |     val bytes = in._1
     |     val output = in._3
     |     
     |     val writer = new FileOutputStream(output)
     |     writer.write(bytes)
     |     writer.close
     |     1
     |   }
writeToLocal: ((Array[Byte], Long, String)) => Int = <function1>

scala> 

scala> val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)
warning: there was one deprecation warning; re-run with -deprecation for details
sqlContext: org.apache.spark.sql.hive.HiveContext = org.apache.spark.sql.hive.HiveContext@5fde1d64

scala>   
     | val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 195  OR  partitionIndex = 210  OR   partitionIndex = 211  OR  partitionIndex = 224  OR  partitionIndex = 225  OR  partitionIndex = 226  OR  partitionIn dex = 240  OR  partitionIndex = 241 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 195  OR  partitionIndex = 210  OR  partitionIndex = 211  OR  partitionIndex = 224  OR  partitionIndex = 225  OR  partitionIndex = 226  OR  partitionIndex = 240  OR  partitionIndex = 241 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 15.558743919 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 0:>                                                        (0 + 64) / 64][Stage 0:==============================================>         (53 + 11) / 64][Stage 0:=======================================================> (62 + 2) / 64][Stage 0:========================================================>(63 + 1) / 64]                                                                                [Stage 1:=======================================================> (63 + 2) / 65][Stage 1:========================================================>(64 + 1) / 65]                                                                                Time elapsed: 22.733570603 seconds
res3: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 32  OR  partitionIndex = 33  OR  pa rtitionIndex = 34  OR  partitionIndex = 35  OR  partitionIndex = 48  OR  partitionIndex = 49  OR  partitionIndex =  50  OR  partitionIndex = 51 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 32  OR  partitionIndex = 33  OR  partitionIndex = 34  OR  partitionIndex = 35  OR  partitionIndex = 48  OR  partitionIndex = 49  OR  partitionIndex = 50  OR  partitionIndex = 51 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.126421386 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 2:======================================================>  (61 + 3) / 64][Stage 2:========================================================>(63 + 1) / 64]                                                                                [Stage 3:========================================================>(64 + 1) / 65]                                                                                Time elapsed: 14.397343178 seconds
res5: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 127  OR  partitionIndex = 128  OR   partitionIndex = 129  OR  partitionIndex = 130  OR  partitionIndex = 131  OR  partitionIndex = 144  OR  partitionIn dex = 145  OR  partitionIndex = 146 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 127  OR  partitionIndex = 128  OR  partitionIndex = 129  OR  partitionIndex = 130  OR  partitionIndex = 131  OR  partitionIndex = 144  OR  partitionIndex = 145  OR  partitionIndex = 146 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.121710258 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 4:========================================================>(63 + 1) / 64]                                                                                [Stage 5:========================================================>(64 + 1) / 65]                                                                                Time elapsed: 22.544070795 seconds
res7: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 222  OR  partitionIndex = 223  OR   partitionIndex = 236  OR  partitionIndex = 237  OR  partitionIndex = 238  OR  partitionIndex = 239  OR  partitionIn dex = 252  OR  partitionIndex = 253 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 222  OR  partitionIndex = 223  OR  partitionIndex = 236  OR  partitionIndex = 237  OR  partitionIndex = 238  OR  partitionIndex = 239  OR  partitionIndex = 252  OR  partitionIndex = 253 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.122708221 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 6:========================================================>(63 + 1) / 64]                                                                                [Stage 7:========================================================>(64 + 1) / 65]                                                                                Time elapsed: 18.12128307 seconds
res9: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 86  OR  partitionIndex = 87  OR  pa rtitionIndex = 100  OR  partitionIndex = 101  OR  partitionIndex = 102  OR  partitionIndex = 103  OR  partitionInde x = 116  OR  partitionIndex = 117 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 86  OR  partitionIndex = 87  OR  partitionIndex = 100  OR  partitionIndex = 101  OR  partitionIndex = 102  OR  partitionIndex = 103  OR  partitionIndex = 116  OR  partitionIndex = 117 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.109627165 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 8:=======================================================> (62 + 2) / 64][Stage 8:========================================================>(63 + 1) / 64]                                                                                [Stage 9:=======================================================> (63 + 2) / 65][Stage 9:========================================================>(64 + 1) / 65]                                                                                Time elapsed: 18.911509641 seconds
res11: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 62  OR  partitionIndex = 63  OR  pa rtitionIndex = 72  OR  partitionIndex = 73  OR  partitionIndex = 74  OR  partitionIndex = 75  OR  partitionIndex =  88  OR  partitionIndex = 89 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 62  OR  partitionIndex = 63  OR  partitionIndex = 72  OR  partitionIndex = 73  OR  partitionIndex = 74  OR  partitionIndex = 75  OR  partitionIndex = 88  OR  partitionIndex = 89 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.110178666 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 10:=======================================================>(63 + 1) / 64]                                                                                [Stage 11:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 11.696054603 seconds
res13: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 132  OR  partitionIndex = 133  OR   partitionIndex = 134  OR  partitionIndex = 148  OR  partitionIndex = 149  OR  partitionIndex = 163  OR  partitionIn dex = 178  OR  partitionIndex = 179 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 132  OR  partitionIndex = 133  OR  partitionIndex = 134  OR  partitionIndex = 148  OR  partitionIndex = 149  OR  partitionIndex = 163  OR  partitionIndex = 178  OR  partitionIndex = 179 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.104998796 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 12:======================================================> (62 + 2) / 64][Stage 12:=======================================================>(63 + 1) / 64]17/06/10 07:25:41 ERROR TaskSchedulerImpl: Lost executor 7 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:25:41 WARN TaskSetManager: Lost task 24.0 in stage 12.0 (TID 798, 128.110.152.145): ExecutorLostFailure (executor 7 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 13:==============================================>        (55 + 10) / 65][Stage 13:======================================================> (63 + 2) / 65][Stage 13:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 23.933087913 seconds
res15: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 182  OR  partitionIndex = 183  OR   partitionIndex = 192  OR  partitionIndex = 193  OR  partitionIndex = 194  OR  partitionIndex = 195  OR  partitionIn dex = 208  OR  partitionIndex = 209 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 182  OR  partitionIndex = 183  OR  partitionIndex = 192  OR  partitionIndex = 193  OR  partitionIndex = 194  OR  partitionIndex = 195  OR  partitionIndex = 208  OR  partitionIndex = 209 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.087311314 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.880376064 seconds
res17: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 0  OR  partitionIndex = 1  OR  part itionIndex = 2  OR  partitionIndex = 3  OR  partitionIndex = 16  OR  partitionIndex = 17  OR  partitionIndex = 18   OR  partitionIndex = 19 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 0  OR  partitionIndex = 1  OR  partitionIndex = 2  OR  partitionIndex = 3  OR  partitionIndex = 16  OR  partitionIndex = 17  OR  partitionIndex = 18  OR  partitionIndex = 19 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.097280411 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 16:=====================================================>  (61 + 3) / 64][Stage 16:======================================================> (62 + 2) / 64][Stage 16:=======================================================>(63 + 1) / 64]                                                                                [Stage 17:====================================================>   (61 + 4) / 65][Stage 17:======================================================> (63 + 2) / 65][Stage 17:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 11.76194613 seconds
res19: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 140  OR  partitionIndex = 141  OR   partitionIndex = 142  OR  partitionIndex = 143  OR  partitionIndex = 156  OR  partitionIndex = 157  OR  partitionIn dex = 158  OR  partitionIndex = 159 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 140  OR  partitionIndex = 141  OR  partitionIndex = 142  OR  partitionIndex = 143  OR  partitionIndex = 156  OR  partitionIndex = 157  OR  partitionIndex = 158  OR  partitionIndex = 159 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.086569409 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 18:======================================================> (62 + 2) / 64][Stage 18:=======================================================>(63 + 1) / 64]                                                                                [Stage 19:======================================================> (63 + 2) / 65][Stage 19:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 16.296140523 seconds
res21: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 150  OR  partitionIndex = 151  OR   partitionIndex = 164  OR  partitionIndex = 165  OR  partitionIndex = 166  OR  partitionIndex = 167  OR  partitionIn dex = 180  OR  partitionIndex = 181 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 150  OR  partitionIndex = 151  OR  partitionIndex = 164  OR  partitionIndex = 165  OR  partitionIndex = 166  OR  partitionIndex = 167  OR  partitionIndex = 180  OR  partitionIndex = 181 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.069608233 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 20:======================================================> (62 + 2) / 64][Stage 20:=======================================================>(63 + 1) / 64]17/06/10 07:26:46 ERROR TaskSchedulerImpl: Lost executor 5 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:26:46 WARN TaskSetManager: Lost task 37.0 in stage 20.0 (TID 1328, 128.110.152.141): ExecutorLostFailure (executor 5 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 21:==============================================>        (55 + 10) / 65][Stage 21:======================================================> (63 + 2) / 65][Stage 21:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 27.827897972 seconds
res23: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 77  OR  partitionIndex = 78  OR  pa rtitionIndex = 79  OR  partitionIndex = 92  OR  partitionIndex = 93  OR  partitionIndex = 94  OR  partitionIndex =  95  OR  partitionIndex = 108 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 77  OR  partitionIndex = 78  OR  partitionIndex = 79  OR  partitionIndex = 92  OR  partitionIndex = 93  OR  partitionIndex = 94  OR  partitionIndex = 95  OR  partitionIndex = 108 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.07302007 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.904770824 seconds
res25: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 78  OR  partitionIndex = 79  OR  pa rtitionIndex = 93  OR  partitionIndex = 94  OR  partitionIndex = 95  OR  partitionIndex = 108  OR  partitionIndex =  109  OR  partitionIndex = 124 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 78  OR  partitionIndex = 79  OR  partitionIndex = 93  OR  partitionIndex = 94  OR  partitionIndex = 95  OR  partitionIndex = 108  OR  partitionIndex = 109  OR  partitionIndex = 124 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.067724161 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 24:======================================================> (62 + 2) / 64][Stage 24:=======================================================>(63 + 1) / 64]                                                                                [Stage 25:======================================================> (63 + 2) / 65][Stage 25:=======================================================>(64 + 1) / 65]17/06/10 07:27:29 ERROR TaskSchedulerImpl: Lost executor 9 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:27:29 WARN TaskSetManager: Lost task 20.0 in stage 25.0 (TID 1634, 128.110.152.141): ExecutorLostFailure (executor 9 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 27.777743102 seconds
res27: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 194  OR  partitionIndex = 195  OR   partitionIndex = 209  OR  partitionIndex = 210  OR  partitionIndex = 211  OR  partitionIndex = 224  OR  partitionIn dex = 225  OR  partitionIndex = 240 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 194  OR  partitionIndex = 195  OR  partitionIndex = 209  OR  partitionIndex = 210  OR  partitionIndex = 211  OR  partitionIndex = 224  OR  partitionIndex = 225  OR  partitionIndex = 240 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.070993717 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 26:==============================================>        (54 + 10) / 64][Stage 26:======================================================> (62 + 2) / 64][Stage 26:=======================================================>(63 + 1) / 64]                                                                                [Stage 27:======================================================> (63 + 2) / 65][Stage 27:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 17.713556402 seconds
res29: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 155  OR  partitionIndex = 168  OR   partitionIndex = 169  OR  partitionIndex = 170  OR  partitionIndex = 171  OR  partitionIndex = 184  OR  partitionIn dex = 185  OR  partitionIndex = 186 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 155  OR  partitionIndex = 168  OR  partitionIndex = 169  OR  partitionIndex = 170  OR  partitionIndex = 171  OR  partitionIndex = 184  OR  partitionIndex = 185  OR  partitionIndex = 186 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.062093967 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 29:==============================================>        (55 + 10) / 65][Stage 29:================================================>       (56 + 9) / 65][Stage 29:=================================================>      (57 + 8) / 65]                                                                                Time elapsed: 15.515262928 seconds
res31: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 8  OR  partitionIndex = 9  OR  part itionIndex = 24  OR  partitionIndex = 102  OR  partitionIndex = 103  OR  partitionIndex = 117  OR  partitionIndex =  118  OR  partitionIndex = 119 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 8  OR  partitionIndex = 9  OR  partitionIndex = 24  OR  partitionIndex = 102  OR  partitionIndex = 103  OR  partitionIndex = 117  OR  partitionIndex = 118  OR  partitionIndex = 119 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.066560572 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 30:========================================>              (47 + 17) / 64][Stage 30:============================================>          (52 + 12) / 64][Stage 30:==============================================>        (54 + 10) / 64][Stage 30:================================================>       (55 + 9) / 64][Stage 30:=================================================>      (56 + 8) / 64]17/06/10 07:28:32 ERROR TaskSchedulerImpl: Lost executor 1 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:28:32 WARN TaskSetManager: Lost task 5.0 in stage 30.0 (TID 1943, 128.110.152.142): ExecutorLostFailure (executor 1 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:28:32 WARN TaskSetManager: Lost task 53.0 in stage 30.0 (TID 1991, 128.110.152.142): ExecutorLostFailure (executor 1 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:28:32 WARN TaskSetManager: Lost task 29.0 in stage 30.0 (TID 1967, 128.110.152.142): ExecutorLostFailure (executor 1 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:28:32 WARN TaskSetManager: Lost task 37.0 in stage 30.0 (TID 1975, 128.110.152.142): ExecutorLostFailure (executor 1 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:28:32 WARN TaskSetManager: Lost task 13.0 in stage 30.0 (TID 1951, 128.110.152.142): ExecutorLostFailure (executor 1 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:28:32 WARN TaskSetManager: Lost task 61.0 in stage 30.0 (TID 1999, 128.110.152.142): ExecutorLostFailure (executor 1 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:28:32 WARN TaskSetManager: Lost task 45.0 in stage 30.0 (TID 1983, 128.110.152.142): ExecutorLostFailure (executor 1 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:28:32 WARN TaskSetManager: Lost task 21.0 in stage 30.0 (TID 1959, 128.110.152.142): ExecutorLostFailure (executor 1 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 31:======================================================> (63 + 2) / 65][Stage 31:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 19.45332476 seconds
res33: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 198  OR  partitionIndex = 199  OR   partitionIndex = 214  OR  partitionIndex = 215  OR  partitionIndex = 228  OR  partitionIndex = 229  OR  partitionIn dex = 244  OR  partitionIndex = 245 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 198  OR  partitionIndex = 199  OR  partitionIndex = 214  OR  partitionIndex = 215  OR  partitionIndex = 228  OR  partitionIndex = 229  OR  partitionIndex = 244  OR  partitionIndex = 245 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.074638956 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 07:28:41 ERROR TaskSchedulerImpl: Lost executor 8 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:28:41 WARN TaskSetManager: Lost task 53.0 in stage 32.0 (TID 2128, 128.110.152.145): ExecutorLostFailure (executor 8 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:28:41 WARN TaskSetManager: Lost task 37.0 in stage 32.0 (TID 2112, 128.110.152.145): ExecutorLostFailure (executor 8 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 32:==============================================>        (54 + 10) / 64][Stage 32:======================================================> (62 + 2) / 64][Stage 32:=======================================================>(63 + 1) / 64]                                                                                [Stage 33:==============================================>        (55 + 10) / 65][Stage 33:======================================================> (63 + 2) / 65][Stage 33:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 13.544328211 seconds
res35: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 198  OR  partitionIndex = 199  OR   partitionIndex = 212  OR  partitionIndex = 213  OR  partitionIndex = 214  OR  partitionIndex = 215  OR  partitionIn dex = 228  OR  partitionIndex = 229 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 198  OR  partitionIndex = 199  OR  partitionIndex = 212  OR  partitionIndex = 213  OR  partitionIndex = 214  OR  partitionIndex = 215  OR  partitionIndex = 228  OR  partitionIndex = 229 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.068843123 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 34:======================================================> (62 + 2) / 64][Stage 34:=======================================================>(63 + 1) / 64]                                                                                [Stage 35:======================================================> (63 + 2) / 65][Stage 35:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 13.897869063 seconds
res37: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68  OR  partitionIndex = 69  OR  pa rtitionIndex = 70  OR  partitionIndex = 71  OR  partitionIndex = 84  OR  partitionIndex = 85  OR  partitionIndex =  86  OR  partitionIndex = 87 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68  OR  partitionIndex = 69  OR  partitionIndex = 70  OR  partitionIndex = 71  OR  partitionIndex = 84  OR  partitionIndex = 85  OR  partitionIndex = 86  OR  partitionIndex = 87 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.07031443 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 36:=======================================================>(63 + 1) / 64]                                                                                [Stage 37:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 19.401779308 seconds
res39: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 82  OR  partitionIndex = 83  OR  pa rtitionIndex = 96  OR  partitionIndex = 97  OR  partitionIndex = 98  OR  partitionIndex = 99  OR  partitionIndex =  112  OR  partitionIndex = 113 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 82  OR  partitionIndex = 83  OR  partitionIndex = 96  OR  partitionIndex = 97  OR  partitionIndex = 98  OR  partitionIndex = 99  OR  partitionIndex = 112  OR  partitionIndex = 113 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.076797204 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 38:======================================================> (62 + 2) / 64]                                                                                [Stage 39:======================================================> (63 + 2) / 65]17/06/10 07:29:49 ERROR TaskSchedulerImpl: Lost executor 10 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:29:49 WARN TaskSetManager: Lost task 23.0 in stage 39.0 (TID 2551, 128.110.152.141): ExecutorLostFailure (executor 10 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 39:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 22.419852652 seconds
res41: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 202  OR  partitionIndex = 203  OR   partitionIndex = 217  OR  partitionIndex = 218  OR  partitionIndex = 219  OR  partitionIndex = 232  OR  partitionIn dex = 233  OR  partitionIndex = 248 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 202  OR  partitionIndex = 203  OR  partitionIndex = 217  OR  partitionIndex = 218  OR  partitionIndex = 219  OR  partitionIndex = 232  OR  partitionIndex = 233  OR  partitionIndex = 248 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.064482396 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 40:=================================================>      (56 + 8) / 64]                                                                                Time elapsed: 5.775263928 seconds
res43: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 46  OR  partitionIndex = 47  OR  pa rtitionIndex = 61  OR  partitionIndex = 62  OR  partitionIndex = 63  OR  partitionIndex = 72  OR  partitionIndex =  73  OR  partitionIndex = 88 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 46  OR  partitionIndex = 47  OR  partitionIndex = 61  OR  partitionIndex = 62  OR  partitionIndex = 63  OR  partitionIndex = 72  OR  partitionIndex = 73  OR  partitionIndex = 88 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.064915178 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 42:======================================================> (62 + 2) / 64][Stage 42:=======================================================>(63 + 1) / 64]                                                                                [Stage 43:======================================================> (63 + 2) / 65][Stage 43:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.778959735 seconds
res45: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 134  OR  partitionIndex = 135  OR   partitionIndex = 149  OR  partitionIndex = 150  OR  partitionIndex = 151  OR  partitionIndex = 164  OR  partitionIn dex = 165  OR  partitionIndex = 180 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 134  OR  partitionIndex = 135  OR  partitionIndex = 149  OR  partitionIndex = 150  OR  partitionIndex = 151  OR  partitionIndex = 164  OR  partitionIndex = 165  OR  partitionIndex = 180 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058809564 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.717813589 seconds
res47: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 55  OR  partitionIndex = 64  OR  pa rtitionIndex = 65  OR  partitionIndex = 66  OR  partitionIndex = 67  OR  partitionIndex = 80  OR  partitionIndex =  81  OR  partitionIndex = 82 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 55  OR  partitionIndex = 64  OR  partitionIndex = 65  OR  partitionIndex = 66  OR  partitionIndex = 67  OR  partitionIndex = 80  OR  partitionIndex = 81  OR  partitionIndex = 82 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055548446 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 46:=======================================================>(63 + 1) / 64]                                                                                [Stage 47:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 7.639256394 seconds
res49: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 4  OR  partitionIndex = 33  OR  par titionIndex = 34  OR  partitionIndex = 35  OR  partitionIndex = 48  OR  partitionIndex = 49  OR  partitionIndex = 5 0  OR  partitionIndex = 51 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 4  OR  partitionIndex = 33  OR  partitionIndex = 34  OR  partitionIndex = 35  OR  partitionIndex = 48  OR  partitionIndex = 49  OR  partitionIndex = 50  OR  partitionIndex = 51 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05998791 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 48:=====================================================>  (61 + 3) / 64]17/06/10 07:30:42 ERROR TaskSchedulerImpl: Lost executor 12 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:30:42 WARN TaskSetManager: Lost task 0.0 in stage 48.0 (TID 3110, 128.110.152.145): ExecutorLostFailure (executor 12 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 48:======================================================> (62 + 2) / 64][Stage 48:=======================================================>(63 + 1) / 64]17/06/10 07:30:46 ERROR TaskSchedulerImpl: Lost executor 13 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:30:46 WARN TaskSetManager: Lost task 19.0 in stage 48.0 (TID 3129, 128.110.152.141): ExecutorLostFailure (executor 13 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 49:======================================>                (46 + 19) / 65][Stage 49:=======================================>               (47 + 18) / 65][Stage 49:========================================>              (48 + 17) / 65][Stage 49:================================================>       (56 + 9) / 65][Stage 49:======================================================> (63 + 2) / 65][Stage 49:=======================================================>(64 + 1) / 65]17/06/10 07:31:04 ERROR TaskSetManager: Total size of serialized results of 65 tasks (610.0 MB) is bigger than spark.driver.maxResultSize (512.0 MB)
org.apache.spark.SparkException: Job aborted due to stage failure: Total size of serialized results of 65 tasks (610.0 MB) is bigger than spark.driver.maxResultSize (512.0 MB)
  at org.apache.spark.scheduler.DAGScheduler.org$apache$spark$scheduler$DAGScheduler$$failJobAndIndependentStages(DAGScheduler.scala:1454)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$abortStage$1.apply(DAGScheduler.scala:1442)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$abortStage$1.apply(DAGScheduler.scala:1441)
  at scala.collection.mutable.ResizableArray$class.foreach(ResizableArray.scala:59)
  at scala.collection.mutable.ArrayBuffer.foreach(ArrayBuffer.scala:48)
  at org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:1441)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$handleTaskSetFailed$1.apply(DAGScheduler.scala:811)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$handleTaskSetFailed$1.apply(DAGScheduler.scala:811)
  at scala.Option.foreach(Option.scala:257)
  at org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:811)
  at org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:1667)
  at org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:1622)
  at org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:1611)
  at org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:48)
  at org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:632)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1873)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1886)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1899)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1913)
  at org.apache.spark.rdd.RDD$$anonfun$collect$1.apply(RDD.scala:912)
  at org.apache.spark.rdd.RDDOperationScope$.withScope(RDDOperationScope.scala:151)
  at org.apache.spark.rdd.RDDOperationScope$.withScope(RDDOperationScope.scala:112)
  at org.apache.spark.rdd.RDD.withScope(RDD.scala:358)
  at org.apache.spark.rdd.RDD.collect(RDD.scala:911)
  at $anonfun$1.apply$mcI$sp(<console>:38)
  at $anonfun$1.apply(<console>:38)
  at $anonfun$1.apply(<console>:38)
  at show_timing(<console>:30)
  ... 50 elided

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 66  OR  partitionIndex = 67  OR  pa rtitionIndex = 82  OR  partitionIndex = 83  OR  partitionIndex = 96  OR  partitionIndex = 97  OR  partitionIndex =  112  OR  partitionIndex = 113 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 66  OR  partitionIndex = 67  OR  partitionIndex = 82  OR  partitionIndex = 83  OR  partitionIndex = 96  OR  partitionIndex = 97  OR  partitionIndex = 112  OR  partitionIndex = 113 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.084513983 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 50:======================================================> (62 + 2) / 64][Stage 50:=======================================================>(63 + 1) / 64]                                                                                [Stage 51:======================================================> (63 + 2) / 65][Stage 51:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 17.418560438 seconds
res53: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 38  OR  partitionIndex = 39  OR  pa rtitionIndex = 53  OR  partitionIndex = 54  OR  partitionIndex = 55  OR  partitionIndex = 64  OR  partitionIndex =  65  OR  partitionIndex = 80 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 38  OR  partitionIndex = 39  OR  partitionIndex = 53  OR  partitionIndex = 54  OR  partitionIndex = 55  OR  partitionIndex = 64  OR  partitionIndex = 65  OR  partitionIndex = 80 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056043446 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 52:======================================================> (62 + 2) / 64][Stage 52:=======================================================>(63 + 1) / 64]                                                                                [Stage 53:======================================================> (63 + 2) / 65][Stage 53:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 14.708776836 seconds
res55: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 8  OR  partitionIndex = 9  OR  part itionIndex = 24  OR  partitionIndex = 25  OR  partitionIndex = 102  OR  partitionIndex = 103  OR  partitionIndex =  118  OR  partitionIndex = 119 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 8  OR  partitionIndex = 9  OR  partitionIndex = 24  OR  partitionIndex = 25  OR  partitionIndex = 102  OR  partitionIndex = 103  OR  partitionIndex = 118  OR  partitionIndex = 119 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.065726619 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 54:====================================================>   (60 + 4) / 64][Stage 54:=====================================================>  (61 + 3) / 64][Stage 54:======================================================> (62 + 2) / 64][Stage 54:=======================================================>(63 + 1) / 64]                                                                                [Stage 55:====================================================>   (61 + 4) / 65][Stage 55:=====================================================>  (62 + 3) / 65][Stage 55:======================================================> (63 + 2) / 65]                                                                                Time elapsed: 17.449330642 seconds
res57: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 44  OR  partitionIndex = 45  OR  pa rtitionIndex = 46  OR  partitionIndex = 47  OR  partitionIndex = 60  OR  partitionIndex = 61  OR  partitionIndex =  62  OR  partitionIndex = 63 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 44  OR  partitionIndex = 45  OR  partitionIndex = 46  OR  partitionIndex = 47  OR  partitionIndex = 60  OR  partitionIndex = 61  OR  partitionIndex = 62  OR  partitionIndex = 63 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.064406471 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 56:======================================================> (62 + 2) / 64][Stage 56:=======================================================>(63 + 1) / 64]17/06/10 07:32:14 ERROR TaskSchedulerImpl: Lost executor 14 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:32:14 WARN TaskSetManager: Lost task 9.0 in stage 56.0 (TID 3637, 128.110.152.145): ExecutorLostFailure (executor 14 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 57:==============================================>        (55 + 10) / 65][Stage 57:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 25.322613564 seconds
res59: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 67  OR  partitionIndex = 82  OR  pa rtitionIndex = 83  OR  partitionIndex = 96  OR  partitionIndex = 97  OR  partitionIndex = 98  OR  partitionIndex =  112  OR  partitionIndex = 113 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 67  OR  partitionIndex = 82  OR  partitionIndex = 83  OR  partitionIndex = 96  OR  partitionIndex = 97  OR  partitionIndex = 98  OR  partitionIndex = 112  OR  partitionIndex = 113 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.06820603 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 58:======================================================> (62 + 2) / 64][Stage 58:=======================================================>(63 + 1) / 64]                                                                                [Stage 59:======================================================> (63 + 2) / 65][Stage 59:=======================================================>(64 + 1) / 65]17/06/10 07:32:46 ERROR TaskSchedulerImpl: Lost executor 0 on 128.110.152.165: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:32:46 WARN TaskSetManager: Lost task 11.0 in stage 59.0 (TID 3833, 128.110.152.165): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 24.511890915 seconds
res61: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 136  OR  partitionIndex = 137  OR   partitionIndex = 152  OR  partitionIndex = 230  OR  partitionIndex = 231  OR  partitionIndex = 245  OR  partitionIn dex = 246  OR  partitionIndex = 247 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 136  OR  partitionIndex = 137  OR  partitionIndex = 152  OR  partitionIndex = 230  OR  partitionIndex = 231  OR  partitionIndex = 245  OR  partitionIndex = 246  OR  partitionIndex = 247 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056153324 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 60:==============================================>        (54 + 10) / 64][Stage 60:======================================================> (62 + 2) / 64][Stage 60:=======================================================>(63 + 1) / 64]                                                                                [Stage 61:======================================================> (63 + 2) / 65][Stage 61:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 18.274890455 seconds
res63: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 76  OR  partitionIndex = 77  OR  pa rtitionIndex = 78  OR  partitionIndex = 79  OR  partitionIndex = 92  OR  partitionIndex = 93  OR  partitionIndex =  94  OR  partitionIndex = 95 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 76  OR  partitionIndex = 77  OR  partitionIndex = 78  OR  partitionIndex = 79  OR  partitionIndex = 92  OR  partitionIndex = 93  OR  partitionIndex = 94  OR  partitionIndex = 95 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.066985662 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.809268737 seconds
res65: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 196  OR  partitionIndex = 197  OR   partitionIndex = 198  OR  partitionIndex = 212  OR  partitionIndex = 213  OR  partitionIndex = 227  OR  partitionIn dex = 242  OR  partitionIndex = 243 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 196  OR  partitionIndex = 197  OR  partitionIndex = 198  OR  partitionIndex = 212  OR  partitionIndex = 213  OR  partitionIndex = 227  OR  partitionIndex = 242  OR  partitionIndex = 243 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052261303 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.687361037 seconds
res67: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 6  OR  partitionIndex = 7  OR  part itionIndex = 21  OR  partitionIndex = 22  OR  partitionIndex = 23  OR  partitionIndex = 36  OR  partitionIndex = 37   OR  partitionIndex = 52 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 6  OR  partitionIndex = 7  OR  partitionIndex = 21  OR  partitionIndex = 22  OR  partitionIndex = 23  OR  partitionIndex = 36  OR  partitionIndex = 37  OR  partitionIndex = 52 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.063931506 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 66:======================================================> (62 + 2) / 64][Stage 66:=======================================================>(63 + 1) / 64]                                                                                [Stage 67:==============================================>        (55 + 10) / 65]17/06/10 07:33:31 ERROR TaskSchedulerImpl: Lost executor 15 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:33:31 WARN TaskSetManager: Lost task 42.0 in stage 67.0 (TID 4381, 128.110.152.141): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:33:31 WARN TaskSetManager: Lost task 50.0 in stage 67.0 (TID 4389, 128.110.152.141): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:33:31 WARN TaskSetManager: Lost task 26.0 in stage 67.0 (TID 4365, 128.110.152.141): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:33:31 WARN TaskSetManager: Lost task 2.0 in stage 67.0 (TID 4341, 128.110.152.141): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:33:31 WARN TaskSetManager: Lost task 58.0 in stage 67.0 (TID 4397, 128.110.152.141): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:33:31 WARN TaskSetManager: Lost task 34.0 in stage 67.0 (TID 4373, 128.110.152.141): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:33:31 WARN TaskSetManager: Lost task 10.0 in stage 67.0 (TID 4349, 128.110.152.141): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:33:31 WARN TaskSetManager: Lost task 18.0 in stage 67.0 (TID 4357, 128.110.152.141): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 67:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 14.10139325 seconds
res69: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 10  OR  partitionIndex = 11  OR  pa rtitionIndex = 26  OR  partitionIndex = 27  OR  partitionIndex = 40  OR  partitionIndex = 41  OR  partitionIndex =  56  OR  partitionIndex = 57 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 10  OR  partitionIndex = 11  OR  partitionIndex = 26  OR  partitionIndex = 27  OR  partitionIndex = 40  OR  partitionIndex = 41  OR  partitionIndex = 56  OR  partitionIndex = 57 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053617129 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 68:>                                                        (0 + 0) / 64][Stage 68:============================================>          (52 + 12) / 64][Stage 68:=============================================>         (53 + 11) / 64][Stage 68:================================================>       (55 + 9) / 64][Stage 68:=======================================================>(63 + 1) / 64]                                                                                [Stage 69:===========================================>           (51 + 14) / 65][Stage 69:============================================>          (52 + 13) / 65][Stage 69:=============================================>         (54 + 11) / 65]17/06/10 07:33:54 WARN TransportChannelHandler: Exception in connection from /128.110.152.141:42698
java.io.IOException: Connection reset by peer
	at sun.nio.ch.FileDispatcherImpl.read0(Native Method)
	at sun.nio.ch.SocketDispatcher.read(SocketDispatcher.java:39)
	at sun.nio.ch.IOUtil.readIntoNativeBuffer(IOUtil.java:223)
	at sun.nio.ch.IOUtil.read(IOUtil.java:192)
	at sun.nio.ch.SocketChannelImpl.read(SocketChannelImpl.java:380)
	at io.netty.buffer.PooledUnsafeDirectByteBuf.setBytes(PooledUnsafeDirectByteBuf.java:313)
	at io.netty.buffer.AbstractByteBuf.writeBytes(AbstractByteBuf.java:881)
	at io.netty.channel.socket.nio.NioSocketChannel.doReadBytes(NioSocketChannel.java:242)
	at io.netty.channel.nio.AbstractNioByteChannel$NioByteUnsafe.read(AbstractNioByteChannel.java:119)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:511)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 07:33:54 ERROR TaskSchedulerImpl: Lost executor 18 on 128.110.152.141: Command exited with code 137
17/06/10 07:33:54 WARN TaskSetManager: Lost task 51.0 in stage 69.0 (TID 4527, 128.110.152.141): ExecutorLostFailure (executor 18 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 07:33:54 WARN TaskSetManager: Lost task 27.0 in stage 69.0 (TID 4503, 128.110.152.141): ExecutorLostFailure (executor 18 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 07:33:54 WARN TaskSetManager: Lost task 3.0 in stage 69.0 (TID 4479, 128.110.152.141): ExecutorLostFailure (executor 18 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 07:33:54 WARN TaskSetManager: Lost task 59.0 in stage 69.0 (TID 4535, 128.110.152.141): ExecutorLostFailure (executor 18 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 07:33:54 WARN TaskSetManager: Lost task 35.0 in stage 69.0 (TID 4511, 128.110.152.141): ExecutorLostFailure (executor 18 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 07:33:54 WARN TaskSetManager: Lost task 11.0 in stage 69.0 (TID 4487, 128.110.152.141): ExecutorLostFailure (executor 18 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 07:33:54 WARN TaskSetManager: Lost task 19.0 in stage 69.0 (TID 4495, 128.110.152.141): ExecutorLostFailure (executor 18 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 07:33:54 WARN TaskSetManager: Lost task 43.0 in stage 69.0 (TID 4519, 128.110.152.141): ExecutorLostFailure (executor 18 exited caused by one of the running tasks) Reason: Command exited with code 137
[Stage 69:===================================================>    (60 + 5) / 65]17/06/10 07:33:54 ERROR TaskSchedulerImpl: Lost executor 3 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:33:54 WARN TaskSetManager: Lost task 39.0 in stage 69.0 (TID 4515, 128.110.152.168): ExecutorLostFailure (executor 3 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:33:54 WARN TaskSetManager: Lost task 11.1 in stage 69.0 (TID 4543, 128.110.152.168): ExecutorLostFailure (executor 3 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:33:54 ERROR TaskSchedulerImpl: Lost executor 6 on 128.110.152.152: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:33:54 WARN TaskSetManager: Lost task 24.0 in stage 69.0 (TID 4500, 128.110.152.152): ExecutorLostFailure (executor 6 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:33:54 WARN TaskSetManager: Lost task 51.1 in stage 69.0 (TID 4548, 128.110.152.152): ExecutorLostFailure (executor 6 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 69:====================================================>   (61 + 4) / 65]17/06/10 07:33:59 ERROR TaskSchedulerImpl: Lost executor 11 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:33:59 WARN TaskSetManager: Lost task 11.2 in stage 69.0 (TID 4549, 128.110.152.142): ExecutorLostFailure (executor 11 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:33:59 WARN TaskSetManager: Lost task 24.1 in stage 69.0 (TID 4552, 128.110.152.142): ExecutorLostFailure (executor 11 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 69:=====================================================>  (62 + 3) / 65][Stage 69:======================================================> (63 + 2) / 65]17/06/10 07:34:05 ERROR TaskSchedulerImpl: Lost executor 4 on 128.110.152.157: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:34:05 WARN TaskSetManager: Lost task 11.3 in stage 69.0 (TID 4554, 128.110.152.157): ExecutorLostFailure (executor 4 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:34:05 ERROR TaskSetManager: Task 11 in stage 69.0 failed 4 times; aborting job
org.apache.spark.SparkException: Job aborted due to stage failure: Task 11 in stage 69.0 failed 4 times, most recent failure: Lost task 11.3 in stage 69.0 (TID 4554, 128.110.152.157): ExecutorLostFailure (executor 4 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
Driver stacktrace:
  at org.apache.spark.scheduler.DAGScheduler.org$apache$spark$scheduler$DAGScheduler$$failJobAndIndependentStages(DAGScheduler.scala:1454)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$abortStage$1.apply(DAGScheduler.scala:1442)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$abortStage$1.apply(DAGScheduler.scala:1441)
  at scala.collection.mutable.ResizableArray$class.foreach(ResizableArray.scala:59)
  at scala.collection.mutable.ArrayBuffer.foreach(ArrayBuffer.scala:48)
  at org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:1441)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$handleTaskSetFailed$1.apply(DAGScheduler.scala:811)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$handleTaskSetFailed$1.apply(DAGScheduler.scala:811)
  at scala.Option.foreach(Option.scala:257)
  at org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:811)
  at org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:1667)
  at org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:1622)
  at org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:1611)
  at org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:48)
  at org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:632)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1873)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1886)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1899)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1913)
  at org.apache.spark.rdd.RDD$$anonfun$collect$1.apply(RDD.scala:912)
  at org.apache.spark.rdd.RDDOperationScope$.withScope(RDDOperationScope.scala:151)
  at org.apache.spark.rdd.RDDOperationScope$.withScope(RDDOperationScope.scala:112)
  at org.apache.spark.rdd.RDD.withScope(RDD.scala:358)
  at org.apache.spark.rdd.RDD.collect(RDD.scala:911)
  at $anonfun$1.apply$mcI$sp(<console>:38)
  at $anonfun$1.apply(<console>:38)
  at $anonfun$1.apply(<console>:38)
  at show_timing(<console>:30)
  ... 50 elided

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 94  OR  partitionIndex = 95  OR  pa rtitionIndex = 108  OR  partitionIndex = 109  OR  partitionIndex = 110  OR  partitionIndex = 111  OR  partitionInde x = 124  OR  partitionIndex = 125 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 94  OR  partitionIndex = 95  OR  partitionIndex = 108  OR  partitionIndex = 109  OR  partitionIndex = 110  OR  partitionIndex = 111  OR  partitionIndex = 124  OR  partitionIndex = 125 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.071468725 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 07:34:07 ERROR TaskSchedulerImpl: Lost executor 2 on 128.110.152.160: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:34:07 WARN TaskSetManager: Lost task 24.2 in stage 69.0 (TID 4553, 128.110.152.160): ExecutorLostFailure (executor 2 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 70:=============>                                         (13 + 39) / 52][Stage 70:================>                                      (16 + 36) / 52]17/06/10 07:34:08 ERROR TaskSchedulerImpl: Lost executor 16 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:34:08 WARN TaskSetManager: Lost task 50.0 in stage 70.0 (TID 4605, 128.110.152.145): ExecutorLostFailure (executor 16 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:34:08 WARN TaskSetManager: Lost task 49.0 in stage 70.0 (TID 4604, 128.110.152.145): ExecutorLostFailure (executor 16 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:34:08 WARN TaskSetManager: Lost task 9.0 in stage 70.0 (TID 4564, 128.110.152.145): ExecutorLostFailure (executor 16 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:34:08 WARN TaskSetManager: Lost task 48.0 in stage 70.0 (TID 4603, 128.110.152.145): ExecutorLostFailure (executor 16 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 70:====================>                                  (19 + 33) / 52][Stage 70:===================================>                   (34 + 18) / 52][Stage 70:============================================>          (42 + 10) / 52][Stage 70:=====================================================>  (50 + 2) / 52][Stage 70:======================================================> (51 + 1) / 52]                                                                                [Stage 71:==================================>                    (33 + 20) / 53][Stage 71:===============================================>        (45 + 8) / 53][Stage 71:=====================================================>  (51 + 2) / 53][Stage 71:======================================================> (52 + 1) / 53]                                                                                Time elapsed: 27.692504927 seconds
res73: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 196  OR  partitionIndex = 225  OR   partitionIndex = 226  OR  partitionIndex = 227  OR  partitionIndex = 240  OR  partitionIndex = 241  OR  partitionIn dex = 242  OR  partitionIndex = 243 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 196  OR  partitionIndex = 225  OR  partitionIndex = 226  OR  partitionIndex = 227  OR  partitionIndex = 240  OR  partitionIndex = 241  OR  partitionIndex = 242  OR  partitionIndex = 243 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.081003435 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.856304594 seconds
res75: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 140  OR  partitionIndex = 141  OR   partitionIndex = 156  OR  partitionIndex = 157  OR  partitionIndex = 170  OR  partitionIndex = 171  OR  partitionIn dex = 186  OR  partitionIndex = 187 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 140  OR  partitionIndex = 141  OR  partitionIndex = 156  OR  partitionIndex = 157  OR  partitionIndex = 170  OR  partitionIndex = 171  OR  partitionIndex = 186  OR  partitionIndex = 187 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058211993 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 74:======================================================> (62 + 2) / 64]                                                                                [Stage 75:======================================================> (63 + 2) / 65][Stage 75:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 20.984720782 seconds
res77: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 76  OR  partitionIndex = 77  OR  pa rtitionIndex = 78  OR  partitionIndex = 79  OR  partitionIndex = 92  OR  partitionIndex = 93  OR  partitionIndex =  122  OR  partitionIndex = 123 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 76  OR  partitionIndex = 77  OR  partitionIndex = 78  OR  partitionIndex = 79  OR  partitionIndex = 92  OR  partitionIndex = 93  OR  partitionIndex = 122  OR  partitionIndex = 123 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.068004984 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.783632854 seconds
res79: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 4  OR  partitionIndex = 5  OR  part itionIndex = 6  OR  partitionIndex = 7  OR  partitionIndex = 20  OR  partitionIndex = 21  OR  partitionIndex = 50   OR  partitionIndex = 51 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 4  OR  partitionIndex = 5  OR  partitionIndex = 6  OR  partitionIndex = 7  OR  partitionIndex = 20  OR  partitionIndex = 21  OR  partitionIndex = 50  OR  partitionIndex = 51 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056725324 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 78:======================================================> (62 + 2) / 64][Stage 78:=======================================================>(63 + 1) / 64]                                                                                [Stage 79:======================================================> (63 + 2) / 65][Stage 79:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 17.452011505 seconds
res81: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 12  OR  partitionIndex = 13  OR  pa rtitionIndex = 14  OR  partitionIndex = 15  OR  partitionIndex = 28  OR  partitionIndex = 29  OR  partitionIndex =  30  OR  partitionIndex = 31 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 12  OR  partitionIndex = 13  OR  partitionIndex = 14  OR  partitionIndex = 15  OR  partitionIndex = 28  OR  partitionIndex = 29  OR  partitionIndex = 30  OR  partitionIndex = 31 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057858849 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 80:======================================================> (62 + 2) / 64][Stage 80:=======================================================>(63 + 1) / 64]                                                                                [Stage 81:======================================================> (63 + 2) / 65][Stage 81:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.91144697 seconds
res83: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 198  OR  partitionIndex = 199  OR   partitionIndex = 213  OR  partitionIndex = 214  OR  partitionIndex = 215  OR  partitionIndex = 228  OR  partitionIn dex = 229  OR  partitionIndex = 244 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 198  OR  partitionIndex = 199  OR  partitionIndex = 213  OR  partitionIndex = 214  OR  partitionIndex = 215  OR  partitionIndex = 228  OR  partitionIndex = 229  OR  partitionIndex = 244 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056363801 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 82:======================================================> (62 + 2) / 64][Stage 82:=======================================================>(63 + 1) / 64]                                                                                [Stage 83:======================================================> (63 + 2) / 65][Stage 83:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 13.489958268 seconds
res85: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 134  OR  partitionIndex = 135  OR   partitionIndex = 148  OR  partitionIndex = 149  OR  partitionIndex = 150  OR  partitionIndex = 151  OR  partitionIn dex = 164  OR  partitionIndex = 165 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 134  OR  partitionIndex = 135  OR  partitionIndex = 148  OR  partitionIndex = 149  OR  partitionIndex = 150  OR  partitionIndex = 151  OR  partitionIndex = 164  OR  partitionIndex = 165 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052413599 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.662643166 seconds
res87: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 136  OR  partitionIndex = 229  OR   partitionIndex = 230  OR  partitionIndex = 231  OR  partitionIndex = 244  OR  partitionIndex = 245  OR  partitionIn dex = 246  OR  partitionIndex = 247 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 136  OR  partitionIndex = 229  OR  partitionIndex = 230  OR  partitionIndex = 231  OR  partitionIndex = 244  OR  partitionIndex = 245  OR  partitionIndex = 246  OR  partitionIndex = 247 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046689428 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 86:======================================================> (62 + 2) / 64][Stage 86:=======================================================>(63 + 1) / 64]                                                                                [Stage 87:======================================================> (63 + 2) / 65][Stage 87:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 14.388128429 seconds
res89: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 11  OR  partitionIndex = 26  OR  pa rtitionIndex = 27  OR  partitionIndex = 40  OR  partitionIndex = 41  OR  partitionIndex = 42  OR  partitionIndex =  56  OR  partitionIndex = 57 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 11  OR  partitionIndex = 26  OR  partitionIndex = 27  OR  partitionIndex = 40  OR  partitionIndex = 41  OR  partitionIndex = 42  OR  partitionIndex = 56  OR  partitionIndex = 57 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.078796599 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 88:=====================================================>  (61 + 3) / 64][Stage 88:======================================================> (62 + 2) / 64][Stage 88:=======================================================>(63 + 1) / 64]                                                                                [Stage 89:=====================================================>  (62 + 3) / 65][Stage 89:======================================================> (63 + 2) / 65][Stage 89:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 16.568957129 seconds
res91: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 218  OR  partitionIndex = 219  OR   partitionIndex = 232  OR  partitionIndex = 233  OR  partitionIndex = 234  OR  partitionIndex = 235  OR  partitionIn dex = 248  OR  partitionIndex = 249 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 218  OR  partitionIndex = 219  OR  partitionIndex = 232  OR  partitionIndex = 233  OR  partitionIndex = 234  OR  partitionIndex = 235  OR  partitionIndex = 248  OR  partitionIndex = 249 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.070705395 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 90:=======================================================>(63 + 1) / 64]                                                                                [Stage 91:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 14.047976521 seconds
res93: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 196  OR  partitionIndex = 197  OR   partitionIndex = 198  OR  partitionIndex = 199  OR  partitionIndex = 212  OR  partitionIndex = 213  OR  partitionIn dex = 242  OR  partitionIndex = 243 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 196  OR  partitionIndex = 197  OR  partitionIndex = 198  OR  partitionIndex = 199  OR  partitionIndex = 212  OR  partitionIndex = 213  OR  partitionIndex = 242  OR  partitionIndex = 243 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.061829288 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.576864733 seconds
res95: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68  OR  partitionIndex = 69  OR  pa rtitionIndex = 70  OR  partitionIndex = 71  OR  partitionIndex = 84  OR  partitionIndex = 85  OR  partitionIndex =  86  OR  partitionIndex = 115 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68  OR  partitionIndex = 69  OR  partitionIndex = 70  OR  partitionIndex = 71  OR  partitionIndex = 84  OR  partitionIndex = 85  OR  partitionIndex = 86  OR  partitionIndex = 115 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051289851 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 94:======================================================> (62 + 2) / 64][Stage 94:=======================================================>(63 + 1) / 64]17/06/10 07:37:07 ERROR TaskSchedulerImpl: Lost executor 19 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:37:07 WARN TaskSetManager: Lost task 23.0 in stage 94.0 (TID 6106, 128.110.152.141): ExecutorLostFailure (executor 19 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 95:==============================================>        (55 + 10) / 65][Stage 95:======================================================> (63 + 2) / 65][Stage 95:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 29.283454353 seconds
res97: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 65  OR  partitionIndex = 66  OR  pa rtitionIndex = 67  OR  partitionIndex = 80  OR  partitionIndex = 81  OR  partitionIndex = 82  OR  partitionIndex =  83  OR  partitionIndex = 96 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 65  OR  partitionIndex = 66  OR  partitionIndex = 67  OR  partitionIndex = 80  OR  partitionIndex = 81  OR  partitionIndex = 82  OR  partitionIndex = 83  OR  partitionIndex = 96 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050805368 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.775973654 seconds
res99: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 12  OR  partitionIndex = 13  OR  pa rtitionIndex = 28  OR  partitionIndex = 29  OR  partitionIndex = 42  OR  partitionIndex = 43  OR  partitionIndex =  58  OR  partitionIndex = 59 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 12  OR  partitionIndex = 13  OR  partitionIndex = 28  OR  partitionIndex = 29  OR  partitionIndex = 42  OR  partitionIndex = 43  OR  partitionIndex = 58  OR  partitionIndex = 59 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048179075 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 98:=====================================================>  (61 + 3) / 64][Stage 98:======================================================> (62 + 2) / 64][Stage 98:=======================================================>(63 + 1) / 64]                                                                                [Stage 99:=====================================================>  (62 + 3) / 65][Stage 99:======================================================> (63 + 2) / 65][Stage 99:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.844559638 seconds
res101: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 210  OR  partitionIndex = 211  OR   partitionIndex = 224  OR  partitionIndex = 225  OR  partitionIndex = 226  OR  partitionIndex = 227  OR  partitionIn dex = 240  OR  partitionIndex = 241 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 210  OR  partitionIndex = 211  OR  partitionIndex = 224  OR  partitionIndex = 225  OR  partitionIndex = 226  OR  partitionIndex = 227  OR  partitionIndex = 240  OR  partitionIndex = 241 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050928168 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.630992902 seconds
res103: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 132  OR  partitionIndex = 133  OR   partitionIndex = 134  OR  partitionIndex = 135  OR  partitionIndex = 148  OR  partitionIndex = 149  OR  partitionIn dex = 150  OR  partitionIndex = 179 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 132  OR  partitionIndex = 133  OR  partitionIndex = 134  OR  partitionIndex = 135  OR  partitionIndex = 148  OR  partitionIndex = 149  OR  partitionIndex = 150  OR  partitionIndex = 179 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051576451 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.580815176 seconds
res105: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 175  OR  partitionIndex = 190  OR   partitionIndex = 191  OR  partitionIndex = 200  OR  partitionIndex = 201  OR  partitionIndex = 202  OR  partitionIn dex = 216  OR  partitionIndex = 217 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 175  OR  partitionIndex = 190  OR  partitionIndex = 191  OR  partitionIndex = 200  OR  partitionIndex = 201  OR  partitionIndex = 202  OR  partitionIndex = 216  OR  partitionIndex = 217 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049821163 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 104:=====================================================> (62 + 2) / 64][Stage 104:======================================================>(63 + 1) / 64]                                                                                [Stage 105:==========================================>           (51 + 14) / 65][Stage 105:===========================================>          (52 + 13) / 65][Stage 105:============================================>         (53 + 12) / 65][Stage 105:============================================>         (54 + 11) / 65][Stage 105:=============================================>        (55 + 10) / 65][Stage 105:===============================================>       (56 + 9) / 65][Stage 105:===============================================>       (56 + 9) / 65][Stage 105:===============================================>       (56 + 9) / 65][Stage 105:================================================>      (57 + 8) / 65][Stage 105:================================================>      (57 + 8) / 65][Stage 105:================================================>      (57 + 8) / 65][Stage 105:================================================>      (57 + 8) / 65][Stage 105:================================================>      (57 + 8) / 65][Stage 105:================================================>      (57 + 8) / 65][Stage 105:================================================>      (57 + 8) / 65][Stage 105:================================================>      (57 + 8) / 65][Stage 105:================================================>      (57 + 8) / 65][Stage 105:================================================>      (57 + 8) / 65][Stage 105:================================================>      (57 + 8) / 65][Stage 105:================================================>      (57 + 8) / 65][Stage 105:================================================>      (57 + 8) / 65][Stage 105:================================================>      (57 + 8) / 65][Stage 105:================================================>      (57 + 8) / 65][Stage 105:================================================>      (57 + 8) / 65]17/06/10 07:56:27 ERROR TaskSchedulerImpl: Lost executor 25 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:56:27 WARN TaskSetManager: Lost task 1.0 in stage 105.0 (TID 6794, 128.110.152.145): ExecutorLostFailure (executor 25 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:56:27 WARN TaskSetManager: Lost task 49.0 in stage 105.0 (TID 6842, 128.110.152.145): ExecutorLostFailure (executor 25 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:56:27 WARN TaskSetManager: Lost task 25.0 in stage 105.0 (TID 6818, 128.110.152.145): ExecutorLostFailure (executor 25 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:56:27 WARN TaskSetManager: Lost task 57.0 in stage 105.0 (TID 6850, 128.110.152.145): ExecutorLostFailure (executor 25 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:56:27 WARN TaskSetManager: Lost task 33.0 in stage 105.0 (TID 6826, 128.110.152.145): ExecutorLostFailure (executor 25 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:56:27 WARN TaskSetManager: Lost task 9.0 in stage 105.0 (TID 6802, 128.110.152.145): ExecutorLostFailure (executor 25 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:56:27 WARN TaskSetManager: Lost task 41.0 in stage 105.0 (TID 6834, 128.110.152.145): ExecutorLostFailure (executor 25 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:56:27 WARN TaskSetManager: Lost task 17.0 in stage 105.0 (TID 6810, 128.110.152.145): ExecutorLostFailure (executor 25 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 1113.806233052 seconds
res107: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 207  OR  partitionIndex = 222  OR   partitionIndex = 223  OR  partitionIndex = 236  OR  partitionIndex = 237  OR  partitionIndex = 238  OR  partitionIn dex = 252  OR  partitionIndex = 253 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 207  OR  partitionIndex = 222  OR  partitionIndex = 223  OR  partitionIndex = 236  OR  partitionIndex = 237  OR  partitionIndex = 238  OR  partitionIndex = 252  OR  partitionIndex = 253 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.065466711 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.578745255 seconds
res109: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 137  OR  partitionIndex = 138  OR   partitionIndex = 139  OR  partitionIndex = 152  OR  partitionIndex = 153  OR  partitionIndex = 154  OR  partitionIn dex = 155  OR  partitionIndex = 168 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 137  OR  partitionIndex = 138  OR  partitionIndex = 139  OR  partitionIndex = 152  OR  partitionIndex = 153  OR  partitionIndex = 154  OR  partitionIndex = 155  OR  partitionIndex = 168 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049418775 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 108:================================================>      (56 + 8) / 64]                                                                                Time elapsed: 5.711787979 seconds
res111: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 6  OR  partitionIndex = 7  OR  part itionIndex = 22  OR  partitionIndex = 23  OR  partitionIndex = 36  OR  partitionIndex = 37  OR  partitionIndex = 52   OR  partitionIndex = 53 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 6  OR  partitionIndex = 7  OR  partitionIndex = 22  OR  partitionIndex = 23  OR  partitionIndex = 36  OR  partitionIndex = 37  OR  partitionIndex = 52  OR  partitionIndex = 53 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05029666 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 110:====================================================>  (61 + 3) / 64][Stage 110:=====================================================> (62 + 2) / 64][Stage 110:======================================================>(63 + 1) / 64]                                                                                [Stage 111:====================================================>  (62 + 3) / 65][Stage 111:=====================================================> (63 + 2) / 65][Stage 111:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 16.102946963 seconds
res113: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68  OR  partitionIndex = 69  OR  pa rtitionIndex = 70  OR  partitionIndex = 71  OR  partitionIndex = 84  OR  partitionIndex = 85  OR  partitionIndex =  114  OR  partitionIndex = 115 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68  OR  partitionIndex = 69  OR  partitionIndex = 70  OR  partitionIndex = 71  OR  partitionIndex = 84  OR  partitionIndex = 85  OR  partitionIndex = 114  OR  partitionIndex = 115 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048850952 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.625593971 seconds
res115: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 74  OR  partitionIndex = 75  OR  pa rtitionIndex = 89  OR  partitionIndex = 90  OR  partitionIndex = 91  OR  partitionIndex = 104  OR  partitionIndex =  105  OR  partitionIndex = 120 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 74  OR  partitionIndex = 75  OR  partitionIndex = 89  OR  partitionIndex = 90  OR  partitionIndex = 91  OR  partitionIndex = 104  OR  partitionIndex = 105  OR  partitionIndex = 120 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055875705 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 114:=====================================================> (62 + 2) / 64][Stage 114:======================================================>(63 + 1) / 64]                                                                                [Stage 115:=====================================================> (63 + 2) / 65][Stage 115:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 16.34939854 seconds
res117: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 196  OR  partitionIndex = 197  OR   partitionIndex = 198  OR  partitionIndex = 199  OR  partitionIndex = 212  OR  partitionIndex = 213  OR  partitionIn dex = 214  OR  partitionIndex = 243 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 196  OR  partitionIndex = 197  OR  partitionIndex = 198  OR  partitionIndex = 199  OR  partitionIndex = 212  OR  partitionIndex = 213  OR  partitionIndex = 214  OR  partitionIndex = 243 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.065818592 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.582712903 seconds
res119: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 8  OR  partitionIndex = 9  OR  part itionIndex = 10  OR  partitionIndex = 11  OR  partitionIndex = 24  OR  partitionIndex = 25  OR  partitionIndex = 11 8  OR  partitionIndex = 119 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 8  OR  partitionIndex = 9  OR  partitionIndex = 10  OR  partitionIndex = 11  OR  partitionIndex = 24  OR  partitionIndex = 25  OR  partitionIndex = 118  OR  partitionIndex = 119 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047112163 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 118:===================================================>   (60 + 4) / 64][Stage 118:====================================================>  (61 + 3) / 64][Stage 118:=====================================================> (62 + 2) / 64][Stage 118:======================================================>(63 + 1) / 64]                                                                                [Stage 119:===================================================>   (61 + 4) / 65][Stage 119:====================================================>  (62 + 3) / 65][Stage 119:=====================================================> (63 + 2) / 65][Stage 119:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 17.250185211 seconds
res121: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 109  OR  partitionIndex = 110  OR   partitionIndex = 111  OR  partitionIndex = 124  OR  partitionIndex = 125  OR  partitionIndex = 126  OR  partitionIn dex = 127  OR  partitionIndex = 128 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 109  OR  partitionIndex = 110  OR  partitionIndex = 111  OR  partitionIndex = 124  OR  partitionIndex = 125  OR  partitionIndex = 126  OR  partitionIndex = 127  OR  partitionIndex = 128 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.064822527 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 120:======================================================>(63 + 1) / 64]                                                                                [Stage 121:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 21.165909224 seconds
res123: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 168  OR  partitionIndex = 169  OR   partitionIndex = 170  OR  partitionIndex = 171  OR  partitionIndex = 184  OR  partitionIndex = 185  OR  partitionIn dex = 186  OR  partitionIndex = 187 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 168  OR  partitionIndex = 169  OR  partitionIndex = 170  OR  partitionIndex = 171  OR  partitionIndex = 184  OR  partitionIndex = 185  OR  partitionIndex = 186  OR  partitionIndex = 187 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.078519331 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 122:======================================================>(63 + 1) / 64]17/06/10 07:58:14 ERROR TaskSchedulerImpl: Lost executor 21 on 128.110.152.152: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:58:14 WARN TaskSetManager: Lost task 35.0 in stage 122.0 (TID 7917, 128.110.152.152): ExecutorLostFailure (executor 21 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 123:===============================================>       (56 + 9) / 65][Stage 123:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 27.593062078 seconds
res125: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 204  OR  partitionIndex = 205  OR   partitionIndex = 206  OR  partitionIndex = 220  OR  partitionIndex = 221  OR  partitionIndex = 235  OR  partitionIn dex = 250  OR  partitionIndex = 251 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 204  OR  partitionIndex = 205  OR  partitionIndex = 206  OR  partitionIndex = 220  OR  partitionIndex = 221  OR  partitionIndex = 235  OR  partitionIndex = 250  OR  partitionIndex = 251 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050734979 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.7384579 seconds
res127: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 140  OR  partitionIndex = 141  OR   partitionIndex = 156  OR  partitionIndex = 170  OR  partitionIndex = 171  OR  partitionIndex = 185  OR  partitionIn dex = 186  OR  partitionIndex = 187 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 140  OR  partitionIndex = 141  OR  partitionIndex = 156  OR  partitionIndex = 170  OR  partitionIndex = 171  OR  partitionIndex = 185  OR  partitionIndex = 186  OR  partitionIndex = 187 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054569197 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.643619292 seconds
res129: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 71  OR  partitionIndex = 86  OR  pa rtitionIndex = 87  OR  partitionIndex = 100  OR  partitionIndex = 101  OR  partitionIndex = 102  OR  partitionIndex  = 116  OR  partitionIndex = 117 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 71  OR  partitionIndex = 86  OR  partitionIndex = 87  OR  partitionIndex = 100  OR  partitionIndex = 101  OR  partitionIndex = 102  OR  partitionIndex = 116  OR  partitionIndex = 117 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04455875 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 128:=====================================================> (62 + 2) / 64][Stage 128:======================================================>(63 + 1) / 64]17/06/10 07:58:49 ERROR TaskSchedulerImpl: Lost executor 22 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:58:49 WARN TaskSetManager: Lost task 20.0 in stage 128.0 (TID 8290, 128.110.152.142): ExecutorLostFailure (executor 22 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                17/06/10 07:58:57 ERROR TaskSchedulerImpl: Lost executor 20 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:58:57 WARN TaskSetManager: Lost task 8.0 in stage 129.0 (TID 8343, 128.110.152.168): ExecutorLostFailure (executor 20 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 129:=============================================>        (55 + 10) / 65][Stage 129:=====================================================> (63 + 2) / 65]17/06/10 07:59:05 ERROR TaskSchedulerImpl: Lost executor 27 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:59:05 WARN TaskSetManager: Lost task 8.1 in stage 129.0 (TID 8400, 128.110.152.145): ExecutorLostFailure (executor 27 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:59:05 WARN TaskSetManager: Lost task 20.0 in stage 129.0 (TID 8355, 128.110.152.145): ExecutorLostFailure (executor 27 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 129:======================================================>(64 + 1) / 65]17/06/10 07:59:14 ERROR TaskSchedulerImpl: Lost executor 24 on 128.110.152.160: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:59:14 WARN TaskSetManager: Lost task 20.1 in stage 129.0 (TID 8401, 128.110.152.160): ExecutorLostFailure (executor 24 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 49.238585956 seconds
res131: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 4  OR  partitionIndex = 5  OR  part itionIndex = 20  OR  partitionIndex = 21  OR  partitionIndex = 34  OR  partitionIndex = 35  OR  partitionIndex = 50   OR  partitionIndex = 51 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 4  OR  partitionIndex = 5  OR  partitionIndex = 20  OR  partitionIndex = 21  OR  partitionIndex = 34  OR  partitionIndex = 35  OR  partitionIndex = 50  OR  partitionIndex = 51 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048862229 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 130:======================================>               (46 + 18) / 64][Stage 130:=======================================>              (47 + 17) / 64][Stage 130:======================================================>(63 + 1) / 64]17/06/10 07:59:38 ERROR TaskSchedulerImpl: Lost executor 26 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:59:38 WARN TaskSetManager: Lost task 0.0 in stage 130.0 (TID 8404, 128.110.152.141): ExecutorLostFailure (executor 26 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 131:=============================================>        (55 + 10) / 65][Stage 131:===============================================>       (56 + 9) / 65][Stage 131:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 23.248171519 seconds
res133: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 10  OR  partitionIndex = 11  OR  pa rtitionIndex = 24  OR  partitionIndex = 25  OR  partitionIndex = 26  OR  partitionIndex = 27  OR  partitionIndex =  40  OR  partitionIndex = 41 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 10  OR  partitionIndex = 11  OR  partitionIndex = 24  OR  partitionIndex = 25  OR  partitionIndex = 26  OR  partitionIndex = 27  OR  partitionIndex = 40  OR  partitionIndex = 41 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047237341 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 132:=====================================================> (62 + 2) / 64][Stage 132:======================================================>(63 + 1) / 64]                                                                                [Stage 133:=====================================================> (63 + 2) / 65][Stage 133:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 17.990132743 seconds
res135: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 204  OR  partitionIndex = 205  OR   partitionIndex = 206  OR  partitionIndex = 207  OR  partitionIndex = 220  OR  partitionIndex = 221  OR  partitionIn dex = 222  OR  partitionIndex = 223 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 204  OR  partitionIndex = 205  OR  partitionIndex = 206  OR  partitionIndex = 207  OR  partitionIndex = 220  OR  partitionIndex = 221  OR  partitionIndex = 222  OR  partitionIndex = 223 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054858136 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 134:=====================================================> (62 + 2) / 64][Stage 134:======================================================>(63 + 1) / 64]                                                                                [Stage 135:=====================================================> (63 + 2) / 65][Stage 135:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 13.646401531 seconds
res137: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68  OR  partitionIndex = 69  OR  pa rtitionIndex = 70  OR  partitionIndex = 84  OR  partitionIndex = 85  OR  partitionIndex = 99  OR  partitionIndex =  114  OR  partitionIndex = 115 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68  OR  partitionIndex = 69  OR  partitionIndex = 70  OR  partitionIndex = 84  OR  partitionIndex = 85  OR  partitionIndex = 99  OR  partitionIndex = 114  OR  partitionIndex = 115 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046932279 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.76266822 seconds
res139: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 12  OR  partitionIndex = 41  OR  pa rtitionIndex = 42  OR  partitionIndex = 43  OR  partitionIndex = 56  OR  partitionIndex = 57  OR  partitionIndex =  58  OR  partitionIndex = 59 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 12  OR  partitionIndex = 41  OR  partitionIndex = 42  OR  partitionIndex = 43  OR  partitionIndex = 56  OR  partitionIndex = 57  OR  partitionIndex = 58  OR  partitionIndex = 59 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045701173 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 138:====================================================>  (61 + 3) / 64][Stage 138:=====================================================> (62 + 2) / 64][Stage 138:======================================================>(63 + 1) / 64]                                                                                [Stage 139:====================================================>  (62 + 3) / 65][Stage 139:=====================================================> (63 + 2) / 65][Stage 139:======================================================>(64 + 1) / 65]17/06/10 08:00:48 WARN TransportChannelHandler: Exception in connection from /128.110.152.145:39582
java.io.IOException: Connection reset by peer
	at sun.nio.ch.FileDispatcherImpl.read0(Native Method)
	at sun.nio.ch.SocketDispatcher.read(SocketDispatcher.java:39)
	at sun.nio.ch.IOUtil.readIntoNativeBuffer(IOUtil.java:223)
	at sun.nio.ch.IOUtil.read(IOUtil.java:192)
	at sun.nio.ch.SocketChannelImpl.read(SocketChannelImpl.java:380)
	at io.netty.buffer.PooledUnsafeDirectByteBuf.setBytes(PooledUnsafeDirectByteBuf.java:313)
	at io.netty.buffer.AbstractByteBuf.writeBytes(AbstractByteBuf.java:881)
	at io.netty.channel.socket.nio.NioSocketChannel.doReadBytes(NioSocketChannel.java:242)
	at io.netty.channel.nio.AbstractNioByteChannel$NioByteUnsafe.read(AbstractNioByteChannel.java:119)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:511)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 08:00:48 ERROR TaskSchedulerImpl: Lost executor 31 on 128.110.152.145: Command exited with code 137
17/06/10 08:00:48 WARN TaskSetManager: Lost task 4.0 in stage 139.0 (TID 8989, 128.110.152.145): ExecutorLostFailure (executor 31 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 08:00:48 ERROR TransportResponseHandler: Still have 1 requests outstanding when connection from /128.110.152.145:39582 is closed
17/06/10 08:00:48 WARN BlockManagerMaster: Failed to remove broadcast 201 with removeFromMaster = true - Connection reset by peer
java.io.IOException: Connection reset by peer
	at sun.nio.ch.FileDispatcherImpl.read0(Native Method)
	at sun.nio.ch.SocketDispatcher.read(SocketDispatcher.java:39)
	at sun.nio.ch.IOUtil.readIntoNativeBuffer(IOUtil.java:223)
	at sun.nio.ch.IOUtil.read(IOUtil.java:192)
	at sun.nio.ch.SocketChannelImpl.read(SocketChannelImpl.java:380)
	at io.netty.buffer.PooledUnsafeDirectByteBuf.setBytes(PooledUnsafeDirectByteBuf.java:313)
	at io.netty.buffer.AbstractByteBuf.writeBytes(AbstractByteBuf.java:881)
	at io.netty.channel.socket.nio.NioSocketChannel.doReadBytes(NioSocketChannel.java:242)
	at io.netty.channel.nio.AbstractNioByteChannel$NioByteUnsafe.read(AbstractNioByteChannel.java:119)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:511)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 08:00:48 ERROR ContextCleaner: Error cleaning broadcast 201
org.apache.spark.SparkException: Exception thrown in awaitResult
	at org.apache.spark.rpc.RpcTimeout$$anonfun$1.applyOrElse(RpcTimeout.scala:77)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$1.applyOrElse(RpcTimeout.scala:75)
	at scala.runtime.AbstractPartialFunction.apply(AbstractPartialFunction.scala:36)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$addMessageIfTimeout$1.applyOrElse(RpcTimeout.scala:59)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$addMessageIfTimeout$1.applyOrElse(RpcTimeout.scala:59)
	at scala.PartialFunction$OrElse.apply(PartialFunction.scala:167)
	at org.apache.spark.rpc.RpcTimeout.awaitResult(RpcTimeout.scala:83)
	at org.apache.spark.storage.BlockManagerMaster.removeBroadcast(BlockManagerMaster.scala:143)
	at org.apache.spark.broadcast.TorrentBroadcast$.unpersist(TorrentBroadcast.scala:267)
	at org.apache.spark.broadcast.TorrentBroadcastFactory.unbroadcast(TorrentBroadcastFactory.scala:45)
	at org.apache.spark.broadcast.BroadcastManager.unbroadcast(BroadcastManager.scala:60)
	at org.apache.spark.ContextCleaner.doCleanupBroadcast(ContextCleaner.scala:232)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1$$anonfun$apply$mcV$sp$2.apply(ContextCleaner.scala:188)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1$$anonfun$apply$mcV$sp$2.apply(ContextCleaner.scala:179)
	at scala.Option.foreach(Option.scala:257)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1.apply$mcV$sp(ContextCleaner.scala:179)
	at org.apache.spark.util.Utils$.tryOrStopSparkContext(Utils.scala:1252)
	at org.apache.spark.ContextCleaner.org$apache$spark$ContextCleaner$$keepCleaning(ContextCleaner.scala:172)
	at org.apache.spark.ContextCleaner$$anon$1.run(ContextCleaner.scala:67)
Caused by: java.io.IOException: Connection reset by peer
	at sun.nio.ch.FileDispatcherImpl.read0(Native Method)
	at sun.nio.ch.SocketDispatcher.read(SocketDispatcher.java:39)
	at sun.nio.ch.IOUtil.readIntoNativeBuffer(IOUtil.java:223)
	at sun.nio.ch.IOUtil.read(IOUtil.java:192)
	at sun.nio.ch.SocketChannelImpl.read(SocketChannelImpl.java:380)
	at io.netty.buffer.PooledUnsafeDirectByteBuf.setBytes(PooledUnsafeDirectByteBuf.java:313)
	at io.netty.buffer.AbstractByteBuf.writeBytes(AbstractByteBuf.java:881)
	at io.netty.channel.socket.nio.NioSocketChannel.doReadBytes(NioSocketChannel.java:242)
	at io.netty.channel.nio.AbstractNioByteChannel$NioByteUnsafe.read(AbstractNioByteChannel.java:119)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:511)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
                                                                                Time elapsed: 19.514978714 seconds
res141: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 75  OR  partitionIndex = 90  OR  pa rtitionIndex = 91  OR  partitionIndex = 104  OR  partitionIndex = 105  OR  partitionIndex = 106  OR  partitionIndex  = 120  OR  partitionIndex = 121 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 75  OR  partitionIndex = 90  OR  partitionIndex = 91  OR  partitionIndex = 104  OR  partitionIndex = 105  OR  partitionIndex = 106  OR  partitionIndex = 120  OR  partitionIndex = 121 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046754257 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 140:================================================>      (56 + 8) / 64]                                                                                Time elapsed: 5.633522984 seconds
res143: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 46  OR  partitionIndex = 47  OR  pa rtitionIndex = 62  OR  partitionIndex = 63  OR  partitionIndex = 72  OR  partitionIndex = 73  OR  partitionIndex =  88  OR  partitionIndex = 89 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 46  OR  partitionIndex = 47  OR  partitionIndex = 62  OR  partitionIndex = 63  OR  partitionIndex = 72  OR  partitionIndex = 73  OR  partitionIndex = 88  OR  partitionIndex = 89 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047064759 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 142:=====================================================> (62 + 2) / 64]17/06/10 08:01:11 ERROR TaskSchedulerImpl: Lost executor 33 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:01:11 WARN TaskSetManager: Lost task 3.0 in stage 142.0 (TID 9183, 128.110.152.141): ExecutorLostFailure (executor 33 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:01:11 WARN TaskSetManager: Lost task 11.0 in stage 142.0 (TID 9191, 128.110.152.141): ExecutorLostFailure (executor 33 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 142:======================================================>(63 + 1) / 64]                                                                                [Stage 143:=============================================>        (55 + 10) / 65][Stage 143:=====================================================> (63 + 2) / 65][Stage 143:======================================================>(64 + 1) / 65]17/06/10 08:01:30 ERROR TaskSchedulerImpl: Lost executor 34 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:01:30 WARN TaskSetManager: Lost task 11.0 in stage 143.0 (TID 9257, 128.110.152.145): ExecutorLostFailure (executor 34 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:01:37 ERROR TaskSchedulerImpl: Lost executor 17 on 128.110.152.165: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:01:37 ERROR TransportResponseHandler: Still have 1 requests outstanding when connection from /128.110.152.165:41684 is closed
17/06/10 08:01:37 WARN TaskSetManager: Lost task 11.1 in stage 143.0 (TID 9311, 128.110.152.165): ExecutorLostFailure (executor 17 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:01:42 ERROR RetryingBlockFetcher: Exception while beginning fetch of 1 outstanding blocks (after 1 retries)
java.io.IOException: Failed to connect to /128.110.152.165:41684
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:228)
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:179)
	at org.apache.spark.network.netty.NettyBlockTransferService$$anon$1.createAndStart(NettyBlockTransferService.scala:96)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.fetchAllOutstanding(RetryingBlockFetcher.java:140)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.access$200(RetryingBlockFetcher.java:43)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher$1.run(RetryingBlockFetcher.java:170)
	at java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:511)
	at java.util.concurrent.FutureTask.run(FutureTask.java:266)
	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)
	at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:617)
	at java.lang.Thread.run(Thread.java:748)
Caused by: java.net.ConnectException: Connection refused: /128.110.152.165:41684
	at sun.nio.ch.SocketChannelImpl.checkConnect(Native Method)
	at sun.nio.ch.SocketChannelImpl.finishConnect(SocketChannelImpl.java:717)
	at io.netty.channel.socket.nio.NioSocketChannel.doFinishConnect(NioSocketChannel.java:224)
	at io.netty.channel.nio.AbstractNioChannel$AbstractNioUnsafe.finishConnect(AbstractNioChannel.java:289)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:528)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	... 1 more
17/06/10 08:01:47 ERROR TaskSchedulerImpl: Lost executor 35 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:01:47 WARN TaskSetManager: Lost task 11.2 in stage 143.0 (TID 9312, 128.110.152.141): ExecutorLostFailure (executor 35 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:01:47 ERROR RetryingBlockFetcher: Exception while beginning fetch of 1 outstanding blocks (after 2 retries)
java.io.IOException: Failed to connect to /128.110.152.165:41684
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:228)
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:179)
	at org.apache.spark.network.netty.NettyBlockTransferService$$anon$1.createAndStart(NettyBlockTransferService.scala:96)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.fetchAllOutstanding(RetryingBlockFetcher.java:140)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.access$200(RetryingBlockFetcher.java:43)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher$1.run(RetryingBlockFetcher.java:170)
	at java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:511)
	at java.util.concurrent.FutureTask.run(FutureTask.java:266)
	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)
	at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:617)
	at java.lang.Thread.run(Thread.java:748)
Caused by: java.net.ConnectException: Connection refused: /128.110.152.165:41684
	at sun.nio.ch.SocketChannelImpl.checkConnect(Native Method)
	at sun.nio.ch.SocketChannelImpl.finishConnect(SocketChannelImpl.java:717)
	at io.netty.channel.socket.nio.NioSocketChannel.doFinishConnect(NioSocketChannel.java:224)
	at io.netty.channel.nio.AbstractNioChannel$AbstractNioUnsafe.finishConnect(AbstractNioChannel.java:289)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:528)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	... 1 more
17/06/10 08:01:52 ERROR RetryingBlockFetcher: Exception while beginning fetch of 1 outstanding blocks (after 3 retries)
java.io.IOException: Failed to connect to /128.110.152.165:41684
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:228)
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:179)
	at org.apache.spark.network.netty.NettyBlockTransferService$$anon$1.createAndStart(NettyBlockTransferService.scala:96)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.fetchAllOutstanding(RetryingBlockFetcher.java:140)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.access$200(RetryingBlockFetcher.java:43)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher$1.run(RetryingBlockFetcher.java:170)
	at java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:511)
	at java.util.concurrent.FutureTask.run(FutureTask.java:266)
	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)
	at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:617)
	at java.lang.Thread.run(Thread.java:748)
Caused by: java.net.ConnectException: Connection refused: /128.110.152.165:41684
	at sun.nio.ch.SocketChannelImpl.checkConnect(Native Method)
	at sun.nio.ch.SocketChannelImpl.finishConnect(SocketChannelImpl.java:717)
	at io.netty.channel.socket.nio.NioSocketChannel.doFinishConnect(NioSocketChannel.java:224)
	at io.netty.channel.nio.AbstractNioChannel$AbstractNioUnsafe.finishConnect(AbstractNioChannel.java:289)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:528)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	... 1 more
17/06/10 08:01:52 WARN BlockManager: Failed to fetch block after 1 fetch failures. Most recent failure cause:
org.apache.spark.SparkException: Exception thrown in awaitResult: 
	at org.apache.spark.util.ThreadUtils$.awaitResult(ThreadUtils.scala:194)
	at org.apache.spark.network.BlockTransferService.fetchBlockSync(BlockTransferService.scala:104)
	at org.apache.spark.storage.BlockManager.getRemoteBytes(BlockManager.scala:555)
	at org.apache.spark.scheduler.TaskResultGetter$$anon$2$$anonfun$run$1.apply$mcV$sp(TaskResultGetter.scala:76)
	at org.apache.spark.scheduler.TaskResultGetter$$anon$2$$anonfun$run$1.apply(TaskResultGetter.scala:57)
	at org.apache.spark.scheduler.TaskResultGetter$$anon$2$$anonfun$run$1.apply(TaskResultGetter.scala:57)
	at org.apache.spark.util.Utils$.logUncaughtExceptions(Utils.scala:1953)
	at org.apache.spark.scheduler.TaskResultGetter$$anon$2.run(TaskResultGetter.scala:56)
	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)
	at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:617)
	at java.lang.Thread.run(Thread.java:748)
Caused by: java.io.IOException: Failed to connect to /128.110.152.165:41684
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:228)
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:179)
	at org.apache.spark.network.netty.NettyBlockTransferService$$anon$1.createAndStart(NettyBlockTransferService.scala:96)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.fetchAllOutstanding(RetryingBlockFetcher.java:140)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.access$200(RetryingBlockFetcher.java:43)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher$1.run(RetryingBlockFetcher.java:170)
	at java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:511)
	at java.util.concurrent.FutureTask.run(FutureTask.java:266)
	... 3 more
Caused by: java.net.ConnectException: Connection refused: /128.110.152.165:41684
	at sun.nio.ch.SocketChannelImpl.checkConnect(Native Method)
	at sun.nio.ch.SocketChannelImpl.finishConnect(SocketChannelImpl.java:717)
	at io.netty.channel.socket.nio.NioSocketChannel.doFinishConnect(NioSocketChannel.java:224)
	at io.netty.channel.nio.AbstractNioChannel$AbstractNioUnsafe.finishConnect(AbstractNioChannel.java:289)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:528)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	... 1 more
                                                                                Time elapsed: 50.967290643 seconds
res145: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 135  OR  partitionIndex = 150  OR   partitionIndex = 151  OR  partitionIndex = 164  OR  partitionIndex = 165  OR  partitionIndex = 166  OR  partitionIn dex = 180  OR  partitionIndex = 181 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 135  OR  partitionIndex = 150  OR  partitionIndex = 151  OR  partitionIndex = 164  OR  partitionIndex = 165  OR  partitionIndex = 166  OR  partitionIndex = 180  OR  partitionIndex = 181 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050844116 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 144:=================================>                    (40 + 24) / 64][Stage 144:================================================>      (56 + 8) / 64]                                                                                Time elapsed: 5.777005104 seconds
res147: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 160  OR  partitionIndex = 161  OR   partitionIndex = 162  OR  partitionIndex = 163  OR  partitionIndex = 176  OR  partitionIndex = 177  OR  partitionIn dex = 178  OR  partitionIndex = 179 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 160  OR  partitionIndex = 161  OR  partitionIndex = 162  OR  partitionIndex = 163  OR  partitionIndex = 176  OR  partitionIndex = 177  OR  partitionIndex = 178  OR  partitionIndex = 179 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047998783 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.821211426 seconds
res149: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 194  OR  partitionIndex = 195  OR   partitionIndex = 208  OR  partitionIndex = 209  OR  partitionIndex = 210  OR  partitionIndex = 211  OR  partitionIn dex = 224  OR  partitionIndex = 225 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 194  OR  partitionIndex = 195  OR  partitionIndex = 208  OR  partitionIndex = 209  OR  partitionIndex = 210  OR  partitionIndex = 211  OR  partitionIndex = 224  OR  partitionIndex = 225 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047201699 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.69931894 seconds
res151: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 130  OR  partitionIndex = 131  OR   partitionIndex = 146  OR  partitionIndex = 147  OR  partitionIndex = 160  OR  partitionIndex = 161  OR  partitionIn dex = 176  OR  partitionIndex = 177 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 130  OR  partitionIndex = 131  OR  partitionIndex = 146  OR  partitionIndex = 147  OR  partitionIndex = 160  OR  partitionIndex = 161  OR  partitionIndex = 176  OR  partitionIndex = 177 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04522749 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 150:=====================================================> (62 + 2) / 64][Stage 150:======================================================>(63 + 1) / 64]                                                                                [Stage 151:=====================================================> (63 + 2) / 65][Stage 151:======================================================>(64 + 1) / 65]17/06/10 08:02:27 ERROR TaskSchedulerImpl: Lost executor 38 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:02:27 WARN TaskSetManager: Lost task 24.0 in stage 151.0 (TID 9789, 128.110.152.141): ExecutorLostFailure (executor 38 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 24.471004938 seconds
res153: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 110  OR  partitionIndex = 111  OR   partitionIndex = 124  OR  partitionIndex = 125  OR  partitionIndex = 126  OR  partitionIndex = 127  OR  partitionIn dex = 128  OR  partitionIndex = 129 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 110  OR  partitionIndex = 111  OR  partitionIndex = 124  OR  partitionIndex = 125  OR  partitionIndex = 126  OR  partitionIndex = 127  OR  partitionIndex = 128  OR  partitionIndex = 129 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052108001 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 152:===============================================>       (55 + 9) / 64][Stage 152:======================================================>(63 + 1) / 64]17/06/10 08:02:48 ERROR TaskSchedulerImpl: Lost executor 30 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:02:48 WARN TaskSetManager: Lost task 23.0 in stage 152.0 (TID 9854, 128.110.152.168): ExecutorLostFailure (executor 30 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 153:===============================================>       (56 + 9) / 65][Stage 153:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 28.224880104 seconds
res155: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 2  OR  partitionIndex = 3  OR  part itionIndex = 18  OR  partitionIndex = 19  OR  partitionIndex = 32  OR  partitionIndex = 33  OR  partitionIndex = 48   OR  partitionIndex = 49 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 2  OR  partitionIndex = 3  OR  partitionIndex = 18  OR  partitionIndex = 19  OR  partitionIndex = 32  OR  partitionIndex = 33  OR  partitionIndex = 48  OR  partitionIndex = 49 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051686438 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 154:=====================================================> (62 + 2) / 64][Stage 154:======================================================>(63 + 1) / 64]                                                                                [Stage 155:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 12.300575707 seconds
res157: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 131  OR  partitionIndex = 146  OR   partitionIndex = 147  OR  partitionIndex = 160  OR  partitionIndex = 161  OR  partitionIndex = 162  OR  partitionIn dex = 176  OR  partitionIndex = 177 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 131  OR  partitionIndex = 146  OR  partitionIndex = 147  OR  partitionIndex = 160  OR  partitionIndex = 161  OR  partitionIndex = 162  OR  partitionIndex = 176  OR  partitionIndex = 177 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049562369 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 156:=====================================================> (62 + 2) / 64]                                                                                [Stage 157:=====================================================> (63 + 2) / 65][Stage 157:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.896480254 seconds
res159: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 12  OR  partitionIndex = 13  OR  pa rtitionIndex = 28  OR  partitionIndex = 42  OR  partitionIndex = 43  OR  partitionIndex = 57  OR  partitionIndex =  58  OR  partitionIndex = 59 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 12  OR  partitionIndex = 13  OR  partitionIndex = 28  OR  partitionIndex = 42  OR  partitionIndex = 43  OR  partitionIndex = 57  OR  partitionIndex = 58  OR  partitionIndex = 59 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049032465 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 158:===================================================>   (60 + 4) / 64][Stage 158:====================================================>  (61 + 3) / 64][Stage 158:=====================================================> (62 + 2) / 64][Stage 158:======================================================>(63 + 1) / 64]                                                                                [Stage 159:===================================================>   (61 + 4) / 65][Stage 159:====================================================>  (62 + 3) / 65][Stage 159:=====================================================> (63 + 2) / 65][Stage 159:======================================================>(64 + 1) / 65]17/06/10 08:03:53 ERROR TaskSetManager: Total size of serialized results of 65 tasks (531.1 MB) is bigger than spark.driver.maxResultSize (512.0 MB)
org.apache.spark.SparkException: Job aborted due to stage failure: Total size of serialized results of 65 tasks (531.1 MB) is bigger than spark.driver.maxResultSize (512.0 MB)
  at org.apache.spark.scheduler.DAGScheduler.org$apache$spark$scheduler$DAGScheduler$$failJobAndIndependentStages(DAGScheduler.scala:1454)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$abortStage$1.apply(DAGScheduler.scala:1442)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$abortStage$1.apply(DAGScheduler.scala:1441)
  at scala.collection.mutable.ResizableArray$class.foreach(ResizableArray.scala:59)
  at scala.collection.mutable.ArrayBuffer.foreach(ArrayBuffer.scala:48)
  at org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:1441)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$handleTaskSetFailed$1.apply(DAGScheduler.scala:811)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$handleTaskSetFailed$1.apply(DAGScheduler.scala:811)
  at scala.Option.foreach(Option.scala:257)
  at org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:811)
  at org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:1667)
  at org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:1622)
  at org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:1611)
  at org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:48)
  at org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:632)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1873)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1886)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1899)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1913)
  at org.apache.spark.rdd.RDD$$anonfun$collect$1.apply(RDD.scala:912)
  at org.apache.spark.rdd.RDDOperationScope$.withScope(RDDOperationScope.scala:151)
  at org.apache.spark.rdd.RDDOperationScope$.withScope(RDDOperationScope.scala:112)
  at org.apache.spark.rdd.RDD.withScope(RDD.scala:358)
  at org.apache.spark.rdd.RDD.collect(RDD.scala:911)
  at $anonfun$1.apply$mcI$sp(<console>:38)
  at $anonfun$1.apply(<console>:38)
  at $anonfun$1.apply(<console>:38)
  at show_timing(<console>:30)
  ... 50 elided

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 87  OR  partitionIndex = 100  OR  p artitionIndex = 101  OR  partitionIndex = 102  OR  partitionIndex = 103  OR  partitionIndex = 116  OR  partitionInd ex = 117  OR  partitionIndex = 118 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 87  OR  partitionIndex = 100  OR  partitionIndex = 101  OR  partitionIndex = 102  OR  partitionIndex = 103  OR  partitionIndex = 116  OR  partitionIndex = 117  OR  partitionIndex = 118 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047955221 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 160:=====================================================> (62 + 2) / 64][Stage 160:======================================================>(63 + 1) / 64]17/06/10 08:04:09 ERROR TaskSchedulerImpl: Lost executor 36 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:04:09 WARN TaskSetManager: Lost task 20.0 in stage 160.0 (TID 10368, 128.110.152.145): ExecutorLostFailure (executor 36 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 161:=============================================>        (55 + 10) / 65][Stage 161:=====================================================> (63 + 2) / 65]                                                                                Time elapsed: 32.478751887 seconds
res163: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 74  OR  partitionIndex = 75  OR  pa rtitionIndex = 88  OR  partitionIndex = 89  OR  partitionIndex = 90  OR  partitionIndex = 91  OR  partitionIndex =  104  OR  partitionIndex = 105 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 74  OR  partitionIndex = 75  OR  partitionIndex = 88  OR  partitionIndex = 89  OR  partitionIndex = 90  OR  partitionIndex = 91  OR  partitionIndex = 104  OR  partitionIndex = 105 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048346101 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.753853095 seconds
res165: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 4  OR  partitionIndex = 5  OR  part itionIndex = 6  OR  partitionIndex = 20  OR  partitionIndex = 21  OR  partitionIndex = 35  OR  partitionIndex = 50   OR  partitionIndex = 51 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 4  OR  partitionIndex = 5  OR  partitionIndex = 6  OR  partitionIndex = 20  OR  partitionIndex = 21  OR  partitionIndex = 35  OR  partitionIndex = 50  OR  partitionIndex = 51 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056471739 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 164:===================================================>   (60 + 4) / 64][Stage 164:====================================================>  (61 + 3) / 64][Stage 164:=====================================================> (62 + 2) / 64][Stage 164:======================================================>(63 + 1) / 64]                                                                                [Stage 165:==================================================>    (60 + 5) / 65][Stage 165:===================================================>   (61 + 4) / 65][Stage 165:====================================================>  (62 + 3) / 65][Stage 165:=====================================================> (63 + 2) / 65][Stage 165:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.919613985 seconds
res167: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 39  OR  partitionIndex = 54  OR  pa rtitionIndex = 55  OR  partitionIndex = 64  OR  partitionIndex = 65  OR  partitionIndex = 66  OR  partitionIndex =  80  OR  partitionIndex = 81 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 39  OR  partitionIndex = 54  OR  partitionIndex = 55  OR  partitionIndex = 64  OR  partitionIndex = 65  OR  partitionIndex = 66  OR  partitionIndex = 80  OR  partitionIndex = 81 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049849449 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 166:=====================================================> (62 + 2) / 64][Stage 166:======================================================>(63 + 1) / 64]                                                                                [Stage 167:=====================================================> (63 + 2) / 65][Stage 167:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 16.969650705 seconds
res169: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 191  OR  partitionIndex = 200  OR   partitionIndex = 201  OR  partitionIndex = 202  OR  partitionIndex = 203  OR  partitionIndex = 216  OR  partitionIn dex = 217  OR  partitionIndex = 218 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 191  OR  partitionIndex = 200  OR  partitionIndex = 201  OR  partitionIndex = 202  OR  partitionIndex = 203  OR  partitionIndex = 216  OR  partitionIndex = 217  OR  partitionIndex = 218 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049545406 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 168:>                                                       (0 + 0) / 64][Stage 168:=====================================================> (62 + 2) / 64][Stage 168:======================================================>(63 + 1) / 64]                                                                                [Stage 169:=====================================================> (63 + 2) / 65]17/06/10 08:05:21 ERROR TaskSchedulerImpl: Lost executor 39 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:05:21 WARN TaskSetManager: Lost task 48.0 in stage 169.0 (TID 10977, 128.110.152.141): ExecutorLostFailure (executor 39 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:05:22 ERROR TaskSchedulerImpl: Lost executor 23 on 128.110.152.157: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:05:22 WARN TaskSetManager: Lost task 48.1 in stage 169.0 (TID 10994, 128.110.152.157): ExecutorLostFailure (executor 23 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 169:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 19.500450044 seconds
res171: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 196  OR  partitionIndex = 197  OR   partitionIndex = 212  OR  partitionIndex = 226  OR  partitionIndex = 227  OR  partitionIndex = 241  OR  partitionIn dex = 242  OR  partitionIndex = 243 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 196  OR  partitionIndex = 197  OR  partitionIndex = 212  OR  partitionIndex = 226  OR  partitionIndex = 227  OR  partitionIndex = 241  OR  partitionIndex = 242  OR  partitionIndex = 243 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053550145 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 170:========================================>             (48 + 16) / 64]                                                                                Time elapsed: 5.786306253 seconds
res173: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68  OR  partitionIndex = 97  OR  pa rtitionIndex = 98  OR  partitionIndex = 99  OR  partitionIndex = 112  OR  partitionIndex = 113  OR  partitionIndex  = 114  OR  partitionIndex = 115 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68  OR  partitionIndex = 97  OR  partitionIndex = 98  OR  partitionIndex = 99  OR  partitionIndex = 112  OR  partitionIndex = 113  OR  partitionIndex = 114  OR  partitionIndex = 115 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045408707 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 172:==========================================>           (50 + 14) / 64]                                                                                Time elapsed: 0.9123747 seconds
res175: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 138  OR  partitionIndex = 139  OR   partitionIndex = 153  OR  partitionIndex = 154  OR  partitionIndex = 155  OR  partitionIndex = 168  OR  partitionIn dex = 169  OR  partitionIndex = 184 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 138  OR  partitionIndex = 139  OR  partitionIndex = 153  OR  partitionIndex = 154  OR  partitionIndex = 155  OR  partitionIndex = 168  OR  partitionIndex = 169  OR  partitionIndex = 184 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05694628 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 174:=====================================================> (62 + 2) / 64][Stage 174:======================================================>(63 + 1) / 64]                                                                                [Stage 175:=====================================================> (63 + 2) / 65]                                                                                Time elapsed: 15.684200294 seconds
res177: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 183  OR  partitionIndex = 192  OR   partitionIndex = 193  OR  partitionIndex = 194  OR  partitionIndex = 195  OR  partitionIndex = 208  OR  partitionIn dex = 209  OR  partitionIndex = 210 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 183  OR  partitionIndex = 192  OR  partitionIndex = 193  OR  partitionIndex = 194  OR  partitionIndex = 195  OR  partitionIndex = 208  OR  partitionIndex = 209  OR  partitionIndex = 210 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046994774 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 176:=====================================================> (62 + 2) / 64][Stage 176:======================================================>(63 + 1) / 64]                                                                                [Stage 177:=====================================================> (63 + 2) / 65][Stage 177:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 14.319995257 seconds
res179: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68  OR  partitionIndex = 69  OR  pa rtitionIndex = 84  OR  partitionIndex = 98  OR  partitionIndex = 99  OR  partitionIndex = 113  OR  partitionIndex =  114  OR  partitionIndex = 115 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68  OR  partitionIndex = 69  OR  partitionIndex = 84  OR  partitionIndex = 98  OR  partitionIndex = 99  OR  partitionIndex = 113  OR  partitionIndex = 114  OR  partitionIndex = 115 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046458011 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 178:=====================================================> (62 + 2) / 64][Stage 178:======================================================>(63 + 1) / 64]                                                                                [Stage 179:=====================================================> (63 + 2) / 65]17/06/10 08:06:34 ERROR TaskSchedulerImpl: Lost executor 29 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:06:34 WARN TaskSetManager: Lost task 11.0 in stage 179.0 (TID 11587, 128.110.152.142): ExecutorLostFailure (executor 29 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 179:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 27.703677074 seconds
res181: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 30  OR  partitionIndex = 31  OR  pa rtitionIndex = 44  OR  partitionIndex = 45  OR  partitionIndex = 46  OR  partitionIndex = 47  OR  partitionIndex =  60  OR  partitionIndex = 61 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 30  OR  partitionIndex = 31  OR  partitionIndex = 44  OR  partitionIndex = 45  OR  partitionIndex = 46  OR  partitionIndex = 47  OR  partitionIndex = 60  OR  partitionIndex = 61 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050997911 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 180:=============================================>        (54 + 10) / 64][Stage 180:=====================================================> (62 + 2) / 64][Stage 180:======================================================>(63 + 1) / 64]                                                                                [Stage 181:=====================================================> (63 + 2) / 65][Stage 181:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.598903307 seconds
res183: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 37  OR  partitionIndex = 38  OR  pa rtitionIndex = 39  OR  partitionIndex = 52  OR  partitionIndex = 53  OR  partitionIndex = 54  OR  partitionIndex =  55  OR  partitionIndex = 64 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 37  OR  partitionIndex = 38  OR  partitionIndex = 39  OR  partitionIndex = 52  OR  partitionIndex = 53  OR  partitionIndex = 54  OR  partitionIndex = 55  OR  partitionIndex = 64 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048758541 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 182:=====================================================> (62 + 2) / 64][Stage 182:======================================================>(63 + 1) / 64]17/06/10 08:07:14 ERROR TaskSchedulerImpl: Lost executor 42 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:07:14 WARN TaskSetManager: Lost task 0.0 in stage 182.0 (TID 11771, 128.110.152.141): ExecutorLostFailure (executor 42 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 183:===============================================>       (56 + 9) / 65][Stage 183:=====================================================> (63 + 2) / 65][Stage 183:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 31.309898716 seconds
res185: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 70  OR  partitionIndex = 71  OR  pa rtitionIndex = 84  OR  partitionIndex = 85  OR  partitionIndex = 86  OR  partitionIndex = 87  OR  partitionIndex =  100  OR  partitionIndex = 101 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 70  OR  partitionIndex = 71  OR  partitionIndex = 84  OR  partitionIndex = 85  OR  partitionIndex = 86  OR  partitionIndex = 87  OR  partitionIndex = 100  OR  partitionIndex = 101 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053504342 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 184:======================================================>(63 + 1) / 64]                                                                                [Stage 185:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 18.560253542 seconds
res187: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 204  OR  partitionIndex = 205  OR   partitionIndex = 220  OR  partitionIndex = 234  OR  partitionIndex = 235  OR  partitionIndex = 249  OR  partitionIn dex = 250  OR  partitionIndex = 251 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 204  OR  partitionIndex = 205  OR  partitionIndex = 220  OR  partitionIndex = 234  OR  partitionIndex = 235  OR  partitionIndex = 249  OR  partitionIndex = 250  OR  partitionIndex = 251 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048677902 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 186:=====================================================> (62 + 2) / 64][Stage 186:======================================================>(63 + 1) / 64]                                                                                [Stage 187:=====================================================> (63 + 2) / 65][Stage 187:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 18.556600009 seconds
res189: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 66  OR  partitionIndex = 67  OR  pa rtitionIndex = 81  OR  partitionIndex = 82  OR  partitionIndex = 83  OR  partitionIndex = 96  OR  partitionIndex =  97  OR  partitionIndex = 112 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 66  OR  partitionIndex = 67  OR  partitionIndex = 81  OR  partitionIndex = 82  OR  partitionIndex = 83  OR  partitionIndex = 96  OR  partitionIndex = 97  OR  partitionIndex = 112 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053834103 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 188:=====================================================> (62 + 2) / 64][Stage 188:======================================================>(63 + 1) / 64]17/06/10 08:08:29 ERROR TaskSchedulerImpl: Lost executor 40 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:08:29 WARN TaskSetManager: Lost task 11.0 in stage 188.0 (TID 12170, 128.110.152.168): ExecutorLostFailure (executor 40 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 189:=============================================>        (55 + 10) / 65][Stage 189:=====================================================> (63 + 2) / 65][Stage 189:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 27.140660506 seconds
res191: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 142  OR  partitionIndex = 143  OR   partitionIndex = 156  OR  partitionIndex = 157  OR  partitionIndex = 158  OR  partitionIndex = 159  OR  partitionIn dex = 172  OR  partitionIndex = 173 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 142  OR  partitionIndex = 143  OR  partitionIndex = 156  OR  partitionIndex = 157  OR  partitionIndex = 158  OR  partitionIndex = 159  OR  partitionIndex = 172  OR  partitionIndex = 173 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054731647 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 08:08:49 ERROR TaskSchedulerImpl: Lost executor 45 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:08:49 WARN TaskSetManager: Lost task 40.0 in stage 190.0 (TID 12329, 128.110.152.141): ExecutorLostFailure (executor 45 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:08:49 WARN TaskSetManager: Lost task 16.0 in stage 190.0 (TID 12305, 128.110.152.141): ExecutorLostFailure (executor 45 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:08:49 WARN TaskSetManager: Lost task 48.0 in stage 190.0 (TID 12337, 128.110.152.141): ExecutorLostFailure (executor 45 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:08:49 WARN TaskSetManager: Lost task 24.0 in stage 190.0 (TID 12313, 128.110.152.141): ExecutorLostFailure (executor 45 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:08:49 WARN TaskSetManager: Lost task 0.0 in stage 190.0 (TID 12289, 128.110.152.141): ExecutorLostFailure (executor 45 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 190:=====================================================> (62 + 2) / 64][Stage 190:======================================================>(63 + 1) / 64]                                                                                [Stage 191:===============================================>       (56 + 9) / 65][Stage 191:=====================================================> (63 + 2) / 65][Stage 191:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 20.073968337 seconds
res193: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 202  OR  partitionIndex = 203  OR   partitionIndex = 216  OR  partitionIndex = 217  OR  partitionIndex = 218  OR  partitionIndex = 219  OR  partitionIn dex = 232  OR  partitionIndex = 233 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 202  OR  partitionIndex = 203  OR  partitionIndex = 216  OR  partitionIndex = 217  OR  partitionIndex = 218  OR  partitionIndex = 219  OR  partitionIndex = 232  OR  partitionIndex = 233 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047828419 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 192:=====================================================> (62 + 2) / 64][Stage 192:======================================================>(63 + 1) / 64]                                                                                [Stage 193:=====================================================> (63 + 2) / 65][Stage 193:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 17.837721314 seconds
res195: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 205  OR  partitionIndex = 206  OR   partitionIndex = 207  OR  partitionIndex = 220  OR  partitionIndex = 221  OR  partitionIndex = 222  OR  partitionIn dex = 223  OR  partitionIndex = 236 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 205  OR  partitionIndex = 206  OR  partitionIndex = 207  OR  partitionIndex = 220  OR  partitionIndex = 221  OR  partitionIndex = 222  OR  partitionIndex = 223  OR  partitionIndex = 236 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.044460584 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.650519238 seconds
res197: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 5  OR  partitionIndex = 6  OR  part itionIndex = 7  OR  partitionIndex = 20  OR  partitionIndex = 21  OR  partitionIndex = 22  OR  partitionIndex = 23   OR  partitionIndex = 36 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 5  OR  partitionIndex = 6  OR  partitionIndex = 7  OR  partitionIndex = 20  OR  partitionIndex = 21  OR  partitionIndex = 22  OR  partitionIndex = 23  OR  partitionIndex = 36 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045614829 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 08:09:33 ERROR TaskSchedulerImpl: Lost executor 47 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:09:33 WARN TaskSetManager: Lost task 22.0 in stage 196.0 (TID 12703, 128.110.152.141): ExecutorLostFailure (executor 47 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:09:33 WARN TaskSetManager: Lost task 54.0 in stage 196.0 (TID 12735, 128.110.152.141): ExecutorLostFailure (executor 47 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:09:33 WARN TaskSetManager: Lost task 6.0 in stage 196.0 (TID 12687, 128.110.152.141): ExecutorLostFailure (executor 47 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:09:33 WARN TaskSetManager: Lost task 62.0 in stage 196.0 (TID 12743, 128.110.152.141): ExecutorLostFailure (executor 47 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:09:33 WARN TaskSetManager: Lost task 14.0 in stage 196.0 (TID 12695, 128.110.152.141): ExecutorLostFailure (executor 47 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 196:====================================================>  (61 + 3) / 64][Stage 196:=====================================================> (62 + 2) / 64][Stage 196:======================================================>(63 + 1) / 64]                                                                                [Stage 197:============================================>         (54 + 11) / 65][Stage 197:=============================================>        (55 + 10) / 65][Stage 197:===============================================>       (56 + 9) / 65][Stage 197:======================================================>(64 + 1) / 65]17/06/10 08:09:45 ERROR TaskSchedulerImpl: Lost executor 28 on 128.110.152.152: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:09:45 WARN TaskSetManager: Lost task 9.0 in stage 197.0 (TID 12759, 128.110.152.152): ExecutorLostFailure (executor 28 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 22.426790943 seconds
res199: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 8  OR  partitionIndex = 9  OR  part itionIndex = 10  OR  partitionIndex = 24  OR  partitionIndex = 25  OR  partitionIndex = 103  OR  partitionIndex = 1 18  OR  partitionIndex = 119 ", 8))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 8  OR  partitionIndex = 9  OR  partitionIndex = 10  OR  partitionIndex = 24  OR  partitionIndex = 25  OR  partitionIndex = 103  OR  partitionIndex = 118  OR  partitionIndex = 119 ",8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051066371 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 198:===========================================>          (51 + 13) / 64][Stage 198:===========================================>          (52 + 12) / 64][Stage 198:============================================>         (53 + 11) / 64][Stage 198:====================================================>  (61 + 3) / 64]17/06/10 08:10:04 ERROR TaskSchedulerImpl: Lost executor 48 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:10:04 WARN TaskSetManager: Lost task 24.0 in stage 198.0 (TID 12840, 128.110.152.141): ExecutorLostFailure (executor 48 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:10:04 WARN TaskSetManager: Lost task 0.0 in stage 198.0 (TID 12816, 128.110.152.141): ExecutorLostFailure (executor 48 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 198:=====================================================> (62 + 2) / 64][Stage 198:======================================================>(63 + 1) / 64]                                                                                [Stage 199:============================================>         (53 + 12) / 65][Stage 199:============================================>         (54 + 11) / 65][Stage 199:===================================================>   (61 + 4) / 65][Stage 199:====================================================>  (62 + 3) / 65][Stage 199:=====================================================> (63 + 2) / 65][Stage 199:======================================================>(64 + 1) / 65]17/06/10 08:10:20 ERROR TaskSchedulerImpl: Lost executor 41 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:10:20 WARN TaskSetManager: Lost task 11.0 in stage 199.0 (TID 12893, 128.110.152.145): ExecutorLostFailure (executor 41 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 30.990875655 seconds
res201: Int = 0

scala> 

scala> :quit
