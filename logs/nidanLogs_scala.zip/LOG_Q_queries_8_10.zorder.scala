Using Spark's default log4j profile: org/apache/spark/log4j-defaults.properties
Setting default log level to "WARN".
To adjust logging level use sc.setLogLevel(newLevel).
17/06/10 08:10:49 WARN NativeCodeLoader: Unable to load native-hadoop library for your platform... using builtin-java classes where applicable
17/06/10 08:10:52 WARN SparkContext: Use an existing SparkContext, some configuration may not take effect.
Spark context Web UI available at http://128.110.152.156:4040
Spark context available as 'sc' (master = spark://ctl:7077, app id = app-20170610081051-0064).
Spark session available as 'spark'.
Welcome to
      ____              __
     / __/__  ___ _____/ /__
    _\ \/ _ \/ _ `/ __/  '_/
   /___/ .__/\_,_/_/ /_/\_\   version 2.0.2
      /_/
         
Using Scala version 2.11.8 (OpenJDK 64-Bit Server VM, Java 1.8.0_131)
Type in expressions to have them evaluated.
Type :help for more information.

scala>  
     | import java.io.File
import java.io.File

scala> import java.io.FileOutputStream
import java.io.FileOutputStream

scala> import org.apache.spark.sql._
import org.apache.spark.sql._

scala> 

scala> def show_timing[T](proc: => T): T = {
     |     val start=System.nanoTime()
     |     val res = proc
     |     val end = System.nanoTime()
     |     println("Time elapsed: " + (end-start)/1000000000.0 + " seconds")
     |     res
     | }
show_timing: [T](proc: => T)T

scala> 

scala> val writeToLocal = (in:(Array[Byte], Long, String)) =>{
     |     val bytes = in._1
     |     val output = in._3
     |     
     |     val writer = new FileOutputStream(output)
     |     writer.write(bytes)
     |     writer.close
     |     1
     |   }
writeToLocal: ((Array[Byte], Long, String)) => Int = <function1>

scala> 

scala> val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)
warning: there was one deprecation warning; re-run with -deprecation for details
sqlContext: org.apache.spark.sql.hive.HiveContext = org.apache.spark.sql.hive.HiveContext@4bdb04c8

scala>   
     | val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=166 AND partitionZIndex<=173", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=166 AND partitionZIndex<=173,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 15.592324782 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 0:>                                                        (0 + 64) / 64][Stage 0:=====================>                                  (24 + 40) / 64][Stage 0:======================================================>  (61 + 3) / 64][Stage 0:=======================================================> (62 + 2) / 64][Stage 0:========================================================>(63 + 1) / 64]                                                                                [Stage 1:======================================================>  (62 + 3) / 65]17/06/10 08:11:47 ERROR TaskSchedulerImpl: Lost executor 5 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:11:47 WARN TaskSetManager: Lost task 48.0 in stage 1.0 (TID 112, 128.110.152.141): ExecutorLostFailure (executor 5 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:11:47 WARN TaskSetManager: Lost task 24.0 in stage 1.0 (TID 88, 128.110.152.141): ExecutorLostFailure (executor 5 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 1:=======================================================> (63 + 1) / 65][Stage 1:=======================================================> (63 + 2) / 65][Stage 1:========================================================>(64 + 1) / 65]                                                                                Time elapsed: 30.11628289 seconds
res3: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=9 AND partitionZIndex<=16", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=9 AND partitionZIndex<=16,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.135473178 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 2:==============================================>         (53 + 11) / 64][Stage 2:===============================================>        (54 + 10) / 64][Stage 2:================================================>        (55 + 9) / 64][Stage 2:========================================================>(63 + 1) / 64]                                                                                [Stage 3:=======================================================> (63 + 2) / 65][Stage 3:========================================================>(64 + 1) / 65]                                                                                Time elapsed: 14.797252377 seconds
res5: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=128 AND partitionZIndex<=135", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=128 AND partitionZIndex<=135,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.149526736 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 4:========================================================>(63 + 1) / 64]                                                                                [Stage 5:========================================================>(64 + 1) / 65]                                                                                Time elapsed: 22.891334262 seconds
res7: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=247 AND partitionZIndex<=254", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=247 AND partitionZIndex<=254,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.113907629 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 6:========================================================>(63 + 1) / 64]                                                                                [Stage 7:========================================================>(64 + 1) / 65]                                                                                Time elapsed: 17.710153259 seconds
res9: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=55 AND partitionZIndex<=62", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=55 AND partitionZIndex<=62,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.126248279 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 8:======================================================>  (61 + 3) / 64][Stage 8:=======================================================> (62 + 2) / 64][Stage 8:========================================================>(63 + 1) / 64]                                                                                [Stage 9:======================================================>  (62 + 3) / 65][Stage 9:=======================================================> (63 + 2) / 65][Stage 9:========================================================>(64 + 1) / 65]                                                                                Time elapsed: 17.589833268 seconds
res11: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=95 AND partitionZIndex<=102", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=95 AND partitionZIndex<=102,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.105762775 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.872993008 seconds
res13: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=142 AND partitionZIndex<=149", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=142 AND partitionZIndex<=149,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.112932304 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 12:======================================================> (62 + 2) / 64][Stage 12:=======================================================>(63 + 1) / 64]                                                                                [Stage 13:======================================================> (63 + 2) / 65][Stage 13:=======================================================>(64 + 1) / 65]17/06/10 08:13:51 ERROR TaskSchedulerImpl: Lost executor 8 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:13:51 WARN TaskSetManager: Lost task 24.0 in stage 13.0 (TID 864, 128.110.152.141): ExecutorLostFailure (executor 8 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 29.058232215 seconds
res15: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=159 AND partitionZIndex<=166", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=159 AND partitionZIndex<=166,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.118915329 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 14:=================================================>      (56 + 8) / 64]                                                                                Time elapsed: 5.897632506 seconds
res17: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=1 AND partitionZIndex<=8", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=1 AND partitionZIndex<=8,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.078369862 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 16:=======================================================>(63 + 1) / 64]                                                                                [Stage 17:======================================================> (63 + 2) / 65][Stage 17:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 12.909398343 seconds
res19: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=209 AND partitionZIndex<=216", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=209 AND partitionZIndex<=216,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.08772236 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 18:=====================================================>  (61 + 3) / 64][Stage 18:======================================================> (62 + 2) / 64][Stage 18:=======================================================>(63 + 1) / 64]                                                                                [Stage 19:=====================================================>  (62 + 3) / 65][Stage 19:======================================================> (63 + 2) / 65][Stage 19:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.618582518 seconds
res21: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=151 AND partitionZIndex<=158", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=151 AND partitionZIndex<=158,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.073801662 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 20:>                                                        (0 + 0) / 64][Stage 20:======================================================> (62 + 2) / 64][Stage 20:=======================================================>(63 + 1) / 64]17/06/10 08:14:55 ERROR TaskSchedulerImpl: Lost executor 3 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:14:55 WARN TaskSetManager: Lost task 20.0 in stage 20.0 (TID 1313, 128.110.152.168): ExecutorLostFailure (executor 3 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 21:==============================================>        (55 + 10) / 65][Stage 21:======================================================> (63 + 2) / 65][Stage 21:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 29.464299701 seconds
res23: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=114 AND partitionZIndex<=121", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=114 AND partitionZIndex<=121,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.104202586 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 1.050076979 seconds
res25: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=116 AND partitionZIndex<=123", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=116 AND partitionZIndex<=123,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.115747874 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 24:======================================================> (62 + 2) / 64][Stage 24:=======================================================>(63 + 1) / 64]                                                                                [Stage 25:================================================>       (56 + 9) / 65][Stage 25:=================================================>      (57 + 8) / 65][Stage 25:======================================================> (63 + 2) / 65]17/06/10 08:15:53 ERROR TaskSchedulerImpl: Lost executor 7 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:15:53 WARN TaskSetManager: Lost task 63.0 in stage 25.0 (TID 1679, 128.110.152.145): ExecutorLostFailure (executor 7 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:15:53 WARN TaskSetManager: Lost task 23.0 in stage 25.0 (TID 1639, 128.110.152.145): ExecutorLostFailure (executor 7 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 25:=======================================================>(64 + 1) / 65]17/06/10 08:15:59 ERROR TaskSchedulerImpl: Lost executor 9 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:15:59 WARN TaskSetManager: Lost task 23.1 in stage 25.0 (TID 1681, 128.110.152.141): ExecutorLostFailure (executor 9 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 48.181392543 seconds
res27: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=164 AND partitionZIndex<=171", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=164 AND partitionZIndex<=171,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.082834798 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 26:======================================>                (45 + 19) / 64][Stage 26:============================================>          (52 + 12) / 64][Stage 26:=====================================================>  (61 + 3) / 64][Stage 26:======================================================> (62 + 2) / 64][Stage 26:=======================================================>(63 + 1) / 64]                                                                                [Stage 27:=====================================================>  (62 + 3) / 65][Stage 27:======================================================> (63 + 2) / 65][Stage 27:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 16.813103682 seconds
res29: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=200 AND partitionZIndex<=207", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=200 AND partitionZIndex<=207,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.081667854 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.829978849 seconds
res31: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=60 AND partitionZIndex<=67", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=60 AND partitionZIndex<=67,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.065601808 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 30:=======================================================>(63 + 1) / 64]                                                                                [Stage 31:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 14.20623355 seconds
res33: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=181 AND partitionZIndex<=188", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=181 AND partitionZIndex<=188,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.063103598 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 32:=====================================================>  (61 + 3) / 64][Stage 32:=======================================================>(63 + 1) / 64]                                                                                [Stage 33:=====================================================>  (62 + 3) / 65][Stage 33:======================================================> (63 + 2) / 65]                                                                                Time elapsed: 15.270452237 seconds
res35: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=179 AND partitionZIndex<=186", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=179 AND partitionZIndex<=186,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.073289178 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 34:=====================================================>  (61 + 3) / 64][Stage 34:======================================================> (62 + 2) / 64][Stage 34:=======================================================>(63 + 1) / 64]                                                                                [Stage 35:=====================================================>  (62 + 3) / 65][Stage 35:======================================================> (63 + 2) / 65]                                                                                Time elapsed: 14.883286261 seconds
res37: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=49 AND partitionZIndex<=56", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=49 AND partitionZIndex<=56,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.074447183 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 36:=====================================================>  (61 + 3) / 64][Stage 36:======================================================> (62 + 2) / 64][Stage 36:=======================================================>(63 + 1) / 64]                                                                                [Stage 37:=====================================================>  (62 + 3) / 65][Stage 37:======================================================> (63 + 2) / 65]17/06/10 08:17:43 ERROR TaskSchedulerImpl: Lost executor 1 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:17:43 WARN TaskSetManager: Lost task 23.0 in stage 37.0 (TID 2416, 128.110.152.142): ExecutorLostFailure (executor 1 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 37:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 25.974619338 seconds
res39: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=39 AND partitionZIndex<=46", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=39 AND partitionZIndex<=46,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.073923481 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 38:==============================================>        (54 + 10) / 64][Stage 38:=====================================================>  (61 + 3) / 64]17/06/10 08:18:01 ERROR TaskSchedulerImpl: Lost executor 6 on 128.110.152.152: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:18:01 WARN TaskSetManager: Lost task 10.0 in stage 38.0 (TID 2469, 128.110.152.152): ExecutorLostFailure (executor 6 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 38:======================================================> (62 + 2) / 64][Stage 38:=======================================================>(63 + 1) / 64]                                                                                [Stage 39:==============================================>        (55 + 10) / 65][Stage 39:=====================================================>  (62 + 3) / 65][Stage 39:======================================================> (63 + 2) / 65]17/06/10 08:18:16 ERROR TaskSchedulerImpl: Lost executor 11 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:18:16 WARN TaskSetManager: Lost task 1.0 in stage 39.0 (TID 2525, 128.110.152.145): ExecutorLostFailure (executor 11 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:18:16 ERROR TransportResponseHandler: Still have 1 requests outstanding when connection from /128.110.152.145:34142 is closed
17/06/10 08:18:16 WARN BlockManagerMaster: Failed to remove broadcast 54 with removeFromMaster = true - Connection from /128.110.152.145:34142 closed
java.io.IOException: Connection from /128.110.152.145:34142 closed
	at org.apache.spark.network.client.TransportResponseHandler.channelInactive(TransportResponseHandler.java:128)
	at org.apache.spark.network.server.TransportChannelHandler.channelInactive(TransportChannelHandler.java:109)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at io.netty.handler.timeout.IdleStateHandler.channelInactive(IdleStateHandler.java:257)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at org.apache.spark.network.util.TransportFrameDecoder.channelInactive(TransportFrameDecoder.java:182)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.DefaultChannelPipeline.fireChannelInactive(DefaultChannelPipeline.java:828)
	at io.netty.channel.AbstractChannel$AbstractUnsafe$7.run(AbstractChannel.java:621)
	at io.netty.util.concurrent.SingleThreadEventExecutor.runAllTasks(SingleThreadEventExecutor.java:357)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:357)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 08:18:16 ERROR ContextCleaner: Error cleaning broadcast 54
org.apache.spark.SparkException: Exception thrown in awaitResult
	at org.apache.spark.rpc.RpcTimeout$$anonfun$1.applyOrElse(RpcTimeout.scala:77)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$1.applyOrElse(RpcTimeout.scala:75)
	at scala.runtime.AbstractPartialFunction.apply(AbstractPartialFunction.scala:36)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$addMessageIfTimeout$1.applyOrElse(RpcTimeout.scala:59)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$addMessageIfTimeout$1.applyOrElse(RpcTimeout.scala:59)
	at scala.PartialFunction$OrElse.apply(PartialFunction.scala:167)
	at org.apache.spark.rpc.RpcTimeout.awaitResult(RpcTimeout.scala:83)
	at org.apache.spark.storage.BlockManagerMaster.removeBroadcast(BlockManagerMaster.scala:143)
	at org.apache.spark.broadcast.TorrentBroadcast$.unpersist(TorrentBroadcast.scala:267)
	at org.apache.spark.broadcast.TorrentBroadcastFactory.unbroadcast(TorrentBroadcastFactory.scala:45)
	at org.apache.spark.broadcast.BroadcastManager.unbroadcast(BroadcastManager.scala:60)
	at org.apache.spark.ContextCleaner.doCleanupBroadcast(ContextCleaner.scala:232)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1$$anonfun$apply$mcV$sp$2.apply(ContextCleaner.scala:188)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1$$anonfun$apply$mcV$sp$2.apply(ContextCleaner.scala:179)
	at scala.Option.foreach(Option.scala:257)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1.apply$mcV$sp(ContextCleaner.scala:179)
	at org.apache.spark.util.Utils$.tryOrStopSparkContext(Utils.scala:1252)
	at org.apache.spark.ContextCleaner.org$apache$spark$ContextCleaner$$keepCleaning(ContextCleaner.scala:172)
	at org.apache.spark.ContextCleaner$$anon$1.run(ContextCleaner.scala:67)
Caused by: java.io.IOException: Connection from /128.110.152.145:34142 closed
	at org.apache.spark.network.client.TransportResponseHandler.channelInactive(TransportResponseHandler.java:128)
	at org.apache.spark.network.server.TransportChannelHandler.channelInactive(TransportChannelHandler.java:109)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at io.netty.handler.timeout.IdleStateHandler.channelInactive(IdleStateHandler.java:257)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at org.apache.spark.network.util.TransportFrameDecoder.channelInactive(TransportFrameDecoder.java:182)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.DefaultChannelPipeline.fireChannelInactive(DefaultChannelPipeline.java:828)
	at io.netty.channel.AbstractChannel$AbstractUnsafe$7.run(AbstractChannel.java:621)
	at io.netty.util.concurrent.SingleThreadEventExecutor.runAllTasks(SingleThreadEventExecutor.java:357)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:357)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 08:18:16 ERROR TaskSchedulerImpl: Lost executor 12 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:18:16 WARN TaskSetManager: Lost task 1.1 in stage 39.0 (TID 2589, 128.110.152.141): ExecutorLostFailure (executor 12 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 39:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 27.216738008 seconds
res41: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=228 AND partitionZIndex<=235", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=228 AND partitionZIndex<=235,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.088063978 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 40:=========================================>             (48 + 16) / 64][Stage 40:=================================================>      (56 + 8) / 64]                                                                                Time elapsed: 5.768126801 seconds
res43: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=92 AND partitionZIndex<=99", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=92 AND partitionZIndex<=99,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.060219065 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 42:=====================================================>  (61 + 3) / 64][Stage 42:======================================================> (62 + 2) / 64][Stage 42:=======================================================>(63 + 1) / 64]17/06/10 08:18:40 ERROR TaskSchedulerImpl: Lost executor 4 on 128.110.152.157: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:18:40 WARN TaskSetManager: Lost task 20.0 in stage 42.0 (TID 2740, 128.110.152.157): ExecutorLostFailure (executor 4 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 43:=============================================>         (54 + 11) / 65][Stage 43:=====================================================>  (62 + 3) / 65][Stage 43:======================================================> (63 + 2) / 65][Stage 43:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 26.891326685 seconds
res45: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=148 AND partitionZIndex<=155", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=148 AND partitionZIndex<=155,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.059619322 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 1.199584794 seconds
res47: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=32 AND partitionZIndex<=39", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=32 AND partitionZIndex<=39,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056694731 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 46:==============================================>        (54 + 10) / 64][Stage 46:================================================>       (55 + 9) / 64][Stage 46:=================================================>      (56 + 8) / 64][Stage 46:=================================================>      (56 + 8) / 64][Stage 46:=================================================>      (56 + 8) / 64][Stage 46:=================================================>      (56 + 8) / 64][Stage 46:=================================================>      (56 + 8) / 64][Stage 46:=================================================>      (56 + 8) / 64][Stage 46:=================================================>      (56 + 8) / 64]17/06/10 08:25:39 ERROR TaskSchedulerImpl: Lost executor 15 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:25:39 WARN TaskSetManager: Lost task 20.0 in stage 46.0 (TID 2999, 128.110.152.145): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:25:39 WARN TaskSetManager: Lost task 52.0 in stage 46.0 (TID 3031, 128.110.152.145): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:25:39 WARN TaskSetManager: Lost task 28.0 in stage 46.0 (TID 3007, 128.110.152.145): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:25:39 WARN TaskSetManager: Lost task 4.0 in stage 46.0 (TID 2983, 128.110.152.145): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:25:39 WARN TaskSetManager: Lost task 12.0 in stage 46.0 (TID 2991, 128.110.152.145): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:25:39 WARN TaskSetManager: Lost task 60.0 in stage 46.0 (TID 3039, 128.110.152.145): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:25:39 WARN TaskSetManager: Lost task 36.0 in stage 46.0 (TID 3015, 128.110.152.145): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:25:39 WARN TaskSetManager: Lost task 44.0 in stage 46.0 (TID 3023, 128.110.152.145): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 47:======================================================> (63 + 2) / 65]17/06/10 08:25:46 ERROR TaskSetManager: Total size of serialized results of 65 tasks (539.4 MB) is bigger than spark.driver.maxResultSize (512.0 MB)
[Stage 47:=======================================================>(64 + 1) / 65]org.apache.spark.SparkException: Job aborted due to stage failure: Total size of serialized results of 65 tasks (539.4 MB) is bigger than spark.driver.maxResultSize (512.0 MB)
  at org.apache.spark.scheduler.DAGScheduler.org$apache$spark$scheduler$DAGScheduler$$failJobAndIndependentStages(DAGScheduler.scala:1454)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$abortStage$1.apply(DAGScheduler.scala:1442)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$abortStage$1.apply(DAGScheduler.scala:1441)
  at scala.collection.mutable.ResizableArray$class.foreach(ResizableArray.scala:59)
  at scala.collection.mutable.ArrayBuffer.foreach(ArrayBuffer.scala:48)
  at org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:1441)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$handleTaskSetFailed$1.apply(DAGScheduler.scala:811)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$handleTaskSetFailed$1.apply(DAGScheduler.scala:811)
  at scala.Option.foreach(Option.scala:257)
  at org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:811)
  at org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:1667)
  at org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:1622)
  at org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:1611)
  at org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:48)
  at org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:632)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1873)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1886)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1899)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1913)
  at org.apache.spark.rdd.RDD$$anonfun$collect$1.apply(RDD.scala:912)
  at org.apache.spark.rdd.RDDOperationScope$.withScope(RDDOperationScope.scala:151)
  at org.apache.spark.rdd.RDDOperationScope$.withScope(RDDOperationScope.scala:112)
  at org.apache.spark.rdd.RDD.withScope(RDD.scala:358)
  at org.apache.spark.rdd.RDD.collect(RDD.scala:911)
  at $anonfun$1.apply$mcI$sp(<console>:38)
  at $anonfun$1.apply(<console>:38)
  at $anonfun$1.apply(<console>:38)
  at show_timing(<console>:30)
  ... 50 elided

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=10 AND partitionZIndex<=17", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=10 AND partitionZIndex<=17,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.066136305 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 48:>                                                        (0 + 0) / 64][Stage 48:=============================================>         (53 + 11) / 64][Stage 48:==============================================>        (54 + 10) / 64][Stage 48:================================================>       (55 + 9) / 64][Stage 48:=======================================================>(63 + 1) / 64]17/06/10 08:25:57 ERROR TaskSchedulerImpl: Lost executor 10 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:25:57 WARN TaskSetManager: Lost task 21.0 in stage 48.0 (TID 3137, 128.110.152.168): ExecutorLostFailure (executor 10 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 49:=============================================>         (54 + 11) / 65][Stage 49:==============================================>        (55 + 10) / 65][Stage 49:======================================================> (63 + 2) / 65]17/06/10 08:26:11 ERROR TaskSchedulerImpl: Lost executor 16 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:26:11 WARN TaskSetManager: Lost task 21.0 in stage 49.0 (TID 3202, 128.110.152.141): ExecutorLostFailure (executor 16 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:26:13 ERROR TaskSchedulerImpl: Lost executor 13 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:26:13 WARN TaskSetManager: Lost task 9.0 in stage 49.0 (TID 3190, 128.110.152.142): ExecutorLostFailure (executor 13 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 49:=======================================================>(64 + 1) / 65]17/06/10 08:26:19 ERROR TaskSetManager: Total size of serialized results of 65 tasks (557.3 MB) is bigger than spark.driver.maxResultSize (512.0 MB)
org.apache.spark.SparkException: Job aborted due to stage failure: Total size of serialized results of 65 tasks (557.3 MB) is bigger than spark.driver.maxResultSize (512.0 MB)
  at org.apache.spark.scheduler.DAGScheduler.org$apache$spark$scheduler$DAGScheduler$$failJobAndIndependentStages(DAGScheduler.scala:1454)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$abortStage$1.apply(DAGScheduler.scala:1442)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$abortStage$1.apply(DAGScheduler.scala:1441)
  at scala.collection.mutable.ResizableArray$class.foreach(ResizableArray.scala:59)
  at scala.collection.mutable.ArrayBuffer.foreach(ArrayBuffer.scala:48)
  at org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:1441)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$handleTaskSetFailed$1.apply(DAGScheduler.scala:811)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$handleTaskSetFailed$1.apply(DAGScheduler.scala:811)
  at scala.Option.foreach(Option.scala:257)
  at org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:811)
  at org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:1667)
  at org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:1622)
  at org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:1611)
  at org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:48)
  at org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:632)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1873)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1886)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1899)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1913)
  at org.apache.spark.rdd.RDD$$anonfun$collect$1.apply(RDD.scala:912)
  at org.apache.spark.rdd.RDDOperationScope$.withScope(RDDOperationScope.scala:151)
  at org.apache.spark.rdd.RDDOperationScope$.withScope(RDDOperationScope.scala:112)
  at org.apache.spark.rdd.RDD.withScope(RDD.scala:358)
  at org.apache.spark.rdd.RDD.collect(RDD.scala:911)
  at $anonfun$1.apply$mcI$sp(<console>:38)
  at $anonfun$1.apply(<console>:38)
  at $anonfun$1.apply(<console>:38)
  at show_timing(<console>:30)
  ... 50 elided

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=37 AND partitionZIndex<=44", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=37 AND partitionZIndex<=44,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.065273221 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 50:=========================================>             (48 + 16) / 64][Stage 50:=====================================================>  (61 + 3) / 64]17/06/10 08:26:33 ERROR TaskSchedulerImpl: Lost executor 20 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:26:33 WARN TaskSetManager: Lost task 24.0 in stage 50.0 (TID 3272, 128.110.152.141): ExecutorLostFailure (executor 20 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:26:33 WARN TaskSetManager: Lost task 0.0 in stage 50.0 (TID 3248, 128.110.152.141): ExecutorLostFailure (executor 20 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 50:======================================================> (62 + 2) / 64][Stage 50:=======================================================>(63 + 1) / 64]                                                                                [Stage 51:=============================================>         (54 + 11) / 65][Stage 51:=====================================================>  (62 + 3) / 65]17/06/10 08:26:47 ERROR TaskSchedulerImpl: Lost executor 0 on 128.110.152.165: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:26:47 WARN TaskSetManager: Lost task 0.0 in stage 51.0 (TID 3314, 128.110.152.165): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:26:47 WARN TaskSetManager: Lost task 24.0 in stage 51.0 (TID 3338, 128.110.152.165): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 51:======================================================> (63 + 2) / 65][Stage 51:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 35.381136313 seconds
res53: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=28 AND partitionZIndex<=35", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=28 AND partitionZIndex<=35,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.06246685 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 52:==============================================>        (54 + 10) / 64][Stage 52:================================================>       (55 + 9) / 64][Stage 52:=================================================>      (56 + 8) / 64][Stage 52:=======================================================>(63 + 1) / 64]                                                                                [Stage 53:=====================================================>  (62 + 3) / 65][Stage 53:======================================================> (63 + 2) / 65][Stage 53:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 22.905237163 seconds
res55: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=61 AND partitionZIndex<=68", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=61 AND partitionZIndex<=68,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.06759495 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 54:=====================================================>  (61 + 3) / 64][Stage 54:======================================================> (62 + 2) / 64][Stage 54:=======================================================>(63 + 1) / 64]                                                                                [Stage 55:=====================================================>  (62 + 3) / 65][Stage 55:======================================================> (63 + 2) / 65][Stage 55:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 17.996037461 seconds
res57: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=89 AND partitionZIndex<=96", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=89 AND partitionZIndex<=96,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05735539 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 56:=====================================================>  (61 + 3) / 64][Stage 56:======================================================> (62 + 2) / 64][Stage 56:=======================================================>(63 + 1) / 64]                                                                                17/06/10 08:27:53 ERROR TaskSchedulerImpl: Lost executor 22 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:27:53 WARN TaskSetManager: Lost task 1.0 in stage 57.0 (TID 3704, 128.110.152.141): ExecutorLostFailure (executor 22 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 57:=====================================================>  (62 + 3) / 65][Stage 57:======================================================> (63 + 2) / 65][Stage 57:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 16.215299326 seconds
res59: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=38 AND partitionZIndex<=45", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=38 AND partitionZIndex<=45,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.062761511 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 58:================================================>       (55 + 9) / 64][Stage 58:=====================================================>  (61 + 3) / 64][Stage 58:======================================================> (62 + 2) / 64]17/06/10 08:28:15 ERROR TaskSchedulerImpl: Lost executor 24 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:28:15 WARN TaskSetManager: Lost task 24.0 in stage 58.0 (TID 3793, 128.110.152.141): ExecutorLostFailure (executor 24 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:28:15 WARN TaskSetManager: Lost task 0.0 in stage 58.0 (TID 3769, 128.110.152.141): ExecutorLostFailure (executor 24 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 58:=======================================================>(63 + 1) / 64]                                                                                [Stage 59:==============================================>        (55 + 10) / 65][Stage 59:=====================================================>  (62 + 3) / 65][Stage 59:======================================================> (63 + 2) / 65][Stage 59:=======================================================>(64 + 1) / 65]17/06/10 08:28:36 ERROR TaskSchedulerImpl: Lost executor 25 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:28:36 WARN TaskSetManager: Lost task 11.0 in stage 59.0 (TID 3846, 128.110.152.141): ExecutorLostFailure (executor 25 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 42.780403068 seconds
res61: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=188 AND partitionZIndex<=195", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=188 AND partitionZIndex<=195,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056029823 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 60:=============================================>         (53 + 11) / 64][Stage 60:======================================================> (62 + 2) / 64][Stage 60:=======================================================>(63 + 1) / 64]                                                                                [Stage 61:=====================================================>  (62 + 3) / 65][Stage 61:======================================================> (63 + 2) / 65][Stage 61:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 18.174774492 seconds
res63: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=113 AND partitionZIndex<=120", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=113 AND partitionZIndex<=120,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056811387 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.777563539 seconds
res65: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=174 AND partitionZIndex<=181", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=174 AND partitionZIndex<=181,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050302501 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.79061577 seconds
res67: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=20 AND partitionZIndex<=27", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=20 AND partitionZIndex<=27,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052207648 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 66:======================================================> (62 + 2) / 64][Stage 66:=======================================================>(63 + 1) / 64]                                                                                [Stage 67:======================================================> (63 + 2) / 65]17/06/10 08:29:23 ERROR TaskSchedulerImpl: Lost executor 14 on 128.110.152.152: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:29:23 WARN TaskSetManager: Lost task 0.0 in stage 67.0 (TID 4352, 128.110.152.152): ExecutorLostFailure (executor 14 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:29:23 WARN TaskSetManager: Lost task 8.0 in stage 67.0 (TID 4360, 128.110.152.152): ExecutorLostFailure (executor 14 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:29:30 ERROR TaskSchedulerImpl: Lost executor 18 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:29:30 WARN TaskSetManager: Lost task 0.1 in stage 67.0 (TID 4418, 128.110.152.145): ExecutorLostFailure (executor 18 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 67:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 22.755024115 seconds
res69: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=69 AND partitionZIndex<=76", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=69 AND partitionZIndex<=76,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058566854 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 68:=========================================>             (48 + 16) / 64]                                                                                Time elapsed: 5.875434051 seconds
res71: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=119 AND partitionZIndex<=126", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=119 AND partitionZIndex<=126,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051186564 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 70:======================================================> (62 + 2) / 64][Stage 70:=======================================================>(63 + 1) / 64]                                                                                [Stage 71:======================================================> (63 + 2) / 65][Stage 71:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 19.431752706 seconds
res73: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=170 AND partitionZIndex<=177", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=170 AND partitionZIndex<=177,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053960875 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.802438892 seconds
res75: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=205 AND partitionZIndex<=212", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=205 AND partitionZIndex<=212,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.059984198 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 74:=====================================================>  (61 + 3) / 64][Stage 74:======================================================> (62 + 2) / 64][Stage 74:=======================================================>(63 + 1) / 64]                                                                                [Stage 75:=====================================================>  (62 + 3) / 65][Stage 75:======================================================> (63 + 2) / 65][Stage 75:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 20.475595761 seconds
res77: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=111 AND partitionZIndex<=118", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=111 AND partitionZIndex<=118,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058877754 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.609198042 seconds
res79: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=15 AND partitionZIndex<=22", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=15 AND partitionZIndex<=22,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051841466 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 78:======================================================> (62 + 2) / 64][Stage 78:=======================================================>(63 + 1) / 64]17/06/10 08:30:44 ERROR TaskSchedulerImpl: Lost executor 2 on 128.110.152.160: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:30:44 WARN TaskSetManager: Lost task 0.0 in stage 78.0 (TID 5065, 128.110.152.160): ExecutorLostFailure (executor 2 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 79:================================================>       (56 + 9) / 65][Stage 79:======================================================> (63 + 2) / 65][Stage 79:=======================================================>(64 + 1) / 65]17/06/10 08:30:59 ERROR TaskSchedulerImpl: Lost executor 28 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:30:59 WARN TaskSetManager: Lost task 0.0 in stage 79.0 (TID 5130, 128.110.152.145): ExecutorLostFailure (executor 28 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 30.484350454 seconds
res81: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=81 AND partitionZIndex<=88", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=81 AND partitionZIndex<=88,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052530268 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 80:=============================================>         (53 + 11) / 64][Stage 80:=====================================================>  (61 + 3) / 64]17/06/10 08:31:16 ERROR TaskSchedulerImpl: Lost executor 23 on 128.110.152.165: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:31:16 WARN TaskSetManager: Lost task 24.0 in stage 80.0 (TID 5220, 128.110.152.165): ExecutorLostFailure (executor 23 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:31:16 WARN TaskSetManager: Lost task 0.0 in stage 80.0 (TID 5196, 128.110.152.165): ExecutorLostFailure (executor 23 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 80:======================================================> (62 + 2) / 64][Stage 80:=======================================================>(63 + 1) / 64]                                                                                [Stage 81:=============================================>         (54 + 11) / 65][Stage 81:=====================================================>  (62 + 3) / 65][Stage 81:======================================================> (63 + 2) / 65]17/06/10 08:31:31 ERROR TaskSchedulerImpl: Lost executor 30 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:31:31 WARN TaskSetManager: Lost task 0.0 in stage 81.0 (TID 5262, 128.110.152.145): ExecutorLostFailure (executor 30 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:31:31 WARN TaskSetManager: Lost task 24.0 in stage 81.0 (TID 5286, 128.110.152.145): ExecutorLostFailure (executor 30 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 81:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 29.825047184 seconds
res83: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=180 AND partitionZIndex<=187", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=180 AND partitionZIndex<=187,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054951698 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 82:=============================================>         (53 + 11) / 64][Stage 82:=====================================================>  (61 + 3) / 64][Stage 82:======================================================> (62 + 2) / 64][Stage 82:=======================================================>(63 + 1) / 64]                                                                                [Stage 83:=====================================================>  (62 + 3) / 65][Stage 83:======================================================> (63 + 2) / 65][Stage 83:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 14.885957546 seconds
res85: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=147 AND partitionZIndex<=154", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=147 AND partitionZIndex<=154,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05303267 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.775970937 seconds
res87: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=186 AND partitionZIndex<=193", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=186 AND partitionZIndex<=193,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056920466 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 86:=====================================================>  (61 + 3) / 64][Stage 86:======================================================> (62 + 2) / 64][Stage 86:=======================================================>(63 + 1) / 64]                                                                                17/06/10 08:32:09 ERROR TaskSchedulerImpl: Lost executor 26 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:32:09 WARN TaskSetManager: Lost task 42.0 in stage 87.0 (TID 5693, 128.110.152.141): ExecutorLostFailure (executor 26 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:32:09 WARN TaskSetManager: Lost task 50.0 in stage 87.0 (TID 5701, 128.110.152.141): ExecutorLostFailure (executor 26 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:32:09 WARN TaskSetManager: Lost task 10.0 in stage 87.0 (TID 5661, 128.110.152.141): ExecutorLostFailure (executor 26 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 87:=====================================================>  (62 + 3) / 65][Stage 87:======================================================> (63 + 2) / 65][Stage 87:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 16.866845541 seconds
res89: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=70 AND partitionZIndex<=77", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=70 AND partitionZIndex<=77,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050208139 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 88:=============================================>         (53 + 11) / 64][Stage 88:=====================================================>  (61 + 3) / 64][Stage 88:=======================================================>(63 + 1) / 64]                                                                                [Stage 89:=====================================================>  (62 + 3) / 65]17/06/10 08:32:35 ERROR TaskSchedulerImpl: Lost executor 17 on 128.110.152.157: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:32:35 WARN TaskSetManager: Lost task 0.0 in stage 89.0 (TID 5783, 128.110.152.157): ExecutorLostFailure (executor 17 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:32:35 WARN TaskSetManager: Lost task 24.0 in stage 89.0 (TID 5807, 128.110.152.157): ExecutorLostFailure (executor 17 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 89:======================================================> (63 + 2) / 65][Stage 89:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 23.099693652 seconds
res91: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=231 AND partitionZIndex<=238", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=231 AND partitionZIndex<=238,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.084641975 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 08:32:46 ERROR TaskSchedulerImpl: Lost executor 32 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:32:46 WARN TaskSetManager: Lost task 37.0 in stage 90.0 (TID 5887, 128.110.152.145): ExecutorLostFailure (executor 32 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 90:==============================================>        (54 + 10) / 64][Stage 90:======================================================> (62 + 2) / 64][Stage 90:=======================================================>(63 + 1) / 64]                                                                                [Stage 91:==============================================>        (55 + 10) / 65][Stage 91:======================================================> (63 + 2) / 65][Stage 91:=======================================================>(64 + 1) / 65]17/06/10 08:33:03 WARN TransportChannelHandler: Exception in connection from /128.110.152.141:35710
java.io.IOException: Connection reset by peer
	at sun.nio.ch.FileDispatcherImpl.read0(Native Method)
	at sun.nio.ch.SocketDispatcher.read(SocketDispatcher.java:39)
	at sun.nio.ch.IOUtil.readIntoNativeBuffer(IOUtil.java:223)
	at sun.nio.ch.IOUtil.read(IOUtil.java:192)
	at sun.nio.ch.SocketChannelImpl.read(SocketChannelImpl.java:380)
	at io.netty.buffer.PooledUnsafeDirectByteBuf.setBytes(PooledUnsafeDirectByteBuf.java:313)
	at io.netty.buffer.AbstractByteBuf.writeBytes(AbstractByteBuf.java:881)
	at io.netty.channel.socket.nio.NioSocketChannel.doReadBytes(NioSocketChannel.java:242)
	at io.netty.channel.nio.AbstractNioByteChannel$NioByteUnsafe.read(AbstractNioByteChannel.java:119)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:511)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 08:33:03 ERROR TransportResponseHandler: Still have 1 requests outstanding when connection from /128.110.152.141:35710 is closed
17/06/10 08:33:03 WARN BlockManagerMaster: Failed to remove broadcast 126 with removeFromMaster = true - Connection reset by peer
java.io.IOException: Connection reset by peer
	at sun.nio.ch.FileDispatcherImpl.read0(Native Method)
	at sun.nio.ch.SocketDispatcher.read(SocketDispatcher.java:39)
	at sun.nio.ch.IOUtil.readIntoNativeBuffer(IOUtil.java:223)
	at sun.nio.ch.IOUtil.read(IOUtil.java:192)
	at sun.nio.ch.SocketChannelImpl.read(SocketChannelImpl.java:380)
	at io.netty.buffer.PooledUnsafeDirectByteBuf.setBytes(PooledUnsafeDirectByteBuf.java:313)
	at io.netty.buffer.AbstractByteBuf.writeBytes(AbstractByteBuf.java:881)
	at io.netty.channel.socket.nio.NioSocketChannel.doReadBytes(NioSocketChannel.java:242)
	at io.netty.channel.nio.AbstractNioByteChannel$NioByteUnsafe.read(AbstractNioByteChannel.java:119)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:511)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 08:33:03 ERROR TaskSchedulerImpl: Lost executor 33 on 128.110.152.141: Command exited with code 137
17/06/10 08:33:03 WARN TaskSetManager: Lost task 37.0 in stage 91.0 (TID 5952, 128.110.152.141): ExecutorLostFailure (executor 33 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 08:33:03 ERROR ContextCleaner: Error cleaning broadcast 126
org.apache.spark.SparkException: Exception thrown in awaitResult
	at org.apache.spark.rpc.RpcTimeout$$anonfun$1.applyOrElse(RpcTimeout.scala:77)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$1.applyOrElse(RpcTimeout.scala:75)
	at scala.runtime.AbstractPartialFunction.apply(AbstractPartialFunction.scala:36)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$addMessageIfTimeout$1.applyOrElse(RpcTimeout.scala:59)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$addMessageIfTimeout$1.applyOrElse(RpcTimeout.scala:59)
	at scala.PartialFunction$OrElse.apply(PartialFunction.scala:167)
	at org.apache.spark.rpc.RpcTimeout.awaitResult(RpcTimeout.scala:83)
	at org.apache.spark.storage.BlockManagerMaster.removeBroadcast(BlockManagerMaster.scala:143)
	at org.apache.spark.broadcast.TorrentBroadcast$.unpersist(TorrentBroadcast.scala:267)
	at org.apache.spark.broadcast.TorrentBroadcastFactory.unbroadcast(TorrentBroadcastFactory.scala:45)
	at org.apache.spark.broadcast.BroadcastManager.unbroadcast(BroadcastManager.scala:60)
	at org.apache.spark.ContextCleaner.doCleanupBroadcast(ContextCleaner.scala:232)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1$$anonfun$apply$mcV$sp$2.apply(ContextCleaner.scala:188)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1$$anonfun$apply$mcV$sp$2.apply(ContextCleaner.scala:179)
	at scala.Option.foreach(Option.scala:257)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1.apply$mcV$sp(ContextCleaner.scala:179)
	at org.apache.spark.util.Utils$.tryOrStopSparkContext(Utils.scala:1252)
	at org.apache.spark.ContextCleaner.org$apache$spark$ContextCleaner$$keepCleaning(ContextCleaner.scala:172)
	at org.apache.spark.ContextCleaner$$anon$1.run(ContextCleaner.scala:67)
Caused by: java.io.IOException: Connection reset by peer
	at sun.nio.ch.FileDispatcherImpl.read0(Native Method)
	at sun.nio.ch.SocketDispatcher.read(SocketDispatcher.java:39)
	at sun.nio.ch.IOUtil.readIntoNativeBuffer(IOUtil.java:223)
	at sun.nio.ch.IOUtil.read(IOUtil.java:192)
	at sun.nio.ch.SocketChannelImpl.read(SocketChannelImpl.java:380)
	at io.netty.buffer.PooledUnsafeDirectByteBuf.setBytes(PooledUnsafeDirectByteBuf.java:313)
	at io.netty.buffer.AbstractByteBuf.writeBytes(AbstractByteBuf.java:881)
	at io.netty.channel.socket.nio.NioSocketChannel.doReadBytes(NioSocketChannel.java:242)
	at io.netty.channel.nio.AbstractNioByteChannel$NioByteUnsafe.read(AbstractNioByteChannel.java:119)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:511)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
                                                                                Time elapsed: 26.069612719 seconds
res93: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=175 AND partitionZIndex<=182", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=175 AND partitionZIndex<=182,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058672332 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 92:=================================================>      (56 + 8) / 64]                                                                                Time elapsed: 5.699627151 seconds
res95: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=48 AND partitionZIndex<=55", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=48 AND partitionZIndex<=55,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.060231718 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 94:=====================================================>  (61 + 3) / 64][Stage 94:======================================================> (62 + 2) / 64][Stage 94:=======================================================>(63 + 1) / 64]                                                                                [Stage 95:=====================================================>  (62 + 3) / 65][Stage 95:======================================================> (63 + 2) / 65][Stage 95:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 18.832998285 seconds
res97: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=34 AND partitionZIndex<=41", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=34 AND partitionZIndex<=41,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054388875 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 96:======================================================> (62 + 2) / 64][Stage 96:=======================================================>(63 + 1) / 64]                                                                                [Stage 97:======================================================> (63 + 2) / 65][Stage 97:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 17.761789788 seconds
res99: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=77 AND partitionZIndex<=84", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=77 AND partitionZIndex<=84,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057668148 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 98:=====================================================>  (61 + 3) / 64][Stage 98:======================================================> (62 + 2) / 64][Stage 98:=======================================================>(63 + 1) / 64]                                                                                [Stage 99:=====================================================>  (62 + 3) / 65][Stage 99:======================================================> (63 + 2) / 65][Stage 99:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 18.889066082 seconds
res101: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=167 AND partitionZIndex<=174", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=167 AND partitionZIndex<=174,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058189629 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.634093324 seconds
res103: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=144 AND partitionZIndex<=151", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=144 AND partitionZIndex<=151,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051920285 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.616610475 seconds
res105: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=222 AND partitionZIndex<=229", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=222 AND partitionZIndex<=229,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047559587 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 104:=====================================================> (62 + 2) / 64][Stage 104:======================================================>(63 + 1) / 64]                                                                                [Stage 105:=====================================================> (63 + 2) / 65][Stage 105:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 13.55407867 seconds
res107: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=246 AND partitionZIndex<=253", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=246 AND partitionZIndex<=253,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054948637 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.583355182 seconds
res109: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=194 AND partitionZIndex<=201", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=194 AND partitionZIndex<=201,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047429768 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.513575587 seconds
res111: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=21 AND partitionZIndex<=28", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=21 AND partitionZIndex<=28,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.066569123 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 110:=====================================================> (62 + 2) / 64][Stage 110:======================================================>(63 + 1) / 64]                                                                                [Stage 111:=====================================================> (63 + 2) / 65][Stage 111:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.860680799 seconds
res113: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=47 AND partitionZIndex<=54", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=47 AND partitionZIndex<=54,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055050937 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 112:====================================================>  (61 + 3) / 64][Stage 112:=====================================================> (62 + 2) / 64][Stage 112:======================================================>(63 + 1) / 64]                                                                                [Stage 113:====================================================>  (62 + 3) / 65]17/06/10 08:35:20 ERROR TaskSchedulerImpl: Lost executor 36 on 128.110.152.141: Command exited with code 137
17/06/10 08:35:20 WARN TaskSetManager: Lost task 47.0 in stage 113.0 (TID 7382, 128.110.152.141): ExecutorLostFailure (executor 36 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 08:35:20 WARN TransportChannelHandler: Exception in connection from /128.110.152.141:35822
java.io.IOException: Connection reset by peer
	at sun.nio.ch.FileDispatcherImpl.read0(Native Method)
	at sun.nio.ch.SocketDispatcher.read(SocketDispatcher.java:39)
	at sun.nio.ch.IOUtil.readIntoNativeBuffer(IOUtil.java:223)
	at sun.nio.ch.IOUtil.read(IOUtil.java:192)
	at sun.nio.ch.SocketChannelImpl.read(SocketChannelImpl.java:380)
	at io.netty.buffer.PooledUnsafeDirectByteBuf.setBytes(PooledUnsafeDirectByteBuf.java:313)
	at io.netty.buffer.AbstractByteBuf.writeBytes(AbstractByteBuf.java:881)
	at io.netty.channel.socket.nio.NioSocketChannel.doReadBytes(NioSocketChannel.java:242)
	at io.netty.channel.nio.AbstractNioByteChannel$NioByteUnsafe.read(AbstractNioByteChannel.java:119)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:511)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 08:35:20 ERROR TransportResponseHandler: Still have 1 requests outstanding when connection from /128.110.152.141:35822 is closed
17/06/10 08:35:20 WARN BlockManagerMaster: Failed to remove broadcast 155 with removeFromMaster = true - Connection reset by peer
java.io.IOException: Connection reset by peer
	at sun.nio.ch.FileDispatcherImpl.read0(Native Method)
	at sun.nio.ch.SocketDispatcher.read(SocketDispatcher.java:39)
	at sun.nio.ch.IOUtil.readIntoNativeBuffer(IOUtil.java:223)
	at sun.nio.ch.IOUtil.read(IOUtil.java:192)
	at sun.nio.ch.SocketChannelImpl.read(SocketChannelImpl.java:380)
	at io.netty.buffer.PooledUnsafeDirectByteBuf.setBytes(PooledUnsafeDirectByteBuf.java:313)
	at io.netty.buffer.AbstractByteBuf.writeBytes(AbstractByteBuf.java:881)
	at io.netty.channel.socket.nio.NioSocketChannel.doReadBytes(NioSocketChannel.java:242)
	at io.netty.channel.nio.AbstractNioByteChannel$NioByteUnsafe.read(AbstractNioByteChannel.java:119)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:511)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 08:35:20 ERROR ContextCleaner: Error cleaning broadcast 155
org.apache.spark.SparkException: Exception thrown in awaitResult
	at org.apache.spark.rpc.RpcTimeout$$anonfun$1.applyOrElse(RpcTimeout.scala:77)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$1.applyOrElse(RpcTimeout.scala:75)
	at scala.runtime.AbstractPartialFunction.apply(AbstractPartialFunction.scala:36)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$addMessageIfTimeout$1.applyOrElse(RpcTimeout.scala:59)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$addMessageIfTimeout$1.applyOrElse(RpcTimeout.scala:59)
	at scala.PartialFunction$OrElse.apply(PartialFunction.scala:167)
	at org.apache.spark.rpc.RpcTimeout.awaitResult(RpcTimeout.scala:83)
	at org.apache.spark.storage.BlockManagerMaster.removeBroadcast(BlockManagerMaster.scala:143)
	at org.apache.spark.broadcast.TorrentBroadcast$.unpersist(TorrentBroadcast.scala:267)
	at org.apache.spark.broadcast.TorrentBroadcastFactory.unbroadcast(TorrentBroadcastFactory.scala:45)
	at org.apache.spark.broadcast.BroadcastManager.unbroadcast(BroadcastManager.scala:60)
	at org.apache.spark.ContextCleaner.doCleanupBroadcast(ContextCleaner.scala:232)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1$$anonfun$apply$mcV$sp$2.apply(ContextCleaner.scala:188)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1$$anonfun$apply$mcV$sp$2.apply(ContextCleaner.scala:179)
	at scala.Option.foreach(Option.scala:257)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1.apply$mcV$sp(ContextCleaner.scala:179)
	at org.apache.spark.util.Utils$.tryOrStopSparkContext(Utils.scala:1252)
	at org.apache.spark.ContextCleaner.org$apache$spark$ContextCleaner$$keepCleaning(ContextCleaner.scala:172)
	at org.apache.spark.ContextCleaner$$anon$1.run(ContextCleaner.scala:67)
Caused by: java.io.IOException: Connection reset by peer
	at sun.nio.ch.FileDispatcherImpl.read0(Native Method)
	at sun.nio.ch.SocketDispatcher.read(SocketDispatcher.java:39)
	at sun.nio.ch.IOUtil.readIntoNativeBuffer(IOUtil.java:223)
	at sun.nio.ch.IOUtil.read(IOUtil.java:192)
	at sun.nio.ch.SocketChannelImpl.read(SocketChannelImpl.java:380)
	at io.netty.buffer.PooledUnsafeDirectByteBuf.setBytes(PooledUnsafeDirectByteBuf.java:313)
	at io.netty.buffer.AbstractByteBuf.writeBytes(AbstractByteBuf.java:881)
	at io.netty.channel.socket.nio.NioSocketChannel.doReadBytes(NioSocketChannel.java:242)
	at io.netty.channel.nio.AbstractNioByteChannel$NioByteUnsafe.read(AbstractNioByteChannel.java:119)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:511)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
[Stage 113:=====================================================> (63 + 2) / 65][Stage 113:======================================================>(64 + 1) / 65]17/06/10 08:35:24 ERROR TaskSetManager: Total size of serialized results of 65 tasks (546.5 MB) is bigger than spark.driver.maxResultSize (512.0 MB)
org.apache.spark.SparkException: Job aborted due to stage failure: Total size of serialized results of 65 tasks (546.5 MB) is bigger than spark.driver.maxResultSize (512.0 MB)
  at org.apache.spark.scheduler.DAGScheduler.org$apache$spark$scheduler$DAGScheduler$$failJobAndIndependentStages(DAGScheduler.scala:1454)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$abortStage$1.apply(DAGScheduler.scala:1442)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$abortStage$1.apply(DAGScheduler.scala:1441)
  at scala.collection.mutable.ResizableArray$class.foreach(ResizableArray.scala:59)
  at scala.collection.mutable.ArrayBuffer.foreach(ArrayBuffer.scala:48)
  at org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:1441)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$handleTaskSetFailed$1.apply(DAGScheduler.scala:811)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$handleTaskSetFailed$1.apply(DAGScheduler.scala:811)
  at scala.Option.foreach(Option.scala:257)
  at org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:811)
  at org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:1667)
  at org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:1622)
  at org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:1611)
  at org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:48)
  at org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:632)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1873)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1886)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1899)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1913)
  at org.apache.spark.rdd.RDD$$anonfun$collect$1.apply(RDD.scala:912)
  at org.apache.spark.rdd.RDDOperationScope$.withScope(RDDOperationScope.scala:151)
  at org.apache.spark.rdd.RDDOperationScope$.withScope(RDDOperationScope.scala:112)
  at org.apache.spark.rdd.RDD.withScope(RDD.scala:358)
  at org.apache.spark.rdd.RDD.collect(RDD.scala:911)
  at $anonfun$1.apply$mcI$sp(<console>:38)
  at $anonfun$1.apply(<console>:38)
  at $anonfun$1.apply(<console>:38)
  at show_timing(<console>:30)
  ... 50 elided

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=100 AND partitionZIndex<=107", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=100 AND partitionZIndex<=107,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051091541 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 114:=============================================>        (54 + 10) / 64][Stage 114:=====================================================> (62 + 2) / 64]17/06/10 08:35:34 ERROR TaskSchedulerImpl: Lost executor 19 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:35:34 WARN TaskSetManager: Lost task 24.0 in stage 114.0 (TID 7425, 128.110.152.168): ExecutorLostFailure (executor 19 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 114:======================================================>(63 + 1) / 64]                                                                                17/06/10 08:35:41 ERROR TaskSchedulerImpl: Lost executor 27 on 128.110.152.152: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:35:41 WARN TaskSetManager: Lost task 24.0 in stage 115.0 (TID 7490, 128.110.152.152): ExecutorLostFailure (executor 27 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 115:=============================================>        (55 + 10) / 65][Stage 115:=====================================================> (63 + 2) / 65][Stage 115:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 23.882287421 seconds
res117: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=176 AND partitionZIndex<=183", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=176 AND partitionZIndex<=183,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049185314 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 116:>                                                       (0 + 0) / 64][Stage 116:================================================>      (56 + 8) / 64]                                                                                Time elapsed: 5.491101411 seconds
res119: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=63 AND partitionZIndex<=70", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=63 AND partitionZIndex<=70,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047794169 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 118:====================================================>  (61 + 3) / 64][Stage 118:=====================================================> (62 + 2) / 64][Stage 118:======================================================>(63 + 1) / 64]                                                                                [Stage 119:====================================================>  (62 + 3) / 65]17/06/10 08:36:15 ERROR TaskSchedulerImpl: Lost executor 37 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:36:15 WARN TaskSetManager: Lost task 24.0 in stage 119.0 (TID 7749, 128.110.152.141): ExecutorLostFailure (executor 37 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:36:15 WARN TaskSetManager: Lost task 0.0 in stage 119.0 (TID 7725, 128.110.152.141): ExecutorLostFailure (executor 37 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 119:=====================================================> (63 + 2) / 65]17/06/10 08:36:22 ERROR TaskSchedulerImpl: Lost executor 21 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:36:22 WARN TaskSetManager: Lost task 0.1 in stage 119.0 (TID 7790, 128.110.152.142): ExecutorLostFailure (executor 21 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 119:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 30.103443102 seconds
res121: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=122 AND partitionZIndex<=129", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=122 AND partitionZIndex<=129,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049787496 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 120:=======================================>              (47 + 17) / 64][Stage 120:======================================================>(63 + 1) / 64]                                                                                [Stage 121:======================================================>(64 + 1) / 65]17/06/10 08:36:51 ERROR TaskSchedulerImpl: Lost executor 40 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:36:51 WARN TaskSetManager: Lost task 20.0 in stage 121.0 (TID 7877, 128.110.152.141): ExecutorLostFailure (executor 40 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 30.727551473 seconds
res123: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=201 AND partitionZIndex<=208", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=201 AND partitionZIndex<=208,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.069280912 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 08:37:05 ERROR TaskSchedulerImpl: Lost executor 35 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:37:05 WARN TaskSetManager: Lost task 48.0 in stage 122.0 (TID 7971, 128.110.152.145): ExecutorLostFailure (executor 35 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 122:=============================================>        (54 + 10) / 64][Stage 122:====================================================>  (61 + 3) / 64][Stage 122:=====================================================> (62 + 2) / 64][Stage 122:======================================================>(63 + 1) / 64]17/06/10 08:37:22 ERROR TaskSchedulerImpl: Lost executor 42 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:37:22 WARN TaskSetManager: Lost task 20.0 in stage 122.0 (TID 7943, 128.110.152.141): ExecutorLostFailure (executor 42 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 123:=======================================>              (47 + 18) / 65][Stage 123:============================================>         (54 + 11) / 65][Stage 123:====================================================>  (62 + 3) / 65][Stage 123:=====================================================> (63 + 2) / 65][Stage 123:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 43.199509896 seconds
res125: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=238 AND partitionZIndex<=245", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=238 AND partitionZIndex<=245,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051218682 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.707002057 seconds
res127: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=204 AND partitionZIndex<=211", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=204 AND partitionZIndex<=211,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057396026 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.676248096 seconds
res129: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=54 AND partitionZIndex<=61", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=54 AND partitionZIndex<=61,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051459822 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 128:====================================================>  (61 + 3) / 64][Stage 128:=====================================================> (62 + 2) / 64][Stage 128:======================================================>(63 + 1) / 64]17/06/10 08:38:11 ERROR TaskSchedulerImpl: Lost executor 44 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:38:11 WARN TaskSetManager: Lost task 23.0 in stage 128.0 (TID 8335, 128.110.152.141): ExecutorLostFailure (executor 44 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 129:============================================>         (54 + 11) / 65][Stage 129:====================================================>  (62 + 3) / 65]17/06/10 08:38:26 ERROR TaskSchedulerImpl: Lost executor 43 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:38:26 WARN TaskSetManager: Lost task 11.0 in stage 129.0 (TID 8388, 128.110.152.145): ExecutorLostFailure (executor 43 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:38:26 WARN TaskSetManager: Lost task 3.0 in stage 129.0 (TID 8380, 128.110.152.145): ExecutorLostFailure (executor 43 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 129:=====================================================> (63 + 2) / 65][Stage 129:======================================================>(64 + 1) / 65]17/06/10 08:38:38 ERROR TaskSchedulerImpl: Lost executor 45 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:38:38 WARN TaskSetManager: Lost task 11.1 in stage 129.0 (TID 8443, 128.110.152.141): ExecutorLostFailure (executor 45 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 51.682449055 seconds
res131: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=13 AND partitionZIndex<=20", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=13 AND partitionZIndex<=20,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055026475 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 130:=======================================>              (47 + 17) / 64][Stage 130:=====================================================> (62 + 2) / 64][Stage 130:======================================================>(63 + 1) / 64]                                                                                [Stage 131:=====================================================> (63 + 2) / 65][Stage 131:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 16.199932787 seconds
res133: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=67 AND partitionZIndex<=74", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=67 AND partitionZIndex<=74,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047267085 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 132:====================================================>  (61 + 3) / 64][Stage 132:======================================================>(63 + 1) / 64]                                                                                17/06/10 08:39:15 ERROR TaskSchedulerImpl: Lost executor 38 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:39:15 WARN TaskSetManager: Lost task 24.0 in stage 133.0 (TID 8662, 128.110.152.168): ExecutorLostFailure (executor 38 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:39:15 WARN TaskSetManager: Lost task 0.0 in stage 133.0 (TID 8638, 128.110.152.168): ExecutorLostFailure (executor 38 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 133:====================================================>  (62 + 3) / 65][Stage 133:=====================================================> (63 + 2) / 65][Stage 133:======================================================>(64 + 1) / 65]17/06/10 08:39:24 ERROR TransportResponseHandler: Still have 1 requests outstanding when connection from /128.110.152.165:35222 is closed
17/06/10 08:39:24 WARN BlockManagerMaster: Failed to remove broadcast 186 with removeFromMaster = true - Connection from /128.110.152.165:35222 closed
java.io.IOException: Connection from /128.110.152.165:35222 closed
	at org.apache.spark.network.client.TransportResponseHandler.channelInactive(TransportResponseHandler.java:128)
	at org.apache.spark.network.server.TransportChannelHandler.channelInactive(TransportChannelHandler.java:109)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at io.netty.handler.timeout.IdleStateHandler.channelInactive(IdleStateHandler.java:257)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at org.apache.spark.network.util.TransportFrameDecoder.channelInactive(TransportFrameDecoder.java:182)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.DefaultChannelPipeline.fireChannelInactive(DefaultChannelPipeline.java:828)
	at io.netty.channel.AbstractChannel$AbstractUnsafe$7.run(AbstractChannel.java:621)
	at io.netty.util.concurrent.SingleThreadEventExecutor.runAllTasks(SingleThreadEventExecutor.java:357)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:357)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 08:39:24 ERROR TaskSchedulerImpl: Lost executor 31 on 128.110.152.165: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:39:24 ERROR ContextCleaner: Error cleaning broadcast 186
org.apache.spark.SparkException: Exception thrown in awaitResult
	at org.apache.spark.rpc.RpcTimeout$$anonfun$1.applyOrElse(RpcTimeout.scala:77)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$1.applyOrElse(RpcTimeout.scala:75)
	at scala.runtime.AbstractPartialFunction.apply(AbstractPartialFunction.scala:36)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$addMessageIfTimeout$1.applyOrElse(RpcTimeout.scala:59)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$addMessageIfTimeout$1.applyOrElse(RpcTimeout.scala:59)
	at scala.PartialFunction$OrElse.apply(PartialFunction.scala:167)
	at org.apache.spark.rpc.RpcTimeout.awaitResult(RpcTimeout.scala:83)
	at org.apache.spark.storage.BlockManagerMaster.removeBroadcast(BlockManagerMaster.scala:143)
	at org.apache.spark.broadcast.TorrentBroadcast$.unpersist(TorrentBroadcast.scala:267)
	at org.apache.spark.broadcast.TorrentBroadcastFactory.unbroadcast(TorrentBroadcastFactory.scala:45)
	at org.apache.spark.broadcast.BroadcastManager.unbroadcast(BroadcastManager.scala:60)
	at org.apache.spark.ContextCleaner.doCleanupBroadcast(ContextCleaner.scala:232)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1$$anonfun$apply$mcV$sp$2.apply(ContextCleaner.scala:188)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1$$anonfun$apply$mcV$sp$2.apply(ContextCleaner.scala:179)
	at scala.Option.foreach(Option.scala:257)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1.apply$mcV$sp(ContextCleaner.scala:179)
	at org.apache.spark.util.Utils$.tryOrStopSparkContext(Utils.scala:1252)
	at org.apache.spark.ContextCleaner.org$apache$spark$ContextCleaner$$keepCleaning(ContextCleaner.scala:172)
	at org.apache.spark.ContextCleaner$$anon$1.run(ContextCleaner.scala:67)
Caused by: java.io.IOException: Connection from /128.110.152.165:35222 closed
	at org.apache.spark.network.client.TransportResponseHandler.channelInactive(TransportResponseHandler.java:128)
	at org.apache.spark.network.server.TransportChannelHandler.channelInactive(TransportChannelHandler.java:109)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at io.netty.handler.timeout.IdleStateHandler.channelInactive(IdleStateHandler.java:257)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at org.apache.spark.network.util.TransportFrameDecoder.channelInactive(TransportFrameDecoder.java:182)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.DefaultChannelPipeline.fireChannelInactive(DefaultChannelPipeline.java:828)
	at io.netty.channel.AbstractChannel$AbstractUnsafe$7.run(AbstractChannel.java:621)
	at io.netty.util.concurrent.SingleThreadEventExecutor.runAllTasks(SingleThreadEventExecutor.java:357)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:357)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 08:39:24 WARN TaskSetManager: Lost task 0.1 in stage 133.0 (TID 8703, 128.110.152.165): ExecutorLostFailure (executor 31 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:39:24 ERROR TransportClient: Failed to send RPC 6023223990236720556 to /128.110.152.165:35222: java.nio.channels.ClosedChannelException
java.nio.channels.ClosedChannelException
17/06/10 08:39:24 WARN BlockManagerMaster: Failed to remove broadcast 187 with removeFromMaster = true - Failed to send RPC 6023223990236720556 to /128.110.152.165:35222: java.nio.channels.ClosedChannelException
java.io.IOException: Failed to send RPC 6023223990236720556 to /128.110.152.165:35222: java.nio.channels.ClosedChannelException
	at org.apache.spark.network.client.TransportClient$3.operationComplete(TransportClient.java:249)
	at org.apache.spark.network.client.TransportClient$3.operationComplete(TransportClient.java:233)
	at io.netty.util.concurrent.DefaultPromise.notifyListener0(DefaultPromise.java:680)
	at io.netty.util.concurrent.DefaultPromise.notifyListeners(DefaultPromise.java:567)
	at io.netty.util.concurrent.DefaultPromise.tryFailure(DefaultPromise.java:424)
	at io.netty.channel.AbstractChannel$AbstractUnsafe.safeSetFailure(AbstractChannel.java:801)
	at io.netty.channel.AbstractChannel$AbstractUnsafe.write(AbstractChannel.java:699)
	at io.netty.channel.DefaultChannelPipeline$HeadContext.write(DefaultChannelPipeline.java:1122)
	at io.netty.channel.AbstractChannelHandlerContext.invokeWrite(AbstractChannelHandlerContext.java:633)
	at io.netty.channel.AbstractChannelHandlerContext.access$1900(AbstractChannelHandlerContext.java:32)
	at io.netty.channel.AbstractChannelHandlerContext$AbstractWriteTask.write(AbstractChannelHandlerContext.java:908)
	at io.netty.channel.AbstractChannelHandlerContext$WriteAndFlushTask.write(AbstractChannelHandlerContext.java:960)
	at io.netty.channel.AbstractChannelHandlerContext$AbstractWriteTask.run(AbstractChannelHandlerContext.java:893)
	at io.netty.util.concurrent.SingleThreadEventExecutor.runAllTasks(SingleThreadEventExecutor.java:357)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:357)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
Caused by: java.nio.channels.ClosedChannelException
17/06/10 08:39:24 ERROR ContextCleaner: Error cleaning broadcast 187
org.apache.spark.SparkException: Exception thrown in awaitResult
	at org.apache.spark.rpc.RpcTimeout$$anonfun$1.applyOrElse(RpcTimeout.scala:77)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$1.applyOrElse(RpcTimeout.scala:75)
	at scala.runtime.AbstractPartialFunction.apply(AbstractPartialFunction.scala:36)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$addMessageIfTimeout$1.applyOrElse(RpcTimeout.scala:59)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$addMessageIfTimeout$1.applyOrElse(RpcTimeout.scala:59)
	at scala.PartialFunction$OrElse.apply(PartialFunction.scala:167)
	at org.apache.spark.rpc.RpcTimeout.awaitResult(RpcTimeout.scala:83)
	at org.apache.spark.storage.BlockManagerMaster.removeBroadcast(BlockManagerMaster.scala:143)
	at org.apache.spark.broadcast.TorrentBroadcast$.unpersist(TorrentBroadcast.scala:267)
	at org.apache.spark.broadcast.TorrentBroadcastFactory.unbroadcast(TorrentBroadcastFactory.scala:45)
	at org.apache.spark.broadcast.BroadcastManager.unbroadcast(BroadcastManager.scala:60)
	at org.apache.spark.ContextCleaner.doCleanupBroadcast(ContextCleaner.scala:232)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1$$anonfun$apply$mcV$sp$2.apply(ContextCleaner.scala:188)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1$$anonfun$apply$mcV$sp$2.apply(ContextCleaner.scala:179)
	at scala.Option.foreach(Option.scala:257)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1.apply$mcV$sp(ContextCleaner.scala:179)
	at org.apache.spark.util.Utils$.tryOrStopSparkContext(Utils.scala:1252)
	at org.apache.spark.ContextCleaner.org$apache$spark$ContextCleaner$$keepCleaning(ContextCleaner.scala:172)
	at org.apache.spark.ContextCleaner$$anon$1.run(ContextCleaner.scala:67)
Caused by: java.io.IOException: Failed to send RPC 6023223990236720556 to /128.110.152.165:35222: java.nio.channels.ClosedChannelException
	at org.apache.spark.network.client.TransportClient$3.operationComplete(TransportClient.java:249)
	at org.apache.spark.network.client.TransportClient$3.operationComplete(TransportClient.java:233)
	at io.netty.util.concurrent.DefaultPromise.notifyListener0(DefaultPromise.java:680)
	at io.netty.util.concurrent.DefaultPromise.notifyListeners(DefaultPromise.java:567)
	at io.netty.util.concurrent.DefaultPromise.tryFailure(DefaultPromise.java:424)
	at io.netty.channel.AbstractChannel$AbstractUnsafe.safeSetFailure(AbstractChannel.java:801)
	at io.netty.channel.AbstractChannel$AbstractUnsafe.write(AbstractChannel.java:699)
	at io.netty.channel.DefaultChannelPipeline$HeadContext.write(DefaultChannelPipeline.java:1122)
	at io.netty.channel.AbstractChannelHandlerContext.invokeWrite(AbstractChannelHandlerContext.java:633)
	at io.netty.channel.AbstractChannelHandlerContext.access$1900(AbstractChannelHandlerContext.java:32)
	at io.netty.channel.AbstractChannelHandlerContext$AbstractWriteTask.write(AbstractChannelHandlerContext.java:908)
	at io.netty.channel.AbstractChannelHandlerContext$WriteAndFlushTask.write(AbstractChannelHandlerContext.java:960)
	at io.netty.channel.AbstractChannelHandlerContext$AbstractWriteTask.run(AbstractChannelHandlerContext.java:893)
	at io.netty.util.concurrent.SingleThreadEventExecutor.runAllTasks(SingleThreadEventExecutor.java:357)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:357)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
Caused by: java.nio.channels.ClosedChannelException
                                                                                Time elapsed: 24.650065015 seconds
res135: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=241 AND partitionZIndex<=248", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=241 AND partitionZIndex<=248,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.069454312 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 134:=======================================>              (47 + 17) / 64][Stage 134:===============================================>       (55 + 9) / 64][Stage 134:======================================================>(63 + 1) / 64]                                                                                [Stage 135:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 12.422123462 seconds
res137: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=46 AND partitionZIndex<=53", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=46 AND partitionZIndex<=53,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05618394 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 136:====================================================>  (61 + 3) / 64][Stage 136:======================================================>(63 + 1) / 64]                                                                                [Stage 137:====================================================>  (62 + 3) / 65]17/06/10 08:40:04 ERROR TaskSetManager: Total size of serialized results of 65 tasks (587.1 MB) is bigger than spark.driver.maxResultSize (512.0 MB)
org.apache.spark.SparkException: Job aborted due to stage failure: Total size of serialized results of 65 tasks (587.1 MB) is bigger than spark.driver.maxResultSize (512.0 MB)
  at org.apache.spark.scheduler.DAGScheduler.org$apache$spark$scheduler$DAGScheduler$$failJobAndIndependentStages(DAGScheduler.scala:1454)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$abortStage$1.apply(DAGScheduler.scala:1442)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$abortStage$1.apply(DAGScheduler.scala:1441)
  at scala.collection.mutable.ResizableArray$class.foreach(ResizableArray.scala:59)
  at scala.collection.mutable.ArrayBuffer.foreach(ArrayBuffer.scala:48)
  at org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:1441)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$handleTaskSetFailed$1.apply(DAGScheduler.scala:811)
  at org.apache.spark.scheduler.DAGScheduler$$anonfun$handleTaskSetFailed$1.apply(DAGScheduler.scala:811)
  at scala.Option.foreach(Option.scala:257)
  at org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:811)
  at org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:1667)
  at org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:1622)
  at org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:1611)
  at org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:48)
  at org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:632)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1873)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1886)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1899)
  at org.apache.spark.SparkContext.runJob(SparkContext.scala:1913)
  at org.apache.spark.rdd.RDD$$anonfun$collect$1.apply(RDD.scala:912)
  at org.apache.spark.rdd.RDDOperationScope$.withScope(RDDOperationScope.scala:151)
  at org.apache.spark.rdd.RDDOperationScope$.withScope(RDDOperationScope.scala:112)
  at org.apache.spark.rdd.RDD.withScope(RDD.scala:358)
  at org.apache.spark.rdd.RDD.collect(RDD.scala:911)
  at $anonfun$1.apply$mcI$sp(<console>:38)
  at $anonfun$1.apply(<console>:38)
  at $anonfun$1.apply(<console>:38)
  at show_timing(<console>:30)
  ... 50 elided

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=74 AND partitionZIndex<=81", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=74 AND partitionZIndex<=81,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049675614 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 138:=========================================>            (49 + 15) / 64][Stage 138:==========================================>           (50 + 14) / 64][Stage 138:===========================================>          (51 + 13) / 64][Stage 138:===========================================>          (52 + 12) / 64][Stage 138:============================================>         (53 + 11) / 64][Stage 138:=============================================>        (54 + 10) / 64][Stage 138:===============================================>       (55 + 9) / 64][Stage 138:================================================>      (56 + 8) / 64]17/06/10 08:40:24 WARN TransportChannelHandler: Exception in connection from /128.110.152.141:36552
java.io.IOException: Connection reset by peer
	at sun.nio.ch.FileDispatcherImpl.read0(Native Method)
	at sun.nio.ch.SocketDispatcher.read(SocketDispatcher.java:39)
	at sun.nio.ch.IOUtil.readIntoNativeBuffer(IOUtil.java:223)
	at sun.nio.ch.IOUtil.read(IOUtil.java:192)
	at sun.nio.ch.SocketChannelImpl.read(SocketChannelImpl.java:380)
	at io.netty.buffer.PooledUnsafeDirectByteBuf.setBytes(PooledUnsafeDirectByteBuf.java:313)
	at io.netty.buffer.AbstractByteBuf.writeBytes(AbstractByteBuf.java:881)
	at io.netty.channel.socket.nio.NioSocketChannel.doReadBytes(NioSocketChannel.java:242)
	at io.netty.channel.nio.AbstractNioByteChannel$NioByteUnsafe.read(AbstractNioByteChannel.java:119)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:511)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 08:40:24 WARN TransportChannelHandler: Exception in connection from /128.110.152.141:41086
java.io.IOException: Connection reset by peer
	at sun.nio.ch.FileDispatcherImpl.read0(Native Method)
	at sun.nio.ch.SocketDispatcher.read(SocketDispatcher.java:39)
	at sun.nio.ch.IOUtil.readIntoNativeBuffer(IOUtil.java:223)
	at sun.nio.ch.IOUtil.read(IOUtil.java:192)
	at sun.nio.ch.SocketChannelImpl.read(SocketChannelImpl.java:380)
	at io.netty.buffer.PooledUnsafeDirectByteBuf.setBytes(PooledUnsafeDirectByteBuf.java:313)
	at io.netty.buffer.AbstractByteBuf.writeBytes(AbstractByteBuf.java:881)
	at io.netty.channel.socket.nio.NioSocketChannel.doReadBytes(NioSocketChannel.java:242)
	at io.netty.channel.nio.AbstractNioByteChannel$NioByteUnsafe.read(AbstractNioByteChannel.java:119)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:511)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 08:40:24 ERROR TaskSchedulerImpl: Lost executor 47 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:40:24 ERROR TransportResponseHandler: Still have 1 requests outstanding when connection from /128.110.152.141:41086 is closed
17/06/10 08:40:24 ERROR OneForOneBlockFetcher: Failed while starting block fetches
java.io.IOException: Connection reset by peer
	at sun.nio.ch.FileDispatcherImpl.read0(Native Method)
	at sun.nio.ch.SocketDispatcher.read(SocketDispatcher.java:39)
	at sun.nio.ch.IOUtil.readIntoNativeBuffer(IOUtil.java:223)
	at sun.nio.ch.IOUtil.read(IOUtil.java:192)
	at sun.nio.ch.SocketChannelImpl.read(SocketChannelImpl.java:380)
	at io.netty.buffer.PooledUnsafeDirectByteBuf.setBytes(PooledUnsafeDirectByteBuf.java:313)
	at io.netty.buffer.AbstractByteBuf.writeBytes(AbstractByteBuf.java:881)
	at io.netty.channel.socket.nio.NioSocketChannel.doReadBytes(NioSocketChannel.java:242)
	at io.netty.channel.nio.AbstractNioByteChannel$NioByteUnsafe.read(AbstractNioByteChannel.java:119)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:511)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 08:40:24 WARN TaskSetManager: Lost task 37.0 in stage 138.0 (TID 9001, 128.110.152.141): ExecutorLostFailure (executor 47 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:40:24 WARN TaskSetManager: Lost task 13.0 in stage 138.0 (TID 8977, 128.110.152.141): ExecutorLostFailure (executor 47 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:40:24 WARN TaskSetManager: Lost task 61.0 in stage 138.0 (TID 9025, 128.110.152.141): ExecutorLostFailure (executor 47 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:40:24 WARN TaskSetManager: Lost task 45.0 in stage 138.0 (TID 9009, 128.110.152.141): ExecutorLostFailure (executor 47 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:40:24 WARN TaskSetManager: Lost task 21.0 in stage 138.0 (TID 8985, 128.110.152.141): ExecutorLostFailure (executor 47 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:40:24 WARN TaskSetManager: Lost task 53.0 in stage 138.0 (TID 9017, 128.110.152.141): ExecutorLostFailure (executor 47 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:40:24 WARN TaskSetManager: Lost task 29.0 in stage 138.0 (TID 8993, 128.110.152.141): ExecutorLostFailure (executor 47 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:40:24 WARN TaskSetManager: Lost task 5.0 in stage 138.0 (TID 8969, 128.110.152.141): ExecutorLostFailure (executor 47 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 18.51318271 seconds
res141: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=102 AND partitionZIndex<=109", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=102 AND partitionZIndex<=109,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058980231 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.575952193 seconds
res143: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=93 AND partitionZIndex<=100", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=93 AND partitionZIndex<=100,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047289085 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 08:40:29 ERROR RetryingBlockFetcher: Exception while beginning fetch of 1 outstanding blocks (after 1 retries)
java.io.IOException: Failed to connect to /128.110.152.141:41086
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:228)
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:179)
	at org.apache.spark.network.netty.NettyBlockTransferService$$anon$1.createAndStart(NettyBlockTransferService.scala:96)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.fetchAllOutstanding(RetryingBlockFetcher.java:140)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.access$200(RetryingBlockFetcher.java:43)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher$1.run(RetryingBlockFetcher.java:170)
	at java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:511)
	at java.util.concurrent.FutureTask.run(FutureTask.java:266)
	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)
	at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:617)
	at java.lang.Thread.run(Thread.java:748)
Caused by: java.net.ConnectException: Connection refused: /128.110.152.141:41086
	at sun.nio.ch.SocketChannelImpl.checkConnect(Native Method)
	at sun.nio.ch.SocketChannelImpl.finishConnect(SocketChannelImpl.java:717)
	at io.netty.channel.socket.nio.NioSocketChannel.doFinishConnect(NioSocketChannel.java:224)
	at io.netty.channel.nio.AbstractNioChannel$AbstractNioUnsafe.finishConnect(AbstractNioChannel.java:289)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:528)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	... 1 more
[Stage 142:=============================================>        (54 + 10) / 64]17/06/10 08:40:34 ERROR RetryingBlockFetcher: Exception while beginning fetch of 1 outstanding blocks (after 2 retries)
java.io.IOException: Failed to connect to /128.110.152.141:41086
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:228)
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:179)
	at org.apache.spark.network.netty.NettyBlockTransferService$$anon$1.createAndStart(NettyBlockTransferService.scala:96)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.fetchAllOutstanding(RetryingBlockFetcher.java:140)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.access$200(RetryingBlockFetcher.java:43)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher$1.run(RetryingBlockFetcher.java:170)
	at java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:511)
	at java.util.concurrent.FutureTask.run(FutureTask.java:266)
	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)
	at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:617)
	at java.lang.Thread.run(Thread.java:748)
Caused by: java.net.ConnectException: Connection refused: /128.110.152.141:41086
	at sun.nio.ch.SocketChannelImpl.checkConnect(Native Method)
	at sun.nio.ch.SocketChannelImpl.finishConnect(SocketChannelImpl.java:717)
	at io.netty.channel.socket.nio.NioSocketChannel.doFinishConnect(NioSocketChannel.java:224)
	at io.netty.channel.nio.AbstractNioChannel$AbstractNioUnsafe.finishConnect(AbstractNioChannel.java:289)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:528)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	... 1 more
[Stage 142:====================================================>  (61 + 3) / 64]17/06/10 08:40:36 ERROR TaskSchedulerImpl: Lost executor 46 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:40:36 WARN TaskSetManager: Lost task 8.0 in stage 142.0 (TID 9222, 128.110.152.145): ExecutorLostFailure (executor 46 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:40:36 WARN TaskSetManager: Lost task 0.0 in stage 142.0 (TID 9214, 128.110.152.145): ExecutorLostFailure (executor 46 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:40:39 ERROR RetryingBlockFetcher: Exception while beginning fetch of 1 outstanding blocks (after 3 retries)
java.io.IOException: Failed to connect to /128.110.152.141:41086
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:228)
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:179)
	at org.apache.spark.network.netty.NettyBlockTransferService$$anon$1.createAndStart(NettyBlockTransferService.scala:96)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.fetchAllOutstanding(RetryingBlockFetcher.java:140)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.access$200(RetryingBlockFetcher.java:43)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher$1.run(RetryingBlockFetcher.java:170)
	at java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:511)
	at java.util.concurrent.FutureTask.run(FutureTask.java:266)
	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)
	at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:617)
	at java.lang.Thread.run(Thread.java:748)
Caused by: java.net.ConnectException: Connection refused: /128.110.152.141:41086
	at sun.nio.ch.SocketChannelImpl.checkConnect(Native Method)
	at sun.nio.ch.SocketChannelImpl.finishConnect(SocketChannelImpl.java:717)
	at io.netty.channel.socket.nio.NioSocketChannel.doFinishConnect(NioSocketChannel.java:224)
	at io.netty.channel.nio.AbstractNioChannel$AbstractNioUnsafe.finishConnect(AbstractNioChannel.java:289)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:528)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	... 1 more
17/06/10 08:40:39 WARN BlockManager: Failed to fetch block after 1 fetch failures. Most recent failure cause:
org.apache.spark.SparkException: Exception thrown in awaitResult: 
	at org.apache.spark.util.ThreadUtils$.awaitResult(ThreadUtils.scala:194)
	at org.apache.spark.network.BlockTransferService.fetchBlockSync(BlockTransferService.scala:104)
	at org.apache.spark.storage.BlockManager.getRemoteBytes(BlockManager.scala:555)
	at org.apache.spark.scheduler.TaskResultGetter$$anon$2$$anonfun$run$1.apply$mcV$sp(TaskResultGetter.scala:76)
	at org.apache.spark.scheduler.TaskResultGetter$$anon$2$$anonfun$run$1.apply(TaskResultGetter.scala:57)
	at org.apache.spark.scheduler.TaskResultGetter$$anon$2$$anonfun$run$1.apply(TaskResultGetter.scala:57)
	at org.apache.spark.util.Utils$.logUncaughtExceptions(Utils.scala:1953)
	at org.apache.spark.scheduler.TaskResultGetter$$anon$2.run(TaskResultGetter.scala:56)
	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)
	at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:617)
	at java.lang.Thread.run(Thread.java:748)
Caused by: java.io.IOException: Failed to connect to /128.110.152.141:41086
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:228)
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:179)
	at org.apache.spark.network.netty.NettyBlockTransferService$$anon$1.createAndStart(NettyBlockTransferService.scala:96)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.fetchAllOutstanding(RetryingBlockFetcher.java:140)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.access$200(RetryingBlockFetcher.java:43)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher$1.run(RetryingBlockFetcher.java:170)
	at java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:511)
	at java.util.concurrent.FutureTask.run(FutureTask.java:266)
	... 3 more
Caused by: java.net.ConnectException: Connection refused: /128.110.152.141:41086
	at sun.nio.ch.SocketChannelImpl.checkConnect(Native Method)
	at sun.nio.ch.SocketChannelImpl.finishConnect(SocketChannelImpl.java:717)
	at io.netty.channel.socket.nio.NioSocketChannel.doFinishConnect(NioSocketChannel.java:224)
	at io.netty.channel.nio.AbstractNioChannel$AbstractNioUnsafe.finishConnect(AbstractNioChannel.java:289)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:528)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	... 1 more
17/06/10 08:40:39 WARN TaskSetManager: Lost task 50.0 in stage 137.0 (TID 8949, 128.110.152.141): TaskResultLost (result lost from block manager)
17/06/10 08:40:42 ERROR TaskSchedulerImpl: Lost executor 50 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:40:42 WARN TaskSetManager: Lost task 20.0 in stage 142.0 (TID 9234, 128.110.152.141): ExecutorLostFailure (executor 50 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:40:42 WARN TaskSetManager: Lost task 8.1 in stage 142.0 (TID 9279, 128.110.152.141): ExecutorLostFailure (executor 50 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 142:=====================================================> (62 + 2) / 64][Stage 142:======================================================>(63 + 1) / 64]                                                                                [Stage 143:=======================================>              (47 + 18) / 65][Stage 143:=======================================>              (48 + 17) / 65][Stage 143:===============================================>       (56 + 9) / 65][Stage 143:=====================================================> (63 + 2) / 65][Stage 143:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 38.972535422 seconds
res145: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=150 AND partitionZIndex<=157", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=150 AND partitionZIndex<=157,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.063247007 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.769342286 seconds
res147: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=137 AND partitionZIndex<=144", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=137 AND partitionZIndex<=144,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047737946 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.643669235 seconds
res149: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=163 AND partitionZIndex<=170", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=163 AND partitionZIndex<=170,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048030288 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.772050795 seconds
res151: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=133 AND partitionZIndex<=140", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=133 AND partitionZIndex<=140,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046872963 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 150:=====================================================> (62 + 2) / 64][Stage 150:======================================================>(63 + 1) / 64]                                                                                [Stage 151:=====================================================> (63 + 2) / 65][Stage 151:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 16.649986241 seconds
res153: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=123 AND partitionZIndex<=130", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=123 AND partitionZIndex<=130,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.067460443 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 152:======================================================>(63 + 1) / 64]                                                                                [Stage 153:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 18.323779542 seconds
res155: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=5 AND partitionZIndex<=12", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=5 AND partitionZIndex<=12,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053470869 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 154:=====================================================> (62 + 2) / 64][Stage 154:======================================================>(63 + 1) / 64]                                                                                [Stage 155:====================================================>  (62 + 3) / 65][Stage 155:=====================================================> (63 + 2) / 65][Stage 155:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 12.468168065 seconds
res157: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=134 AND partitionZIndex<=141", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=134 AND partitionZIndex<=141,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057791965 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 156:=====================================================> (62 + 2) / 64][Stage 156:======================================================>(63 + 1) / 64]                                                                                [Stage 157:=====================================================> (63 + 2) / 65][Stage 157:======================================================>(64 + 1) / 65]17/06/10 08:42:27 ERROR TaskSchedulerImpl: Lost executor 52 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:42:27 WARN TaskSetManager: Lost task 37.0 in stage 157.0 (TID 10222, 128.110.152.141): ExecutorLostFailure (executor 52 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 22.541806144 seconds
res159: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=76 AND partitionZIndex<=83", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=76 AND partitionZIndex<=83,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049434893 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 158:================================================>      (56 + 8) / 64]                                                                                Time elapsed: 5.729281113 seconds
res161: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=56 AND partitionZIndex<=63", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=56 AND partitionZIndex<=63,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046543721 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 160:>                                                       (0 + 0) / 64][Stage 160:====================================================>  (61 + 3) / 64][Stage 160:=====================================================> (62 + 2) / 64][Stage 160:======================================================>(63 + 1) / 64]                                                                                17/06/10 08:42:53 ERROR TaskSchedulerImpl: Lost executor 51 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:42:53 WARN TaskSetManager: Lost task 3.0 in stage 161.0 (TID 10447, 128.110.152.145): ExecutorLostFailure (executor 51 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:42:53 WARN TaskSetManager: Lost task 11.0 in stage 161.0 (TID 10455, 128.110.152.145): ExecutorLostFailure (executor 51 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 161:====================================================>  (62 + 3) / 65][Stage 161:=====================================================> (63 + 2) / 65][Stage 161:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 19.362478388 seconds
res163: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=99 AND partitionZIndex<=106", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=99 AND partitionZIndex<=106,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045974539 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 162:================================================>      (56 + 8) / 64]                                                                                Time elapsed: 5.514578821 seconds
res165: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=14 AND partitionZIndex<=21", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=14 AND partitionZIndex<=21,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056679921 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 08:43:14 ERROR TaskSchedulerImpl: Lost executor 34 on 128.110.152.157: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:43:14 WARN TaskSetManager: Lost task 12.0 in stage 164.0 (TID 10652, 128.110.152.157): ExecutorLostFailure (executor 34 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 164:====================================================>  (61 + 3) / 64][Stage 164:=====================================================> (62 + 2) / 64][Stage 164:======================================================>(63 + 1) / 64]                                                                                [Stage 165:============================================>         (54 + 11) / 65][Stage 165:=============================================>        (55 + 10) / 65][Stage 165:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.253054696 seconds
res167: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=30 AND partitionZIndex<=37", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=30 AND partitionZIndex<=37,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047530385 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 166:=====================================================> (62 + 2) / 64][Stage 166:======================================================>(63 + 1) / 64]                                                                                [Stage 167:=====================================================> (63 + 2) / 65]17/06/10 08:43:45 ERROR TaskSchedulerImpl: Lost executor 41 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:43:45 WARN TaskSetManager: Lost task 0.0 in stage 167.0 (TID 10834, 128.110.152.142): ExecutorLostFailure (executor 41 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:43:48 ERROR TaskSchedulerImpl: Lost executor 54 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:43:48 WARN TaskSetManager: Lost task 11.0 in stage 167.0 (TID 10845, 128.110.152.145): ExecutorLostFailure (executor 54 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 167:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 27.565497575 seconds
res169: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=224 AND partitionZIndex<=231", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=224 AND partitionZIndex<=231,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05149995 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 168:=======================================>              (47 + 17) / 64][Stage 168:=============================================>        (54 + 10) / 64][Stage 168:=====================================================> (62 + 2) / 64][Stage 168:======================================================>(63 + 1) / 64]                                                                                [Stage 169:=====================================================> (63 + 2) / 65]                                                                                Time elapsed: 18.499994439 seconds
res171: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=172 AND partitionZIndex<=179", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=172 AND partitionZIndex<=179,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.064976003 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.708364041 seconds
res173: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=42 AND partitionZIndex<=49", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=42 AND partitionZIndex<=49,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.043487249 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 172:====================================================>  (61 + 3) / 64][Stage 172:=====================================================> (62 + 2) / 64][Stage 172:======================================================>(63 + 1) / 64]                                                                                [Stage 173:====================================================>  (62 + 3) / 65][Stage 173:=====================================================> (63 + 2) / 65][Stage 173:======================================================>(64 + 1) / 65]17/06/10 08:44:36 ERROR TaskSchedulerImpl: Lost executor 57 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:44:36 WARN TaskSetManager: Lost task 20.0 in stage 173.0 (TID 11243, 128.110.152.145): ExecutorLostFailure (executor 57 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 21.933619051 seconds
res175: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=196 AND partitionZIndex<=203", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=196 AND partitionZIndex<=203,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.064506462 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 174:===============================================>       (55 + 9) / 64][Stage 174:====================================================>  (61 + 3) / 64][Stage 174:=====================================================> (62 + 2) / 64][Stage 174:======================================================>(63 + 1) / 64]                                                                                [Stage 175:====================================================>  (62 + 3) / 65][Stage 175:=====================================================> (63 + 2) / 65][Stage 175:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 22.425378034 seconds
res177: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=160 AND partitionZIndex<=167", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=160 AND partitionZIndex<=167,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046813458 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 176:====================================================>  (61 + 3) / 64][Stage 176:=====================================================> (62 + 2) / 64]                                                                                [Stage 177:====================================================>  (62 + 3) / 65][Stage 177:=====================================================> (63 + 2) / 65]17/06/10 08:45:26 ERROR TaskSchedulerImpl: Lost executor 53 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:45:26 WARN TaskSetManager: Lost task 37.0 in stage 177.0 (TID 11519, 128.110.152.141): ExecutorLostFailure (executor 53 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 177:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 20.526922528 seconds
res179: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=44 AND partitionZIndex<=51", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=44 AND partitionZIndex<=51,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057760806 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 178:===============================================>       (55 + 9) / 64][Stage 178:====================================================>  (61 + 3) / 64][Stage 178:=====================================================> (62 + 2) / 64]17/06/10 08:45:48 ERROR TaskSchedulerImpl: Lost executor 59 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:45:48 WARN TaskSetManager: Lost task 0.0 in stage 178.0 (TID 11548, 128.110.152.141): ExecutorLostFailure (executor 59 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:45:48 WARN TaskSetManager: Lost task 8.0 in stage 178.0 (TID 11556, 128.110.152.141): ExecutorLostFailure (executor 59 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 178:======================================================>(63 + 1) / 64]                                                                                [Stage 179:=============================================>        (55 + 10) / 65][Stage 179:===============================================>       (56 + 9) / 65][Stage 179:=====================================================> (63 + 2) / 65][Stage 179:======================================================>(64 + 1) / 65][Stage 179:======================================================>(64 + 1) / 65]17/06/10 08:47:18 WARN TransportChannelHandler: Exception in connection from /128.110.152.141:38729
java.io.IOException: Connection reset by peer
	at sun.nio.ch.FileDispatcherImpl.read0(Native Method)
	at sun.nio.ch.SocketDispatcher.read(SocketDispatcher.java:39)
	at sun.nio.ch.IOUtil.readIntoNativeBuffer(IOUtil.java:223)
	at sun.nio.ch.IOUtil.read(IOUtil.java:192)
	at sun.nio.ch.SocketChannelImpl.read(SocketChannelImpl.java:380)
	at io.netty.buffer.PooledUnsafeDirectByteBuf.setBytes(PooledUnsafeDirectByteBuf.java:313)
	at io.netty.buffer.AbstractByteBuf.writeBytes(AbstractByteBuf.java:881)
	at io.netty.channel.socket.nio.NioSocketChannel.doReadBytes(NioSocketChannel.java:242)
	at io.netty.channel.nio.AbstractNioByteChannel$NioByteUnsafe.read(AbstractNioByteChannel.java:119)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:511)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 08:47:18 ERROR TaskSchedulerImpl: Lost executor 60 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:47:18 ERROR TransportResponseHandler: Still have 1 requests outstanding when connection from /128.110.152.141:38729 is closed
17/06/10 08:47:18 ERROR OneForOneBlockFetcher: Failed while starting block fetches
java.io.IOException: Connection reset by peer
	at sun.nio.ch.FileDispatcherImpl.read0(Native Method)
	at sun.nio.ch.SocketDispatcher.read(SocketDispatcher.java:39)
	at sun.nio.ch.IOUtil.readIntoNativeBuffer(IOUtil.java:223)
	at sun.nio.ch.IOUtil.read(IOUtil.java:192)
	at sun.nio.ch.SocketChannelImpl.read(SocketChannelImpl.java:380)
	at io.netty.buffer.PooledUnsafeDirectByteBuf.setBytes(PooledUnsafeDirectByteBuf.java:313)
	at io.netty.buffer.AbstractByteBuf.writeBytes(AbstractByteBuf.java:881)
	at io.netty.channel.socket.nio.NioSocketChannel.doReadBytes(NioSocketChannel.java:242)
	at io.netty.channel.nio.AbstractNioByteChannel$NioByteUnsafe.read(AbstractNioByteChannel.java:119)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:511)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 08:47:18 WARN TaskSetManager: Lost task 20.0 in stage 179.0 (TID 11634, 128.110.152.141): ExecutorLostFailure (executor 60 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:47:23 ERROR RetryingBlockFetcher: Exception while beginning fetch of 1 outstanding blocks (after 1 retries)
java.io.IOException: Failed to connect to /128.110.152.141:38729
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:228)
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:179)
	at org.apache.spark.network.netty.NettyBlockTransferService$$anon$1.createAndStart(NettyBlockTransferService.scala:96)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.fetchAllOutstanding(RetryingBlockFetcher.java:140)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.access$200(RetryingBlockFetcher.java:43)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher$1.run(RetryingBlockFetcher.java:170)
	at java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:511)
	at java.util.concurrent.FutureTask.run(FutureTask.java:266)
	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)
	at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:617)
	at java.lang.Thread.run(Thread.java:748)
Caused by: java.net.ConnectException: Connection refused: /128.110.152.141:38729
	at sun.nio.ch.SocketChannelImpl.checkConnect(Native Method)
	at sun.nio.ch.SocketChannelImpl.finishConnect(SocketChannelImpl.java:717)
	at io.netty.channel.socket.nio.NioSocketChannel.doFinishConnect(NioSocketChannel.java:224)
	at io.netty.channel.nio.AbstractNioChannel$AbstractNioUnsafe.finishConnect(AbstractNioChannel.java:289)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:528)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	... 1 more
                                                                                17/06/10 08:47:28 ERROR RetryingBlockFetcher: Exception while beginning fetch of 1 outstanding blocks (after 2 retries)
java.io.IOException: Failed to connect to /128.110.152.141:38729
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:228)
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:179)
	at org.apache.spark.network.netty.NettyBlockTransferService$$anon$1.createAndStart(NettyBlockTransferService.scala:96)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.fetchAllOutstanding(RetryingBlockFetcher.java:140)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.access$200(RetryingBlockFetcher.java:43)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher$1.run(RetryingBlockFetcher.java:170)
	at java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:511)
	at java.util.concurrent.FutureTask.run(FutureTask.java:266)
	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)
	at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:617)
	at java.lang.Thread.run(Thread.java:748)
Caused by: java.net.ConnectException: Connection refused: /128.110.152.141:38729
	at sun.nio.ch.SocketChannelImpl.checkConnect(Native Method)
	at sun.nio.ch.SocketChannelImpl.finishConnect(SocketChannelImpl.java:717)
	at io.netty.channel.socket.nio.NioSocketChannel.doFinishConnect(NioSocketChannel.java:224)
	at io.netty.channel.nio.AbstractNioChannel$AbstractNioUnsafe.finishConnect(AbstractNioChannel.java:289)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:528)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	... 1 more
Time elapsed: 113.416721882 seconds
res181: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=87 AND partitionZIndex<=94", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=87 AND partitionZIndex<=94,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056523743 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 180:==========================================>           (50 + 14) / 64][Stage 180:============================================>         (53 + 11) / 64]17/06/10 08:47:33 ERROR RetryingBlockFetcher: Exception while beginning fetch of 1 outstanding blocks (after 3 retries)
java.io.IOException: Failed to connect to /128.110.152.141:38729
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:228)
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:179)
	at org.apache.spark.network.netty.NettyBlockTransferService$$anon$1.createAndStart(NettyBlockTransferService.scala:96)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.fetchAllOutstanding(RetryingBlockFetcher.java:140)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.access$200(RetryingBlockFetcher.java:43)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher$1.run(RetryingBlockFetcher.java:170)
	at java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:511)
	at java.util.concurrent.FutureTask.run(FutureTask.java:266)
	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)
	at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:617)
	at java.lang.Thread.run(Thread.java:748)
Caused by: java.net.ConnectException: Connection refused: /128.110.152.141:38729
	at sun.nio.ch.SocketChannelImpl.checkConnect(Native Method)
	at sun.nio.ch.SocketChannelImpl.finishConnect(SocketChannelImpl.java:717)
	at io.netty.channel.socket.nio.NioSocketChannel.doFinishConnect(NioSocketChannel.java:224)
	at io.netty.channel.nio.AbstractNioChannel$AbstractNioUnsafe.finishConnect(AbstractNioChannel.java:289)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:528)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	... 1 more
17/06/10 08:47:33 WARN BlockManager: Failed to fetch block after 1 fetch failures. Most recent failure cause:
org.apache.spark.SparkException: Exception thrown in awaitResult: 
	at org.apache.spark.util.ThreadUtils$.awaitResult(ThreadUtils.scala:194)
	at org.apache.spark.network.BlockTransferService.fetchBlockSync(BlockTransferService.scala:104)
	at org.apache.spark.storage.BlockManager.getRemoteBytes(BlockManager.scala:555)
	at org.apache.spark.scheduler.TaskResultGetter$$anon$2$$anonfun$run$1.apply$mcV$sp(TaskResultGetter.scala:76)
	at org.apache.spark.scheduler.TaskResultGetter$$anon$2$$anonfun$run$1.apply(TaskResultGetter.scala:57)
	at org.apache.spark.scheduler.TaskResultGetter$$anon$2$$anonfun$run$1.apply(TaskResultGetter.scala:57)
	at org.apache.spark.util.Utils$.logUncaughtExceptions(Utils.scala:1953)
	at org.apache.spark.scheduler.TaskResultGetter$$anon$2.run(TaskResultGetter.scala:56)
	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)
	at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:617)
	at java.lang.Thread.run(Thread.java:748)
Caused by: java.io.IOException: Failed to connect to /128.110.152.141:38729
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:228)
	at org.apache.spark.network.client.TransportClientFactory.createClient(TransportClientFactory.java:179)
	at org.apache.spark.network.netty.NettyBlockTransferService$$anon$1.createAndStart(NettyBlockTransferService.scala:96)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.fetchAllOutstanding(RetryingBlockFetcher.java:140)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher.access$200(RetryingBlockFetcher.java:43)
	at org.apache.spark.network.shuffle.RetryingBlockFetcher$1.run(RetryingBlockFetcher.java:170)
	at java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:511)
	at java.util.concurrent.FutureTask.run(FutureTask.java:266)
	... 3 more
Caused by: java.net.ConnectException: Connection refused: /128.110.152.141:38729
	at sun.nio.ch.SocketChannelImpl.checkConnect(Native Method)
	at sun.nio.ch.SocketChannelImpl.finishConnect(SocketChannelImpl.java:717)
	at io.netty.channel.socket.nio.NioSocketChannel.doFinishConnect(NioSocketChannel.java:224)
	at io.netty.channel.nio.AbstractNioChannel$AbstractNioUnsafe.finishConnect(AbstractNioChannel.java:289)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:528)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	... 1 more
[Stage 180:====================================================>  (61 + 3) / 64][Stage 180:=====================================================> (62 + 2) / 64][Stage 180:======================================================>(63 + 1) / 64]                                                                                17/06/10 08:47:40 ERROR TaskSchedulerImpl: Lost executor 48 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:47:40 WARN TaskSetManager: Lost task 20.0 in stage 181.0 (TID 11764, 128.110.152.168): ExecutorLostFailure (executor 48 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:47:40 WARN TaskSetManager: Lost task 64.0 in stage 181.0 (TID 11808, 128.110.152.168): ExecutorLostFailure (executor 48 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 181:====================================================>  (62 + 3) / 65][Stage 181:=====================================================> (63 + 2) / 65][Stage 181:======================================================>(64 + 1) / 65]17/06/10 08:47:49 ERROR TaskSchedulerImpl: Lost executor 49 on 128.110.152.165: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:47:49 WARN TaskSetManager: Lost task 8.0 in stage 181.0 (TID 11752, 128.110.152.165): ExecutorLostFailure (executor 49 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 26.025922269 seconds
res183: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=26 AND partitionZIndex<=33", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=26 AND partitionZIndex<=33,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055538281 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 182:=======================================>              (47 + 17) / 64][Stage 182:=====================================================> (62 + 2) / 64][Stage 182:======================================================>(63 + 1) / 64]                                                                                [Stage 183:=====================================================> (63 + 2) / 65][Stage 183:======================================================>(64 + 1) / 65]17/06/10 08:48:20 ERROR TaskSchedulerImpl: Lost executor 58 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:48:20 WARN TaskSetManager: Lost task 11.0 in stage 183.0 (TID 11887, 128.110.152.145): ExecutorLostFailure (executor 58 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 31.254863541 seconds
res185: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=51 AND partitionZIndex<=58", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=51 AND partitionZIndex<=58,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045132915 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 184:============================================>         (53 + 11) / 64][Stage 184:====================================================>  (61 + 3) / 64]17/06/10 08:48:39 ERROR TaskSchedulerImpl: Lost executor 29 on 128.110.152.160: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:48:39 WARN TaskSetManager: Lost task 24.0 in stage 184.0 (TID 11966, 128.110.152.160): ExecutorLostFailure (executor 29 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:48:39 WARN TaskSetManager: Lost task 0.0 in stage 184.0 (TID 11942, 128.110.152.160): ExecutorLostFailure (executor 29 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 184:=====================================================> (62 + 2) / 64][Stage 184:======================================================>(63 + 1) / 64]                                                                                [Stage 185:============================================>         (54 + 11) / 65][Stage 185:====================================================>  (62 + 3) / 65][Stage 185:=====================================================> (63 + 2) / 65][Stage 185:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 23.59591136 seconds
res187: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=236 AND partitionZIndex<=243", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=236 AND partitionZIndex<=243,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045098875 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 186:=====================================================> (62 + 2) / 64][Stage 186:======================================================>(63 + 1) / 64]                                                                                [Stage 187:=====================================================> (63 + 2) / 65][Stage 187:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 17.259111554 seconds
res189: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=36 AND partitionZIndex<=43", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=36 AND partitionZIndex<=43,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050359089 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 188:====================================================>  (61 + 3) / 64][Stage 188:=====================================================> (62 + 2) / 64][Stage 188:======================================================>(63 + 1) / 64]17/06/10 08:49:26 ERROR TaskSchedulerImpl: Lost executor 56 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:49:26 WARN TaskSetManager: Lost task 8.0 in stage 188.0 (TID 12210, 128.110.152.142): ExecutorLostFailure (executor 56 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 189:===============================================>       (56 + 9) / 65][Stage 189:===================================================>   (61 + 4) / 65][Stage 189:====================================================>  (62 + 3) / 65][Stage 189:=====================================================> (63 + 2) / 65][Stage 189:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 32.52009351 seconds
res191: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=211 AND partitionZIndex<=218", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=211 AND partitionZIndex<=218,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.071173402 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 190:====================================================>  (61 + 3) / 64][Stage 190:=====================================================> (62 + 2) / 64]17/06/10 08:50:14 ERROR TaskSchedulerImpl: Lost executor 61 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:50:14 WARN TaskSetManager: Lost task 24.0 in stage 190.0 (TID 12356, 128.110.152.141): ExecutorLostFailure (executor 61 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:50:14 WARN TaskSetManager: Lost task 48.0 in stage 190.0 (TID 12380, 128.110.152.141): ExecutorLostFailure (executor 61 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 190:======================================================>(63 + 1) / 64]                                                                                [Stage 191:============================================>         (54 + 11) / 65]17/06/10 08:50:26 ERROR TaskSchedulerImpl: Lost executor 39 on 128.110.152.152: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:50:26 WARN TaskSetManager: Lost task 48.0 in stage 191.0 (TID 12446, 128.110.152.152): ExecutorLostFailure (executor 39 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:50:26 WARN TaskSetManager: Lost task 24.0 in stage 191.0 (TID 12422, 128.110.152.152): ExecutorLostFailure (executor 39 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 191:====================================================>  (62 + 3) / 65][Stage 191:=====================================================> (63 + 2) / 65][Stage 191:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 42.321848481 seconds
res193: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=227 AND partitionZIndex<=234", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=227 AND partitionZIndex<=234,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045543477 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 192:=============================================>        (54 + 10) / 64][Stage 192:=====================================================> (62 + 2) / 64][Stage 192:======================================================>(63 + 1) / 64]                                                                                17/06/10 08:50:45 ERROR TaskSchedulerImpl: Lost executor 64 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:50:45 WARN TaskSetManager: Lost task 50.0 in stage 193.0 (TID 12579, 128.110.152.145): ExecutorLostFailure (executor 64 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 193:=====================================================> (63 + 2) / 65][Stage 193:======================================================>(64 + 1) / 65]17/06/10 08:50:54 ERROR TaskSchedulerImpl: Lost executor 55 on 128.110.152.157: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:50:54 WARN TaskSetManager: Lost task 37.0 in stage 193.0 (TID 12566, 128.110.152.157): ExecutorLostFailure (executor 55 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:51:04 ERROR TaskSchedulerImpl: Lost executor 67 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:51:04 WARN TaskSetManager: Lost task 37.1 in stage 193.0 (TID 12595, 128.110.152.141): ExecutorLostFailure (executor 67 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 37.556039976 seconds
res195: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=242 AND partitionZIndex<=249", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=242 AND partitionZIndex<=249,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045943899 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 194:=================================>                    (40 + 24) / 64][Stage 194:======================================>               (46 + 18) / 64][Stage 194:================================================>      (56 + 8) / 64]                                                                                Time elapsed: 5.733579953 seconds
res197: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=18 AND partitionZIndex<=25", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=18 AND partitionZIndex<=25,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.043420092 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 196:====================================================>  (61 + 3) / 64][Stage 196:=====================================================> (62 + 2) / 64]                                                                                [Stage 197:====================================================>  (62 + 3) / 65][Stage 197:=====================================================> (63 + 2) / 65][Stage 197:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.936158809 seconds
res199: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=62 AND partitionZIndex<=69", 8))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=62 AND partitionZIndex<=69,8))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050601911 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 198:====================================================>  (61 + 3) / 64][Stage 198:======================================================>(63 + 1) / 64]                                                                                [Stage 199:====================================================>  (62 + 3) / 65]17/06/10 08:51:57 ERROR TaskSchedulerImpl: Lost executor 69 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:51:57 WARN TaskSetManager: Lost task 24.0 in stage 199.0 (TID 12943, 128.110.152.145): ExecutorLostFailure (executor 69 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:51:57 WARN TaskSetManager: Lost task 0.0 in stage 199.0 (TID 12919, 128.110.152.145): ExecutorLostFailure (executor 69 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 199:=====================================================> (63 + 2) / 65][Stage 199:======================================================>(64 + 1) / 65]17/06/10 08:52:06 ERROR TaskSchedulerImpl: Lost executor 71 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 08:52:06 WARN TaskSetManager: Lost task 0.1 in stage 199.0 (TID 12984, 128.110.152.141): ExecutorLostFailure (executor 71 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 32.171944771 seconds
res201: Int = 0

scala> 

scala> :quit
17/06/10 08:52:14 ERROR Utils: Uncaught exception in thread driver-revive-thread
org.apache.spark.SparkException: Could not find CoarseGrainedScheduler.
	at org.apache.spark.rpc.netty.Dispatcher.postMessage(Dispatcher.scala:154)
	at org.apache.spark.rpc.netty.Dispatcher.postOneWayMessage(Dispatcher.scala:134)
	at org.apache.spark.rpc.netty.NettyRpcEnv.send(NettyRpcEnv.scala:186)
	at org.apache.spark.rpc.netty.NettyRpcEndpointRef.send(NettyRpcEnv.scala:513)
	at org.apache.spark.scheduler.cluster.CoarseGrainedSchedulerBackend$DriverEndpoint$$anon$1$$anonfun$run$1$$anonfun$apply$mcV$sp$1.apply(CoarseGrainedSchedulerBackend.scala:117)
	at org.apache.spark.scheduler.cluster.CoarseGrainedSchedulerBackend$DriverEndpoint$$anon$1$$anonfun$run$1$$anonfun$apply$mcV$sp$1.apply(CoarseGrainedSchedulerBackend.scala:117)
	at scala.Option.foreach(Option.scala:257)
	at org.apache.spark.scheduler.cluster.CoarseGrainedSchedulerBackend$DriverEndpoint$$anon$1$$anonfun$run$1.apply$mcV$sp(CoarseGrainedSchedulerBackend.scala:117)
	at org.apache.spark.util.Utils$.tryLogNonFatalError(Utils.scala:1290)
	at org.apache.spark.scheduler.cluster.CoarseGrainedSchedulerBackend$DriverEndpoint$$anon$1.run(CoarseGrainedSchedulerBackend.scala:116)
	at java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:511)
	at java.util.concurrent.FutureTask.runAndReset(FutureTask.java:308)
	at java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.access$301(ScheduledThreadPoolExecutor.java:180)
	at java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(ScheduledThreadPoolExecutor.java:294)
	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)
	at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:617)
	at java.lang.Thread.run(Thread.java:748)
