Using Spark's default log4j profile: org/apache/spark/log4j-defaults.properties
Setting default log level to "WARN".
To adjust logging level use sc.setLogLevel(newLevel).
17/06/10 04:04:26 WARN NativeCodeLoader: Unable to load native-hadoop library for your platform... using builtin-java classes where applicable
17/06/10 04:04:29 WARN SparkContext: Use an existing SparkContext, some configuration may not take effect.
Spark context Web UI available at http://128.110.152.156:4040
Spark context available as 'sc' (master = spark://ctl:7077, app id = app-20170610040429-0058).
Spark session available as 'spark'.
Welcome to
      ____              __
     / __/__  ___ _____/ /__
    _\ \/ _ \/ _ `/ __/  '_/
   /___/ .__/\_,_/_/ /_/\_\   version 2.0.2
      /_/
         
Using Scala version 2.11.8 (OpenJDK 64-Bit Server VM, Java 1.8.0_131)
Type in expressions to have them evaluated.
Type :help for more information.

scala>  
     | import java.io.File
import java.io.File

scala> import java.io.FileOutputStream
import java.io.FileOutputStream

scala> import org.apache.spark.sql._
import org.apache.spark.sql._

scala> 

scala> def show_timing[T](proc: => T): T = {
     |     val start=System.nanoTime()
     |     val res = proc
     |     val end = System.nanoTime()
     |     println("Time elapsed: " + (end-start)/1000000000.0 + " seconds")
     |     res
     | }
show_timing: [T](proc: => T)T

scala> 

scala> val writeToLocal = (in:(Array[Byte], Long, String)) =>{
     |     val bytes = in._1
     |     val output = in._3
     |     
     |     val writer = new FileOutputStream(output)
     |     writer.write(bytes)
     |     writer.close
     |     1
     |   }
writeToLocal: ((Array[Byte], Long, String)) => Int = <function1>

scala> 

scala> val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)
warning: there was one deprecation warning; re-run with -deprecation for details
sqlContext: org.apache.spark.sql.hive.HiveContext = org.apache.spark.sql.hive.HiveContext@74cd798f

scala>   
     | val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=222 AND partitionZIndex<=222", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=222 AND partitionZIndex<=222,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 15.813777992 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 0:>                                                        (0 + 96) / 96][Stage 0:================================>                       (55 + 41) / 96][Stage 0:=======================================================> (94 + 2) / 96][Stage 0:========================================================>(95 + 1) / 96]                                                                                [Stage 1:=======================================================> (95 + 2) / 97][Stage 1:========================================================>(96 + 1) / 97]                                                                                Time elapsed: 21.891137012 seconds
res3: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=98 AND partitionZIndex<=98", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=98 AND partitionZIndex<=98,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.16041378 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 2:=================================>                      (56 + 39) / 95][Stage 2:=======================================================> (93 + 2) / 95][Stage 2:========================================================>(94 + 1) / 95]                                                                                [Stage 3:=======================================================> (93 + 3) / 96][Stage 3:=======================================================> (94 + 2) / 96][Stage 3:========================================================>(95 + 1) / 96]                                                                                Time elapsed: 16.625523189 seconds
res5: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=147 AND partitionZIndex<=147", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=147 AND partitionZIndex<=147,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.177744422 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 4:>                                                         (0 + 0) / 95]                                                                                Time elapsed: 1.240277818 seconds
res7: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=12 AND partitionZIndex<=12", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=12 AND partitionZIndex<=12,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.125965066 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 6:=======================================================> (94 + 2) / 96][Stage 6:========================================================>(95 + 1) / 96]                                                                                [Stage 7:=======================================================> (95 + 2) / 97][Stage 7:========================================================>(96 + 1) / 97]                                                                                Time elapsed: 12.83447849 seconds
res9: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=210 AND partitionZIndex<=210", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=210 AND partitionZIndex<=210,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.099931039 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 1.217182425 seconds
res11: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=134 AND partitionZIndex<=134", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=134 AND partitionZIndex<=134,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.110233966 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 10:=======================================================>(95 + 1) / 96]17/06/10 04:06:26 ERROR TaskSchedulerImpl: Lost executor 2 on 128.110.152.146: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:06:26 WARN TaskSetManager: Lost task 30.0 in stage 10.0 (TID 991, 128.110.152.146): ExecutorLostFailure (executor 2 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 11:=======================================================>(96 + 1) / 97]                                                                                Time elapsed: 29.839762882 seconds
res13: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=123 AND partitionZIndex<=123", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=123 AND partitionZIndex<=123,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.097873424 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 12:=======================================================>(87 + 1) / 88]                                                                                [Stage 13:=======================================================>(88 + 1) / 89]                                                                                Time elapsed: 15.109492592 seconds
res15: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=116 AND partitionZIndex<=116", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=116 AND partitionZIndex<=116,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.083650462 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 14:======================================================> (86 + 2) / 88][Stage 14:=======================================================>(87 + 1) / 88]                                                                                [Stage 15:======================================================> (87 + 2) / 89]17/06/10 04:07:21 ERROR TaskSchedulerImpl: Lost executor 9 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:07:21 WARN TaskSetManager: Lost task 17.0 in stage 15.0 (TID 1437, 128.110.152.145): ExecutorLostFailure (executor 9 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 15:=======================================================>(88 + 1) / 89]                                                                                Time elapsed: 23.535955625 seconds
res17: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=65 AND partitionZIndex<=65", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=65 AND partitionZIndex<=65,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.134346025 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 16:==================================>                    (56 + 33) / 89][Stage 16:==================================>                    (56 + 33) / 89]17/06/10 04:08:57 ERROR TaskSchedulerImpl: Lost executor 7 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:08:57 WARN TaskSetManager: Lost task 0.0 in stage 16.0 (TID 1510, 128.110.152.141): ExecutorLostFailure (executor 7 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:08:57 WARN TaskSetManager: Lost task 77.0 in stage 16.0 (TID 1587, 128.110.152.141): ExecutorLostFailure (executor 7 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:08:57 WARN TaskSetManager: Lost task 44.0 in stage 16.0 (TID 1554, 128.110.152.141): ExecutorLostFailure (executor 7 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:08:57 WARN TaskSetManager: Lost task 11.0 in stage 16.0 (TID 1521, 128.110.152.141): ExecutorLostFailure (executor 7 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:08:57 WARN TaskSetManager: Lost task 22.0 in stage 16.0 (TID 1532, 128.110.152.141): ExecutorLostFailure (executor 7 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:08:57 WARN TaskSetManager: Lost task 55.0 in stage 16.0 (TID 1565, 128.110.152.141): ExecutorLostFailure (executor 7 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:08:57 WARN TaskSetManager: Lost task 66.0 in stage 16.0 (TID 1576, 128.110.152.141): ExecutorLostFailure (executor 7 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:08:57 WARN TaskSetManager: Lost task 33.0 in stage 16.0 (TID 1543, 128.110.152.141): ExecutorLostFailure (executor 7 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 16:======================================>                (62 + 27) / 89][Stage 16:======================================>                (63 + 26) / 89][Stage 16:=======================================>               (64 + 25) / 89][Stage 16:========================================>              (65 + 24) / 89][Stage 16:============================================>          (72 + 17) / 89][Stage 16:==================================================>     (81 + 8) / 89]                                                                                [Stage 17:================================================>      (79 + 11) / 90][Stage 17:======================================================> (87 + 3) / 90][Stage 17:======================================================> (88 + 2) / 90][Stage 17:=======================================================>(89 + 1) / 90]17/06/10 04:09:28 ERROR TaskSchedulerImpl: Lost executor 11 on 128.110.152.155: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:09:28 WARN TaskSetManager: Lost task 27.0 in stage 17.0 (TID 1634, 128.110.152.155): ExecutorLostFailure (executor 11 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 124.356757704 seconds
res19: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=38 AND partitionZIndex<=38", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=38 AND partitionZIndex<=38,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.090383965 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 18:================================================>      (78 + 10) / 88][Stage 18:======================================================> (86 + 2) / 88][Stage 18:=======================================================>(87 + 1) / 88]17/06/10 04:09:45 ERROR TaskSchedulerImpl: Lost executor 14 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:09:45 WARN TaskSetManager: Lost task 50.0 in stage 18.0 (TID 1748, 128.110.152.141): ExecutorLostFailure (executor 14 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 19:================================================>      (79 + 10) / 89][Stage 19:======================================================> (87 + 2) / 89][Stage 19:=======================================================>(88 + 1) / 89]                                                                                Time elapsed: 19.781050996 seconds
res21: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=79 AND partitionZIndex<=79", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=79 AND partitionZIndex<=79,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.078190479 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 20:======================================================> (86 + 3) / 89][Stage 20:======================================================> (87 + 2) / 89][Stage 20:=======================================================>(88 + 1) / 89]17/06/10 04:10:10 ERROR TaskSchedulerImpl: Lost executor 10 on 128.110.152.163: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:10:10 WARN TaskSetManager: Lost task 27.0 in stage 20.0 (TID 1903, 128.110.152.163): ExecutorLostFailure (executor 10 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 21:======================================================> (87 + 3) / 90][Stage 21:======================================================> (88 + 2) / 90][Stage 21:=======================================================>(89 + 1) / 90]                                                                                Time elapsed: 27.97466063 seconds
res23: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=59 AND partitionZIndex<=59", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=59 AND partitionZIndex<=59,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.081229557 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 22:=======================================================>(79 + 1) / 80]                                                                                [Stage 23:=======================================================>(80 + 1) / 81]                                                                                Time elapsed: 10.264674757 seconds
res25: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=168 AND partitionZIndex<=168", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=168 AND partitionZIndex<=168,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.068189031 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.826364844 seconds
res27: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=237 AND partitionZIndex<=237", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=237 AND partitionZIndex<=237,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.06887465 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 26:======================================================> (78 + 2) / 80]17/06/10 04:10:54 ERROR TaskSchedulerImpl: Lost executor 13 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:10:54 WARN TaskSetManager: Lost task 59.0 in stage 26.0 (TID 2437, 128.110.152.145): ExecutorLostFailure (executor 13 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:10:54 ERROR TaskSchedulerImpl: Lost executor 16 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:10:54 WARN TaskSetManager: Lost task 59.1 in stage 26.0 (TID 2458, 128.110.152.141): ExecutorLostFailure (executor 16 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 26:=======================================================>(79 + 1) / 80]                                                                                [Stage 27:==========================================>            (63 + 18) / 81][Stage 27:================================================>      (71 + 10) / 81][Stage 27:======================================================> (79 + 2) / 81][Stage 27:=======================================================>(80 + 1) / 81]                                                                                Time elapsed: 21.863819329 seconds
res29: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=200 AND partitionZIndex<=200", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=200 AND partitionZIndex<=200,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.067122713 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.893633373 seconds
res31: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=94 AND partitionZIndex<=94", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=94 AND partitionZIndex<=94,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.09008763 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 30:======================================================> (78 + 2) / 80][Stage 30:=======================================================>(79 + 1) / 80]                                                                                [Stage 31:======================================================> (79 + 2) / 81][Stage 31:=======================================================>(80 + 1) / 81]                                                                                Time elapsed: 15.12364828 seconds
res33: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=234 AND partitionZIndex<=234", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=234 AND partitionZIndex<=234,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.072432669 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 32:======================================================> (78 + 2) / 80][Stage 32:=======================================================>(79 + 1) / 80]                                                                                [Stage 33:======================================================> (79 + 2) / 81][Stage 33:=======================================================>(80 + 1) / 81]                                                                                Time elapsed: 13.151164935 seconds
res35: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=244 AND partitionZIndex<=244", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=244 AND partitionZIndex<=244,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.110170933 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.646384695 seconds
res37: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=111 AND partitionZIndex<=111", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=111 AND partitionZIndex<=111,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.081228162 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 36:======================================================> (78 + 2) / 80][Stage 36:=======================================================>(79 + 1) / 80]                                                                                [Stage 37:======================================================> (79 + 2) / 81][Stage 37:=======================================================>(80 + 1) / 81]                                                                                Time elapsed: 14.84117413 seconds
res39: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=4 AND partitionZIndex<=4", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=4 AND partitionZIndex<=4,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.065176558 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 38:=======================================================>(79 + 1) / 80]                                                                                [Stage 39:=======================================================>(80 + 1) / 81]                                                                                Time elapsed: 8.480298979 seconds
res41: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=250 AND partitionZIndex<=250", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=250 AND partitionZIndex<=250,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.075589148 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.684213213 seconds
res43: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=199 AND partitionZIndex<=199", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=199 AND partitionZIndex<=199,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.065716938 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 42:=====================================================>  (77 + 3) / 80][Stage 42:======================================================> (78 + 2) / 80][Stage 42:=======================================================>(79 + 1) / 80]                                                                                [Stage 43:=====================================================>  (78 + 3) / 81][Stage 43:======================================================> (79 + 2) / 81][Stage 43:=======================================================>(80 + 1) / 81]                                                                                Time elapsed: 13.995308879 seconds
res45: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=248 AND partitionZIndex<=248", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=248 AND partitionZIndex<=248,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057154307 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.572400786 seconds
res47: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=142 AND partitionZIndex<=142", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=142 AND partitionZIndex<=142,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.062272503 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 46:>                                                        (0 + 0) / 80]                                                                                Time elapsed: 0.67780557 seconds
res49: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=194 AND partitionZIndex<=194", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=194 AND partitionZIndex<=194,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.068337716 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 48:=====================================================>  (77 + 3) / 80][Stage 48:======================================================> (78 + 2) / 80][Stage 48:=======================================================>(79 + 1) / 80]                                                                                [Stage 49:=====================================================>  (78 + 3) / 81][Stage 49:======================================================> (79 + 2) / 81][Stage 49:=======================================================>(80 + 1) / 81]                                                                                Time elapsed: 17.012594442 seconds
res51: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=189 AND partitionZIndex<=189", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=189 AND partitionZIndex<=189,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.068929597 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.686217692 seconds
res53: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=213 AND partitionZIndex<=213", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=213 AND partitionZIndex<=213,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054260431 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.729386454 seconds
res55: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=224 AND partitionZIndex<=224", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=224 AND partitionZIndex<=224,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.064037602 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.51671513 seconds
res57: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=173 AND partitionZIndex<=173", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=173 AND partitionZIndex<=173,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056871328 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 04:13:12 ERROR TaskSchedulerImpl: Lost executor 15 on 128.110.152.155: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:13:12 WARN TaskSetManager: Lost task 44.0 in stage 56.0 (TID 4839, 128.110.152.155): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 56:=====================================================>  (77 + 3) / 80][Stage 56:======================================================> (78 + 2) / 80][Stage 56:=======================================================>(79 + 1) / 80]17/06/10 04:13:21 ERROR TaskSchedulerImpl: Lost executor 8 on 128.110.152.152: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:13:21 WARN TaskSetManager: Lost task 25.0 in stage 56.0 (TID 4820, 128.110.152.152): ExecutorLostFailure (executor 8 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 57:===========================================>           (64 + 17) / 81][Stage 57:================================================>      (71 + 10) / 81][Stage 57:=====================================================>  (78 + 3) / 81]17/06/10 04:13:41 ERROR TaskSchedulerImpl: Lost executor 0 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:13:41 WARN TaskSetManager: Lost task 25.0 in stage 57.0 (TID 4902, 128.110.152.142): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 57:======================================================> (79 + 2) / 81][Stage 57:=======================================================>(80 + 1) / 81]                                                                                Time elapsed: 37.386023373 seconds
res59: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=49 AND partitionZIndex<=49", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=49 AND partitionZIndex<=49,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057762629 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 58:===============================================>       (69 + 11) / 80][Stage 58:=====================================================>  (77 + 3) / 80][Stage 58:======================================================> (78 + 2) / 80][Stage 58:=======================================================>(79 + 1) / 80]                                                                                [Stage 59:=====================================================>  (78 + 3) / 81][Stage 59:======================================================> (79 + 2) / 81][Stage 59:=======================================================>(80 + 1) / 81]                                                                                Time elapsed: 17.710697875 seconds
res61: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=226 AND partitionZIndex<=226", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=226 AND partitionZIndex<=226,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.074676495 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 60:======================================================> (78 + 2) / 80][Stage 60:=======================================================>(79 + 1) / 80]                                                                                [Stage 61:======================================================> (79 + 2) / 81]17/06/10 04:14:28 ERROR TaskSchedulerImpl: Lost executor 17 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:14:28 WARN TaskSetManager: Lost task 61.0 in stage 61.0 (TID 5261, 128.110.152.145): ExecutorLostFailure (executor 17 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 61:=======================================================>(80 + 1) / 81]                                                                                Time elapsed: 24.588578192 seconds
res63: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=8 AND partitionZIndex<=8", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=8 AND partitionZIndex<=8,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057925451 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 62:================================================>      (70 + 10) / 80][Stage 62:=================================================>      (71 + 9) / 80]                                                                                [Stage 63:======================================================> (79 + 2) / 81][Stage 63:=======================================================>(80 + 1) / 81]                                                                                Time elapsed: 11.159013802 seconds
res65: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=227 AND partitionZIndex<=227", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=227 AND partitionZIndex<=227,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.068822582 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.797907569 seconds
res67: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=83 AND partitionZIndex<=83", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=83 AND partitionZIndex<=83,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052239216 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 66:=====================================================>  (77 + 3) / 80][Stage 66:======================================================> (78 + 2) / 80]17/06/10 04:15:14 ERROR TaskSchedulerImpl: Lost executor 18 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:15:14 WARN TaskSetManager: Lost task 0.0 in stage 66.0 (TID 5604, 128.110.152.141): ExecutorLostFailure (executor 18 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:15:14 WARN TaskSetManager: Lost task 10.0 in stage 66.0 (TID 5614, 128.110.152.141): ExecutorLostFailure (executor 18 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 66:=======================================================>(79 + 1) / 80]                                                                                [Stage 67:===============================================>       (70 + 11) / 81][Stage 67:=====================================================>  (78 + 3) / 81][Stage 67:======================================================> (79 + 2) / 81][Stage 67:=======================================================>(80 + 1) / 81]                                                                                Time elapsed: 36.360000763 seconds
res69: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=152 AND partitionZIndex<=152", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=152 AND partitionZIndex<=152,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.068796684 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 68:======================================================> (78 + 2) / 80][Stage 68:=======================================================>(79 + 1) / 80]                                                                                [Stage 69:======================================================> (79 + 2) / 81][Stage 69:=======================================================>(80 + 1) / 81]                                                                                Time elapsed: 14.159190309 seconds
res71: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=138 AND partitionZIndex<=138", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=138 AND partitionZIndex<=138,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054772476 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 70:======================================================> (78 + 2) / 80]                                                                                [Stage 71:======================================================> (79 + 2) / 81][Stage 71:=======================================================>(80 + 1) / 81]                                                                                Time elapsed: 15.965846666 seconds
res73: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=128 AND partitionZIndex<=128", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=128 AND partitionZIndex<=128,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055700456 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 72:=======================================================>(79 + 1) / 80]                                                                                [Stage 73:=======================================================>(80 + 1) / 81]                                                                                Time elapsed: 14.746566988 seconds
res75: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=29 AND partitionZIndex<=29", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=29 AND partitionZIndex<=29,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.078607499 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 74:======================================================> (78 + 2) / 80][Stage 74:=======================================================>(79 + 1) / 80]                                                                                [Stage 75:======================================================> (79 + 2) / 81][Stage 75:=======================================================>(80 + 1) / 81]                                                                                Time elapsed: 13.99766727 seconds
res77: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=172 AND partitionZIndex<=172", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=172 AND partitionZIndex<=172,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055975917 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 76:=====================================================>  (77 + 3) / 80]17/06/10 04:16:47 ERROR TaskSchedulerImpl: Lost executor 5 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:16:47 WARN TaskSetManager: Lost task 64.0 in stage 76.0 (TID 6475, 128.110.152.168): ExecutorLostFailure (executor 5 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 76:======================================================> (78 + 2) / 80][Stage 76:=======================================================>(79 + 1) / 80]17/06/10 04:17:07 ERROR TaskSchedulerImpl: Lost executor 4 on 128.110.152.144: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:17:07 WARN TaskSetManager: Lost task 47.0 in stage 76.0 (TID 6458, 128.110.152.144): ExecutorLostFailure (executor 4 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 77:==========================================>            (62 + 19) / 81][Stage 77:===============================================>       (70 + 11) / 81][Stage 77:=====================================================>  (78 + 3) / 81][Stage 77:======================================================> (79 + 2) / 81][Stage 77:=======================================================>(80 + 1) / 81]                                                                                Time elapsed: 42.739474313 seconds
res79: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=53 AND partitionZIndex<=53", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=53 AND partitionZIndex<=53,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.104717823 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 78:=====================================================>  (77 + 3) / 80][Stage 78:======================================================> (78 + 2) / 80][Stage 78:=======================================================>(79 + 1) / 80]                                                                                [Stage 79:=====================================================>  (78 + 3) / 81][Stage 79:======================================================> (79 + 2) / 81][Stage 79:=======================================================>(80 + 1) / 81]                                                                                Time elapsed: 15.033379642 seconds
res81: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=47 AND partitionZIndex<=47", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=47 AND partitionZIndex<=47,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056846698 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 04:17:43 ERROR TaskSchedulerImpl: Lost executor 19 on 128.110.152.155: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:17:43 WARN TaskSetManager: Lost task 14.0 in stage 80.0 (TID 6749, 128.110.152.155): ExecutorLostFailure (executor 19 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 80:=====================================================>  (77 + 3) / 80][Stage 80:======================================================> (78 + 2) / 80]                                                                                [Stage 81:===============================================>       (70 + 11) / 81][Stage 81:=====================================================>  (78 + 3) / 81][Stage 81:======================================================> (79 + 2) / 81][Stage 81:=======================================================>(80 + 1) / 81]                                                                                Time elapsed: 15.324752297 seconds
res83: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=163 AND partitionZIndex<=163", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=163 AND partitionZIndex<=163,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.06930225 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 82:=====================================================>  (77 + 3) / 80][Stage 82:======================================================> (78 + 2) / 80][Stage 82:=======================================================>(79 + 1) / 80]                                                                                [Stage 83:=====================================================>  (78 + 3) / 81][Stage 83:======================================================> (79 + 2) / 81][Stage 83:=======================================================>(80 + 1) / 81]17/06/10 04:18:15 ERROR TaskSchedulerImpl: Lost executor 23 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:18:15 WARN TaskSetManager: Lost task 31.0 in stage 83.0 (TID 7008, 128.110.152.141): ExecutorLostFailure (executor 23 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 21.604505305 seconds
res85: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=78 AND partitionZIndex<=78", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=78 AND partitionZIndex<=78,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051721143 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 84:==================================================>     (72 + 8) / 80]                                                                                Time elapsed: 5.647189972 seconds
res87: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=21 AND partitionZIndex<=21", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=21 AND partitionZIndex<=21,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054675062 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 86:=====================================================>  (77 + 3) / 80][Stage 86:======================================================> (78 + 2) / 80][Stage 86:=======================================================>(79 + 1) / 80]                                                                                [Stage 87:=====================================================>  (78 + 3) / 81]                                                                                Time elapsed: 10.97551016 seconds
res89: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=131 AND partitionZIndex<=131", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=131 AND partitionZIndex<=131,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057331081 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.679588271 seconds
res91: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=216 AND partitionZIndex<=216", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=216 AND partitionZIndex<=216,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054075383 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 90:======================================================> (78 + 2) / 80][Stage 90:=======================================================>(79 + 1) / 80]                                                                                [Stage 91:======================================================> (79 + 2) / 81][Stage 91:=======================================================>(80 + 1) / 81]                                                                                Time elapsed: 18.031542709 seconds
res93: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=103 AND partitionZIndex<=103", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=103 AND partitionZIndex<=103,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.067466378 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 92:======================================================> (78 + 2) / 80][Stage 92:=======================================================>(79 + 1) / 80]                                                                                17/06/10 04:19:15 ERROR TaskSchedulerImpl: Lost executor 1 on 128.110.152.165: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:19:15 WARN TaskSetManager: Lost task 14.0 in stage 93.0 (TID 7797, 128.110.152.165): ExecutorLostFailure (executor 1 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 93:======================================================> (79 + 2) / 81][Stage 93:=======================================================>(80 + 1) / 81]                                                                                Time elapsed: 14.496666019 seconds
res95: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=19 AND partitionZIndex<=19", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=19 AND partitionZIndex<=19,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057202219 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 94:===============================================>       (69 + 11) / 80][Stage 94:================================================>      (70 + 10) / 80][Stage 94:======================================================> (78 + 2) / 80][Stage 94:=======================================================>(79 + 1) / 80]                                                                                [Stage 95:=====================================================>  (78 + 3) / 81][Stage 95:======================================================> (79 + 2) / 81][Stage 95:=======================================================>(80 + 1) / 81]17/06/10 04:19:36 ERROR TaskSchedulerImpl: Lost executor 24 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:19:36 WARN TaskSetManager: Lost task 26.0 in stage 95.0 (TID 7971, 128.110.152.168): ExecutorLostFailure (executor 24 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:19:36 ERROR TaskSchedulerImpl: Lost executor 22 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:19:36 WARN TaskSetManager: Lost task 26.1 in stage 95.0 (TID 8026, 128.110.152.145): ExecutorLostFailure (executor 22 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 17.569100443 seconds
res97: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=198 AND partitionZIndex<=198", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=198 AND partitionZIndex<=198,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053906992 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 96:>                                                        (0 + 0) / 80][Stage 96:============================================>          (64 + 16) / 80][Stage 96:==================================================>     (72 + 8) / 80]                                                                                Time elapsed: 5.737292993 seconds
res99: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=105 AND partitionZIndex<=105", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=105 AND partitionZIndex<=105,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05184656 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 98:======================================================> (78 + 2) / 80][Stage 98:=======================================================>(79 + 1) / 80]                                                                                [Stage 99:======================================================> (79 + 2) / 81]17/06/10 04:20:00 ERROR TaskSchedulerImpl: Lost executor 21 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:20:00 WARN TaskSetManager: Lost task 10.0 in stage 99.0 (TID 8279, 128.110.152.142): ExecutorLostFailure (executor 21 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 99:=======================================================>(80 + 1) / 81]                                                                                Time elapsed: 17.06682389 seconds
res101: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=252 AND partitionZIndex<=252", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=252 AND partitionZIndex<=252,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.068895296 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 100:================================================>      (71 + 9) / 80][Stage 100:====================================================>  (77 + 3) / 80]                                                                                [Stage 101:======================================================>(80 + 1) / 81]                                                                                Time elapsed: 11.882553162 seconds
res103: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=64 AND partitionZIndex<=64", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=64 AND partitionZIndex<=64,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.067522723 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 102:====================================================>  (77 + 3) / 80][Stage 102:=====================================================> (78 + 2) / 80][Stage 102:======================================================>(79 + 1) / 80]                                                                                [Stage 103:====================================================>  (78 + 3) / 81][Stage 103:=====================================================> (79 + 2) / 81][Stage 103:======================================================>(80 + 1) / 81]                                                                                Time elapsed: 16.654073894 seconds
res105: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=220 AND partitionZIndex<=220", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=220 AND partitionZIndex<=220,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050549468 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.657037743 seconds
res107: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=170 AND partitionZIndex<=170", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=170 AND partitionZIndex<=170,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047162561 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.699212824 seconds
res109: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=221 AND partitionZIndex<=221", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=221 AND partitionZIndex<=221,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.059537134 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 108:=====================================================> (78 + 2) / 80][Stage 108:======================================================>(79 + 1) / 80]                                                                                [Stage 109:=====================================================> (79 + 2) / 81][Stage 109:======================================================>(80 + 1) / 81]                                                                                Time elapsed: 16.765374756 seconds
res111: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=7 AND partitionZIndex<=7", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=7 AND partitionZIndex<=7,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050180931 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 110:=====================================================> (78 + 2) / 80][Stage 110:======================================================>(79 + 1) / 80]                                                                                [Stage 111:=====================================================> (79 + 2) / 81][Stage 111:======================================================>(80 + 1) / 81]                                                                                Time elapsed: 12.398700686 seconds
res113: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=204 AND partitionZIndex<=204", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=204 AND partitionZIndex<=204,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.073674223 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.572090846 seconds
res115: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=73 AND partitionZIndex<=73", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=73 AND partitionZIndex<=73,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.071502931 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 114:====================================================>  (77 + 3) / 80]17/06/10 04:21:26 ERROR TaskSchedulerImpl: Lost executor 25 on 128.110.152.144: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:21:26 WARN TaskSetManager: Lost task 30.0 in stage 114.0 (TID 9508, 128.110.152.144): ExecutorLostFailure (executor 25 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:21:26 WARN TaskSetManager: Lost task 0.0 in stage 114.0 (TID 9478, 128.110.152.144): ExecutorLostFailure (executor 25 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 114:=====================================================> (78 + 2) / 80]                                                                                [Stage 115:===============================================>      (71 + 10) / 81][Stage 115:====================================================>  (78 + 3) / 81][Stage 115:=====================================================> (79 + 2) / 81][Stage 115:======================================================>(80 + 1) / 81]                                                                                Time elapsed: 21.600162361 seconds
res117: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=247 AND partitionZIndex<=247", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=247 AND partitionZIndex<=247,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049384575 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 116:======================================================>(79 + 1) / 80]                                                                                [Stage 117:======================================================>(80 + 1) / 81]                                                                                Time elapsed: 11.525969715 seconds
res119: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=28 AND partitionZIndex<=28", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=28 AND partitionZIndex<=28,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050029933 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 118:=====================================================> (78 + 2) / 80][Stage 118:======================================================>(79 + 1) / 80]                                                                                [Stage 119:=====================================================> (79 + 2) / 81][Stage 119:======================================================>(80 + 1) / 81]                                                                                Time elapsed: 15.392371715 seconds
res121: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=212 AND partitionZIndex<=212", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=212 AND partitionZIndex<=212,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.059587779 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.58396725 seconds
res123: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=166 AND partitionZIndex<=166", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=166 AND partitionZIndex<=166,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047792082 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.610520533 seconds
res125: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=235 AND partitionZIndex<=235", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=235 AND partitionZIndex<=235,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047344285 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 124:=====================================================> (78 + 2) / 80][Stage 124:======================================================>(79 + 1) / 80]                                                                                [Stage 125:=====================================================> (79 + 2) / 81][Stage 125:======================================================>(80 + 1) / 81]                                                                                Time elapsed: 12.613936159 seconds
res127: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=129 AND partitionZIndex<=129", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=129 AND partitionZIndex<=129,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.073755708 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 126:======================================================>(79 + 1) / 80]                                                                                17/06/10 04:22:48 ERROR TaskSchedulerImpl: Lost executor 30 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:22:48 WARN TaskSetManager: Lost task 30.0 in stage 127.0 (TID 10556, 128.110.152.145): ExecutorLostFailure (executor 30 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 127:======================================================>(80 + 1) / 81]                                                                                Time elapsed: 17.055200996 seconds
res129: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=42 AND partitionZIndex<=42", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=42 AND partitionZIndex<=42,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050012276 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 128:==============================================>       (69 + 11) / 80][Stage 128:===============================================>      (70 + 10) / 80][Stage 128:================================================>      (71 + 9) / 80][Stage 128:======================================================>(79 + 1) / 80]                                                                                [Stage 129:====================================================>  (78 + 3) / 81][Stage 129:=====================================================> (79 + 2) / 81][Stage 129:======================================================>(80 + 1) / 81]                                                                                Time elapsed: 11.604937636 seconds
res131: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=209 AND partitionZIndex<=209", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=209 AND partitionZIndex<=209,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049542038 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 130:====================================================>  (77 + 3) / 80][Stage 130:=====================================================> (78 + 2) / 80][Stage 130:======================================================>(79 + 1) / 80]                                                                                17/06/10 04:23:21 ERROR TaskSchedulerImpl: Lost executor 26 on 128.110.152.155: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:23:21 WARN TaskSetManager: Lost task 24.0 in stage 131.0 (TID 10873, 128.110.152.155): ExecutorLostFailure (executor 26 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:23:21 WARN TaskSetManager: Lost task 54.0 in stage 131.0 (TID 10903, 128.110.152.155): ExecutorLostFailure (executor 26 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:23:21 WARN TaskSetManager: Lost task 44.0 in stage 131.0 (TID 10893, 128.110.152.155): ExecutorLostFailure (executor 26 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:23:21 WARN TaskSetManager: Lost task 74.0 in stage 131.0 (TID 10923, 128.110.152.155): ExecutorLostFailure (executor 26 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:23:21 WARN TaskSetManager: Lost task 14.0 in stage 131.0 (TID 10863, 128.110.152.155): ExecutorLostFailure (executor 26 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:23:21 WARN TaskSetManager: Lost task 34.0 in stage 131.0 (TID 10883, 128.110.152.155): ExecutorLostFailure (executor 26 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:23:21 WARN TaskSetManager: Lost task 64.0 in stage 131.0 (TID 10913, 128.110.152.155): ExecutorLostFailure (executor 26 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:23:21 WARN TaskSetManager: Lost task 4.0 in stage 131.0 (TID 10853, 128.110.152.155): ExecutorLostFailure (executor 26 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:23:21 ERROR TaskSchedulerImpl: Lost executor 27 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:23:21 WARN TaskSetManager: Lost task 30.0 in stage 131.0 (TID 10879, 128.110.152.141): ExecutorLostFailure (executor 27 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:23:21 WARN TaskSetManager: Lost task 60.0 in stage 131.0 (TID 10909, 128.110.152.141): ExecutorLostFailure (executor 27 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:23:21 WARN TaskSetManager: Lost task 0.0 in stage 131.0 (TID 10849, 128.110.152.141): ExecutorLostFailure (executor 27 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:23:21 WARN TaskSetManager: Lost task 74.1 in stage 131.0 (TID 10934, 128.110.152.141): ExecutorLostFailure (executor 27 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:23:21 WARN TaskSetManager: Lost task 10.0 in stage 131.0 (TID 10859, 128.110.152.141): ExecutorLostFailure (executor 27 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 131:====================================================>  (78 + 3) / 81][Stage 131:=====================================================> (79 + 2) / 81]17/06/10 04:23:28 ERROR TaskSchedulerImpl: Lost executor 6 on 128.110.152.157: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:23:28 WARN TaskSetManager: Lost task 47.0 in stage 131.0 (TID 10896, 128.110.152.157): ExecutorLostFailure (executor 6 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 131:======================================================>(80 + 1) / 81]                                                                                Time elapsed: 24.271165353 seconds
res133: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=135 AND partitionZIndex<=135", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=135 AND partitionZIndex<=135,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051447433 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 132:=====================================>                (55 + 25) / 80][Stage 132:======================================================>(79 + 1) / 80]                                                                                [Stage 133:======================================================>(80 + 1) / 81]17/06/10 04:23:56 ERROR TaskSchedulerImpl: Lost executor 35 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:23:56 WARN TaskSetManager: Lost task 25.0 in stage 133.0 (TID 11049, 128.110.152.141): ExecutorLostFailure (executor 35 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 25.968931757 seconds
res135: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=182 AND partitionZIndex<=182", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=182 AND partitionZIndex<=182,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053201408 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 134:=================================================>     (72 + 8) / 80]                                                                                Time elapsed: 5.817829581 seconds
res137: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=39 AND partitionZIndex<=39", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=39 AND partitionZIndex<=39,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054477123 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 136:=====================================================> (78 + 2) / 80]                                                                                [Stage 137:=====================================================> (79 + 2) / 81][Stage 137:======================================================>(80 + 1) / 81]17/06/10 04:24:26 ERROR TaskSchedulerImpl: Lost executor 29 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:24:26 WARN TaskSetManager: Lost task 45.0 in stage 137.0 (TID 11392, 128.110.152.168): ExecutorLostFailure (executor 29 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:25:01 ERROR TaskSchedulerImpl: Lost executor 33 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:25:01 WARN TaskSetManager: Lost task 45.1 in stage 137.0 (TID 11428, 128.110.152.145): ExecutorLostFailure (executor 33 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:25:07 ERROR TaskSchedulerImpl: Lost executor 37 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:25:07 WARN TaskSetManager: Lost task 45.2 in stage 137.0 (TID 11429, 128.110.152.141): ExecutorLostFailure (executor 37 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 58.854087599 seconds
res139: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=108 AND partitionZIndex<=108", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=108 AND partitionZIndex<=108,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049039125 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 138:>                                                       (0 + 0) / 80][Stage 138:====================================>                 (54 + 26) / 80][Stage 138:=====================================================> (78 + 2) / 80]                                                                                [Stage 139:=====================================================> (79 + 2) / 81][Stage 139:======================================================>(80 + 1) / 81]                                                                                Time elapsed: 15.472113326 seconds
res141: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=240 AND partitionZIndex<=240", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=240 AND partitionZIndex<=240,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051977475 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.715297002 seconds
res143: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=141 AND partitionZIndex<=141", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=141 AND partitionZIndex<=141,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051292618 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 142:=====================================================> (78 + 2) / 80][Stage 142:======================================================>(79 + 1) / 80]17/06/10 04:25:42 ERROR TaskSchedulerImpl: Lost executor 20 on 128.110.152.152: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:25:42 WARN TaskSetManager: Lost task 30.0 in stage 142.0 (TID 11783, 128.110.152.152): ExecutorLostFailure (executor 20 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 143:===============================================>      (71 + 10) / 81][Stage 143:=====================================================> (79 + 2) / 81][Stage 143:======================================================>(80 + 1) / 81]                                                                                Time elapsed: 21.564272641 seconds
res145: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=33 AND partitionZIndex<=33", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=33 AND partitionZIndex<=33,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047437793 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 144:======================================================>(79 + 1) / 80]                                                                                [Stage 145:======================================================>(80 + 1) / 81]                                                                                Time elapsed: 13.487764952 seconds
res147: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=52 AND partitionZIndex<=52", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=52 AND partitionZIndex<=52,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.069431836 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 146:====================================================>  (77 + 3) / 80][Stage 146:=====================================================> (78 + 2) / 80]                                                                                [Stage 147:====================================================>  (78 + 3) / 81]17/06/10 04:26:23 ERROR TaskSchedulerImpl: Lost executor 32 on 128.110.152.144: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:26:23 WARN TaskSetManager: Lost task 15.0 in stage 147.0 (TID 12171, 128.110.152.144): ExecutorLostFailure (executor 32 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:26:23 WARN TaskSetManager: Lost task 5.0 in stage 147.0 (TID 12161, 128.110.152.144): ExecutorLostFailure (executor 32 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 147:=====================================================> (79 + 2) / 81][Stage 147:======================================================>(80 + 1) / 81]                                                                                Time elapsed: 16.417828392 seconds
res149: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=153 AND partitionZIndex<=153", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=153 AND partitionZIndex<=153,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049579107 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 148:================================================>      (71 + 9) / 80][Stage 148:=====================================================> (78 + 2) / 80][Stage 148:======================================================>(79 + 1) / 80]                                                                                [Stage 149:=====================================================> (79 + 2) / 81][Stage 149:======================================================>(80 + 1) / 81]                                                                                Time elapsed: 24.005604587 seconds
res151: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=201 AND partitionZIndex<=201", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=201 AND partitionZIndex<=201,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05163256 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.686411294 seconds
res153: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=112 AND partitionZIndex<=112", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=112 AND partitionZIndex<=112,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.043982307 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.614390446 seconds
res155: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=57 AND partitionZIndex<=57", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=57 AND partitionZIndex<=57,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058655277 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 04:27:05 ERROR TaskSchedulerImpl: Lost executor 40 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:27:05 WARN TaskSetManager: Lost task 25.0 in stage 154.0 (TID 12747, 128.110.152.141): ExecutorLostFailure (executor 40 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 154:==================================================>    (74 + 6) / 80][Stage 154:====================================================>  (77 + 3) / 80][Stage 154:=====================================================> (78 + 2) / 80][Stage 154:======================================================>(79 + 1) / 80]                                                                                [Stage 155:===============================================>      (71 + 10) / 81][Stage 155:====================================================>  (78 + 3) / 81][Stage 155:=====================================================> (79 + 2) / 81][Stage 155:======================================================>(80 + 1) / 81]                                                                                Time elapsed: 23.962896218 seconds
res157: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=30 AND partitionZIndex<=30", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=30 AND partitionZIndex<=30,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.059874154 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 156:=====================================================> (78 + 2) / 80][Stage 156:======================================================>(79 + 1) / 80]                                                                                [Stage 157:=====================================================> (79 + 2) / 81][Stage 157:======================================================>(80 + 1) / 81]                                                                                Time elapsed: 14.821666585 seconds
res159: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=251 AND partitionZIndex<=251", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=251 AND partitionZIndex<=251,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048853733 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 158:======================================================>(79 + 1) / 80]                                                                                [Stage 159:======================================================>(80 + 1) / 81]                                                                                Time elapsed: 11.702524515 seconds
res161: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=230 AND partitionZIndex<=230", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=230 AND partitionZIndex<=230,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057064004 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 160:=====================================================> (78 + 2) / 80][Stage 160:======================================================>(79 + 1) / 80]                                                                                [Stage 161:=====================================================> (79 + 2) / 81][Stage 161:======================================================>(80 + 1) / 81]                                                                                Time elapsed: 16.221986916 seconds
res163: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=203 AND partitionZIndex<=203", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=203 AND partitionZIndex<=203,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045496825 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.776480532 seconds
res165: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=60 AND partitionZIndex<=60", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=60 AND partitionZIndex<=60,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047478719 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 164:====================================================>  (77 + 3) / 80][Stage 164:=====================================================> (78 + 2) / 80][Stage 164:======================================================>(79 + 1) / 80]                                                                                [Stage 165:====================================================>  (77 + 4) / 81]17/06/10 04:28:30 ERROR TaskSchedulerImpl: Lost executor 34 on 128.110.152.155: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:28:30 WARN TaskSetManager: Lost task 70.0 in stage 165.0 (TID 13678, 128.110.152.155): ExecutorLostFailure (executor 34 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:28:30 WARN TaskSetManager: Lost task 30.0 in stage 165.0 (TID 13638, 128.110.152.155): ExecutorLostFailure (executor 34 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:28:30 WARN TaskSetManager: Lost task 0.0 in stage 165.0 (TID 13608, 128.110.152.155): ExecutorLostFailure (executor 34 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 165:====================================================>  (78 + 3) / 81][Stage 165:=====================================================> (79 + 2) / 81][Stage 165:======================================================>(80 + 1) / 81]                                                                                Time elapsed: 16.000417322 seconds
res167: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=239 AND partitionZIndex<=239", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=239 AND partitionZIndex<=239,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05015273 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 166:=====================================================> (70 + 2) / 72][Stage 166:======================================================>(71 + 1) / 72]                                                                                [Stage 167:================================================>      (64 + 9) / 73][Stage 167:=====================================================> (71 + 2) / 73][Stage 167:======================================================>(72 + 1) / 73]17/06/10 04:29:05 ERROR TaskSchedulerImpl: Lost executor 43 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:29:05 WARN TaskSetManager: Lost task 57.0 in stage 167.0 (TID 13821, 128.110.152.141): ExecutorLostFailure (executor 43 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 31.426750468 seconds
res169: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=143 AND partitionZIndex<=143", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=143 AND partitionZIndex<=143,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049140915 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 168:================================================>      (63 + 9) / 72][Stage 168:=====================================================> (70 + 2) / 72][Stage 168:======================================================>(71 + 1) / 72]17/06/10 04:29:29 ERROR TaskSchedulerImpl: Lost executor 45 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:29:29 WARN TaskSetManager: Lost task 23.0 in stage 168.0 (TID 13861, 128.110.152.141): ExecutorLostFailure (executor 45 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:29:39 ERROR TaskSchedulerImpl: Lost executor 39 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:29:39 WARN TaskSetManager: Lost task 23.1 in stage 168.0 (TID 13910, 128.110.152.145): ExecutorLostFailure (executor 39 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 169:========================================>             (55 + 18) / 73][Stage 169:=============================================>        (62 + 11) / 73][Stage 169:=====================================================> (71 + 2) / 73][Stage 169:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 41.541352459 seconds
res171: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=76 AND partitionZIndex<=76", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=76 AND partitionZIndex<=76,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053051423 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 170:====================================================>  (69 + 3) / 72][Stage 170:=====================================================> (70 + 2) / 72][Stage 170:======================================================>(71 + 1) / 72]                                                                                [Stage 171:====================================================>  (70 + 3) / 73]17/06/10 04:30:12 ERROR TaskSchedulerImpl: Lost executor 46 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:30:12 WARN TaskSetManager: Lost task 13.0 in stage 171.0 (TID 14070, 128.110.152.141): ExecutorLostFailure (executor 46 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:30:12 WARN TaskSetManager: Lost task 4.0 in stage 171.0 (TID 14061, 128.110.152.141): ExecutorLostFailure (executor 46 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 171:=====================================================> (71 + 2) / 73][Stage 171:======================================================>(72 + 1) / 73]17/06/10 04:30:23 ERROR TaskSchedulerImpl: Lost executor 42 on 128.110.152.144: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:30:23 WARN TaskSetManager: Lost task 13.1 in stage 171.0 (TID 14131, 128.110.152.144): ExecutorLostFailure (executor 42 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 34.088141288 seconds
res173: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=86 AND partitionZIndex<=86", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=86 AND partitionZIndex<=86,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048550179 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 172:=======================================>              (53 + 19) / 72][Stage 172:========================================>             (54 + 18) / 72][Stage 172:=====================================================> (70 + 2) / 72][Stage 172:======================================================>(71 + 1) / 72]                                                                                [Stage 173:====================================================>  (70 + 3) / 73][Stage 173:=====================================================> (71 + 2) / 73][Stage 173:======================================================>(72 + 1) / 73]17/06/10 04:30:51 ERROR TaskSchedulerImpl: Lost executor 48 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:30:51 WARN TaskSetManager: Lost task 23.0 in stage 173.0 (TID 14228, 128.110.152.141): ExecutorLostFailure (executor 48 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 26.814532613 seconds
res175: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=114 AND partitionZIndex<=114", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=114 AND partitionZIndex<=114,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058256249 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 174:================================================>      (64 + 8) / 72]                                                                                Time elapsed: 5.800424637 seconds
res177: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=178 AND partitionZIndex<=178", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=178 AND partitionZIndex<=178,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047682664 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 176:====================================================>  (69 + 3) / 72][Stage 176:=====================================================> (70 + 2) / 72][Stage 176:======================================================>(71 + 1) / 72]17/06/10 04:31:18 ERROR TaskSchedulerImpl: Lost executor 28 on 128.110.152.165: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:31:18 WARN TaskSetManager: Lost task 41.0 in stage 176.0 (TID 14465, 128.110.152.165): ExecutorLostFailure (executor 28 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 177:==============================================>       (63 + 10) / 73][Stage 177:====================================================>  (70 + 3) / 73]17/06/10 04:31:31 ERROR TaskSchedulerImpl: Lost executor 47 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:31:31 WARN TaskSetManager: Lost task 53.0 in stage 177.0 (TID 14550, 128.110.152.145): ExecutorLostFailure (executor 47 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 177:=====================================================> (71 + 2) / 73][Stage 177:======================================================>(72 + 1) / 73]17/06/10 04:31:40 ERROR TaskSchedulerImpl: Lost executor 3 on 128.110.152.160: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:31:40 WARN TaskSetManager: Lost task 53.1 in stage 177.0 (TID 14570, 128.110.152.160): ExecutorLostFailure (executor 3 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 35.908435168 seconds
res179: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=48 AND partitionZIndex<=48", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=48 AND partitionZIndex<=48,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049113141 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 178:=========================================>            (55 + 17) / 72][Stage 178:====================================================>  (69 + 3) / 72][Stage 178:=====================================================> (70 + 2) / 72][Stage 178:======================================================>(71 + 1) / 72]                                                                                [Stage 179:====================================================>  (70 + 3) / 73][Stage 179:=====================================================> (71 + 2) / 73][Stage 179:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 21.326291717 seconds
res181: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=44 AND partitionZIndex<=44", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=44 AND partitionZIndex<=44,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046137511 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 04:32:11 ERROR TaskSchedulerImpl: Lost executor 31 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:32:11 WARN TaskSetManager: Lost task 27.0 in stage 180.0 (TID 14744, 128.110.152.142): ExecutorLostFailure (executor 31 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:32:11 WARN TaskSetManager: Lost task 0.0 in stage 180.0 (TID 14717, 128.110.152.142): ExecutorLostFailure (executor 31 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 180:====================================================>  (69 + 3) / 72][Stage 180:=====================================================> (70 + 2) / 72][Stage 180:======================================================>(71 + 1) / 72]                                                                                [Stage 181:=============================================>        (62 + 11) / 73][Stage 181:====================================================>  (70 + 3) / 73][Stage 181:=====================================================> (71 + 2) / 73][Stage 181:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 14.506580763 seconds
res183: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=63 AND partitionZIndex<=63", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=63 AND partitionZIndex<=63,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04674537 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 182:====================================================>  (70 + 3) / 73][Stage 182:=====================================================> (71 + 2) / 73][Stage 182:======================================================>(72 + 1) / 73]                                                                                [Stage 183:====================================================>  (71 + 3) / 74][Stage 183:=====================================================> (72 + 2) / 74][Stage 183:======================================================>(73 + 1) / 74]                                                                                Time elapsed: 15.022698456 seconds
res185: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=15 AND partitionZIndex<=15", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=15 AND partitionZIndex<=15,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050924677 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 184:=====================================================> (70 + 2) / 72][Stage 184:======================================================>(71 + 1) / 72]                                                                                [Stage 185:=====================================================> (71 + 2) / 73][Stage 185:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 12.562525165 seconds
res187: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=146 AND partitionZIndex<=146", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=146 AND partitionZIndex<=146,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049763681 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 186:=====================================================> (70 + 2) / 72][Stage 186:======================================================>(71 + 1) / 72]                                                                                [Stage 187:=====================================================> (71 + 2) / 73][Stage 187:======================================================>(72 + 1) / 73]17/06/10 04:33:13 ERROR TaskSchedulerImpl: Lost executor 50 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:33:13 WARN TaskSetManager: Lost task 27.0 in stage 187.0 (TID 15255, 128.110.152.141): ExecutorLostFailure (executor 50 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 20.651507625 seconds
res189: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=236 AND partitionZIndex<=236", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=236 AND partitionZIndex<=236,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058892613 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 188:================================================>      (64 + 8) / 72]                                                                                Time elapsed: 5.67713587 seconds
res191: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=80 AND partitionZIndex<=80", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=80 AND partitionZIndex<=80,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048506266 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 190:====================================================>  (69 + 3) / 72][Stage 190:=====================================================> (70 + 2) / 72]                                                                                [Stage 191:====================================================>  (70 + 3) / 73][Stage 191:=====================================================> (71 + 2) / 73]                                                                                Time elapsed: 14.995147488 seconds
res193: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=238 AND partitionZIndex<=238", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=238 AND partitionZIndex<=238,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046386094 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 192:=====================================================> (70 + 2) / 72][Stage 192:======================================================>(71 + 1) / 72]                                                                                [Stage 193:=====================================================> (71 + 2) / 73][Stage 193:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 12.5785208 seconds
res195: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=193 AND partitionZIndex<=193", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=193 AND partitionZIndex<=193,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049454945 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.661045221 seconds
res197: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=5 AND partitionZIndex<=5", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=5 AND partitionZIndex<=5,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049084906 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 196:======================================================>(71 + 1) / 72]                                                                                [Stage 197:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 8.230253215 seconds
res199: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=113 AND partitionZIndex<=113", 1))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=113 AND partitionZIndex<=113,1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.062796363 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 198:=====================================================> (70 + 2) / 72][Stage 198:======================================================>(71 + 1) / 72]                                                                                17/06/10 04:34:22 ERROR TaskSchedulerImpl: Lost executor 55 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:34:22 WARN TaskSetManager: Lost task 12.0 in stage 199.0 (TID 16111, 128.110.152.141): ExecutorLostFailure (executor 55 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 199:=====================================================> (71 + 2) / 73][Stage 199:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 15.13779698 seconds
res201: Int = 0

scala> 

scala> :quit
