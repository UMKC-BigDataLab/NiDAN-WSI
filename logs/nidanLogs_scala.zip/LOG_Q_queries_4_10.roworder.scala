Using Spark's default log4j profile: org/apache/spark/log4j-defaults.properties
Setting default log level to "WARN".
To adjust logging level use sc.setLogLevel(newLevel).
17/06/10 05:36:20 WARN NativeCodeLoader: Unable to load native-hadoop library for your platform... using builtin-java classes where applicable
17/06/10 05:36:22 WARN SparkContext: Use an existing SparkContext, some configuration may not take effect.
Spark context Web UI available at http://128.110.152.156:4040
Spark context available as 'sc' (master = spark://ctl:7077, app id = app-20170610053622-0061).
Spark session available as 'spark'.
Welcome to
      ____              __
     / __/__  ___ _____/ /__
    _\ \/ _ \/ _ `/ __/  '_/
   /___/ .__/\_,_/_/ /_/\_\   version 2.0.2
      /_/
         
Using Scala version 2.11.8 (OpenJDK 64-Bit Server VM, Java 1.8.0_131)
Type in expressions to have them evaluated.
Type :help for more information.

scala>  
     | import java.io.File
import java.io.File

scala> import java.io.FileOutputStream
import java.io.FileOutputStream

scala> import org.apache.spark.sql._
import org.apache.spark.sql._

scala> 

scala> def show_timing[T](proc: => T): T = {
     |     val start=System.nanoTime()
     |     val res = proc
     |     val end = System.nanoTime()
     |     println("Time elapsed: " + (end-start)/1000000000.0 + " seconds")
     |     res
     | }
show_timing: [T](proc: => T)T

scala> 

scala> val writeToLocal = (in:(Array[Byte], Long, String)) =>{
     |     val bytes = in._1
     |     val output = in._3
     |     
     |     val writer = new FileOutputStream(output)
     |     writer.write(bytes)
     |     writer.close
     |     1
     |   }
writeToLocal: ((Array[Byte], Long, String)) => Int = <function1>

scala> 

scala> val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)
warning: there was one deprecation warning; re-run with -deprecation for details
sqlContext: org.apache.spark.sql.hive.HiveContext = org.apache.spark.sql.hive.HiveContext@7757a37f

scala>   
     | val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 135  OR  partitionIndex = 150  OR   partitionIndex = 151  OR  partitionIndex = 164 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 135  OR  partitionIndex = 150  OR  partitionIndex = 151  OR  partitionIndex = 164 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 15.625748711 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 0:>                                                         (0 + 0) / 64][Stage 0:>                                                        (0 + 64) / 64][Stage 0:=======================================================> (62 + 2) / 64][Stage 0:========================================================>(63 + 1) / 64]                                                                                [Stage 1:=======================================================> (63 + 2) / 65][Stage 1:========================================================>(64 + 1) / 65]                                                                                Time elapsed: 24.215450398 seconds
res3: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 10  OR  partitionIndex = 11  OR  pa rtitionIndex = 26  OR  partitionIndex = 27 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 10  OR  partitionIndex = 11  OR  partitionIndex = 26  OR  partitionIndex = 27 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.143181609 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 2:=======================================================> (62 + 2) / 64][Stage 2:========================================================>(63 + 1) / 64]                                                                                [Stage 3:=======================================================> (63 + 2) / 65][Stage 3:========================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.388296448 seconds
res5: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 166  OR  partitionIndex = 167  OR   partitionIndex = 180  OR  partitionIndex = 181 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 166  OR  partitionIndex = 167  OR  partitionIndex = 180  OR  partitionIndex = 181 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.149853158 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 4:==============================================>         (53 + 11) / 64][Stage 4:========================================================>(63 + 1) / 64]                                                                                [Stage 5:========================================================>(64 + 1) / 65]                                                                                Time elapsed: 18.725485654 seconds
res7: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 110  OR  partitionIndex = 111  OR   partitionIndex = 126  OR  partitionIndex = 127 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 110  OR  partitionIndex = 111  OR  partitionIndex = 126  OR  partitionIndex = 127 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.148484782 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 6:========================================================>(63 + 1) / 64]                                                                                [Stage 7:========================================================>(64 + 1) / 65]                                                                                Time elapsed: 16.954540726 seconds
res9: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 211  OR  partitionIndex = 224  OR   partitionIndex = 225  OR  partitionIndex = 240 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 211  OR  partitionIndex = 224  OR  partitionIndex = 225  OR  partitionIndex = 240 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.130855613 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 8:========================================================>(63 + 1) / 64]                                                                                [Stage 9:========================================================>(64 + 1) / 65]                                                                                Time elapsed: 12.601020344 seconds
res11: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 10  OR  partitionIndex = 11  OR  pa rtitionIndex = 25  OR  partitionIndex = 26 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 10  OR  partitionIndex = 11  OR  partitionIndex = 25  OR  partitionIndex = 26 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.112226266 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 10:======================================================> (62 + 2) / 64][Stage 10:=======================================================>(63 + 1) / 64]                                                                                [Stage 11:======================================================> (63 + 2) / 65][Stage 11:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 11.895793329 seconds
res13: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 223  OR  partitionIndex = 236  OR   partitionIndex = 237  OR  partitionIndex = 252 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 223  OR  partitionIndex = 236  OR  partitionIndex = 237  OR  partitionIndex = 252 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.089980425 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.73574119 seconds
res15: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 138  OR  partitionIndex = 139  OR   partitionIndex = 154  OR  partitionIndex = 155 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 138  OR  partitionIndex = 139  OR  partitionIndex = 154  OR  partitionIndex = 155 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.087536269 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 14:======================================================> (62 + 2) / 64][Stage 14:=======================================================>(63 + 1) / 64]                                                                                [Stage 15:======================================================> (63 + 2) / 65][Stage 15:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.30938162 seconds
res17: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 219  OR  partitionIndex = 232  OR   partitionIndex = 233  OR  partitionIndex = 248 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 219  OR  partitionIndex = 232  OR  partitionIndex = 233  OR  partitionIndex = 248 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.06995714 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 16:=======================================================>(63 + 1) / 64]                                                                                [Stage 17:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 12.545496815 seconds
res19: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 175  OR  partitionIndex = 190  OR   partitionIndex = 191  OR  partitionIndex = 200 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 175  OR  partitionIndex = 190  OR  partitionIndex = 191  OR  partitionIndex = 200 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.099329189 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 18:=======================================================>(63 + 1) / 64]                                                                                [Stage 19:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 14.169218234 seconds
res21: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 42  OR  partitionIndex = 43  OR  pa rtitionIndex = 58  OR  partitionIndex = 59 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 42  OR  partitionIndex = 43  OR  partitionIndex = 58  OR  partitionIndex = 59 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.082213179 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 20:>                                                        (0 + 0) / 64][Stage 20:======================================================> (62 + 2) / 64][Stage 20:=======================================================>(63 + 1) / 64]                                                                                [Stage 21:======================================================> (63 + 2) / 65][Stage 21:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.578571678 seconds
res23: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 73  OR  partitionIndex = 74  OR  pa rtitionIndex = 88  OR  partitionIndex = 89 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 73  OR  partitionIndex = 74  OR  partitionIndex = 88  OR  partitionIndex = 89 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.068905002 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 22:=======================================================>(63 + 1) / 64]                                                                                [Stage 23:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.753867544 seconds
res25: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 76  OR  partitionIndex = 77  OR  pa rtitionIndex = 92  OR  partitionIndex = 123 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 76  OR  partitionIndex = 77  OR  partitionIndex = 92  OR  partitionIndex = 123 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.07019296 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 24:======================================================> (62 + 2) / 64][Stage 24:=======================================================>(63 + 1) / 64]                                                                                17/06/10 05:40:36 ERROR TaskSchedulerImpl: Lost executor 5 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:40:36 WARN TaskSetManager: Lost task 11.0 in stage 25.0 (TID 1623, 128.110.152.141): ExecutorLostFailure (executor 5 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 25:======================================================> (63 + 2) / 65][Stage 25:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 16.561986456 seconds
res27: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 134  OR  partitionIndex = 135  OR   partitionIndex = 148  OR  partitionIndex = 149 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 134  OR  partitionIndex = 135  OR  partitionIndex = 148  OR  partitionIndex = 149 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.068056464 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 26:================================================>       (55 + 9) / 64][Stage 26:=======================================================>(63 + 1) / 64]                                                                                [Stage 27:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.73626181 seconds
res29: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 19  OR  partitionIndex = 32  OR  pa rtitionIndex = 33  OR  partitionIndex = 48 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 19  OR  partitionIndex = 32  OR  partitionIndex = 33  OR  partitionIndex = 48 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.062808473 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 28:=====================================================>  (61 + 3) / 64][Stage 28:======================================================> (62 + 2) / 64]                                                                                [Stage 29:=====================================================>  (62 + 3) / 65][Stage 29:======================================================> (63 + 2) / 65]                                                                                Time elapsed: 11.010434003 seconds
res31: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 90  OR  partitionIndex = 91  OR  pa rtitionIndex = 104  OR  partitionIndex = 105 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 90  OR  partitionIndex = 91  OR  partitionIndex = 104  OR  partitionIndex = 105 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.075869932 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 30:======================================================> (62 + 2) / 64][Stage 30:=======================================================>(63 + 1) / 64]17/06/10 05:41:28 ERROR TaskSchedulerImpl: Lost executor 8 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:41:28 WARN TaskSetManager: Lost task 11.0 in stage 30.0 (TID 1947, 128.110.152.141): ExecutorLostFailure (executor 8 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 31:==============================================>        (55 + 10) / 65][Stage 31:======================================================> (63 + 2) / 65][Stage 31:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 26.677231277 seconds
res33: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 204  OR  partitionIndex = 205  OR   partitionIndex = 220  OR  partitionIndex = 251 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 204  OR  partitionIndex = 205  OR  partitionIndex = 220  OR  partitionIndex = 251 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056893324 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 32:>                                                        (0 + 0) / 64]                                                                                Time elapsed: 0.778653866 seconds
res35: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 12  OR  partitionIndex = 13  OR  pa rtitionIndex = 28  OR  partitionIndex = 59 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 12  OR  partitionIndex = 13  OR  partitionIndex = 28  OR  partitionIndex = 59 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.073495336 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 34:=====================================================>  (61 + 3) / 64][Stage 34:======================================================> (62 + 2) / 64][Stage 34:=======================================================>(63 + 1) / 64]                                                                                [Stage 35:=====================================================>  (62 + 3) / 65][Stage 35:======================================================> (63 + 2) / 65][Stage 35:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 14.191503779 seconds
res37: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 225  OR  partitionIndex = 226  OR   partitionIndex = 240  OR  partitionIndex = 241 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 225  OR  partitionIndex = 226  OR  partitionIndex = 240  OR  partitionIndex = 241 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.068079526 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 36:=======================================================>(63 + 1) / 64]                                                                                [Stage 37:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 14.082215696 seconds
res39: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 102  OR  partitionIndex = 103  OR   partitionIndex = 117  OR  partitionIndex = 118 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 102  OR  partitionIndex = 103  OR  partitionIndex = 117  OR  partitionIndex = 118 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.067763946 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 38:======================================================> (62 + 2) / 64][Stage 38:=======================================================>(63 + 1) / 64]                                                                                [Stage 39:======================================================> (63 + 2) / 65][Stage 39:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.103919335 seconds
res41: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68  OR  partitionIndex = 99  OR  pa rtitionIndex = 114  OR  partitionIndex = 115 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68  OR  partitionIndex = 99  OR  partitionIndex = 114  OR  partitionIndex = 115 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.079703726 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.744544512 seconds
res43: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 136  OR  partitionIndex = 137  OR   partitionIndex = 152  OR  partitionIndex = 153 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 136  OR  partitionIndex = 137  OR  partitionIndex = 152  OR  partitionIndex = 153 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056828945 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 42:=======================================================>(63 + 1) / 64]17/06/10 05:42:53 ERROR TaskSchedulerImpl: Lost executor 9 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:42:53 WARN TaskSetManager: Lost task 20.0 in stage 42.0 (TID 2731, 128.110.152.141): ExecutorLostFailure (executor 9 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:43:03 ERROR TaskSchedulerImpl: Lost executor 3 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:43:03 WARN TaskSetManager: Lost task 20.1 in stage 42.0 (TID 2775, 128.110.152.168): ExecutorLostFailure (executor 3 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 43:========================================>              (48 + 17) / 65][Stage 43:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 38.253043286 seconds
res45: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 196  OR  partitionIndex = 227  OR   partitionIndex = 242  OR  partitionIndex = 243 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 196  OR  partitionIndex = 227  OR  partitionIndex = 242  OR  partitionIndex = 243 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.064892531 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 44:================================================>       (55 + 9) / 64][Stage 44:======================================================> (62 + 2) / 64]17/06/10 05:43:29 ERROR TaskSchedulerImpl: Lost executor 0 on 128.110.152.165: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:43:29 WARN TaskSetManager: Lost task 49.0 in stage 44.0 (TID 2891, 128.110.152.165): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 44:=======================================================>(63 + 1) / 64]                                                                                [Stage 45:==============================================>        (55 + 10) / 65][Stage 45:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 17.042701057 seconds
res47: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 154  OR  partitionIndex = 155  OR   partitionIndex = 168  OR  partitionIndex = 169 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 154  OR  partitionIndex = 155  OR  partitionIndex = 168  OR  partitionIndex = 169 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057112905 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 46:======================================================> (62 + 2) / 64][Stage 46:=======================================================>(63 + 1) / 64]                                                                                17/06/10 05:43:51 ERROR TaskSchedulerImpl: Lost executor 7 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:43:51 WARN TaskSetManager: Lost task 37.0 in stage 47.0 (TID 3073, 128.110.152.145): ExecutorLostFailure (executor 7 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 47:======================================================> (63 + 2) / 65][Stage 47:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 14.333080883 seconds
res49: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 7  OR  partitionIndex = 22  OR  par titionIndex = 23  OR  partitionIndex = 36 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 7  OR  partitionIndex = 22  OR  partitionIndex = 23  OR  partitionIndex = 36 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.069337205 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 48:==============================================>        (54 + 10) / 64][Stage 48:================================================>       (55 + 9) / 64][Stage 48:======================================================> (62 + 2) / 64][Stage 48:=======================================================>(63 + 1) / 64]                                                                                [Stage 49:=====================================================>  (62 + 3) / 65][Stage 49:======================================================> (63 + 2) / 65]17/06/10 05:44:18 ERROR TaskSchedulerImpl: Lost executor 6 on 128.110.152.152: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:44:18 WARN TaskSetManager: Lost task 7.0 in stage 49.0 (TID 3173, 128.110.152.152): ExecutorLostFailure (executor 6 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:44:18 ERROR TaskSchedulerImpl: Lost executor 10 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:44:18 WARN TaskSetManager: Lost task 7.1 in stage 49.0 (TID 3231, 128.110.152.141): ExecutorLostFailure (executor 10 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 49:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 25.05110309 seconds
res51: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 102  OR  partitionIndex = 103  OR   partitionIndex = 116  OR  partitionIndex = 117 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 102  OR  partitionIndex = 103  OR  partitionIndex = 116  OR  partitionIndex = 117 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.070286644 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 50:========================================>              (47 + 17) / 64][Stage 50:==============================================>        (54 + 10) / 64][Stage 50:======================================================> (62 + 2) / 64][Stage 50:=======================================================>(63 + 1) / 64]                                                                                [Stage 51:============================================>          (52 + 13) / 65][Stage 51:============================================>          (53 + 12) / 65][Stage 51:=============================================>         (54 + 11) / 65][Stage 51:==============================================>        (55 + 10) / 65][Stage 51:================================================>       (56 + 9) / 65][Stage 51:=================================================>      (57 + 8) / 65]17/06/10 05:45:01 WARN TransportChannelHandler: Exception in connection from /128.110.152.141:40936
java.io.IOException: Connection reset by peer
	at sun.nio.ch.FileDispatcherImpl.read0(Native Method)
	at sun.nio.ch.SocketDispatcher.read(SocketDispatcher.java:39)
	at sun.nio.ch.IOUtil.readIntoNativeBuffer(IOUtil.java:223)
	at sun.nio.ch.IOUtil.read(IOUtil.java:192)
	at sun.nio.ch.SocketChannelImpl.read(SocketChannelImpl.java:380)
	at io.netty.buffer.PooledUnsafeDirectByteBuf.setBytes(PooledUnsafeDirectByteBuf.java:313)
	at io.netty.buffer.AbstractByteBuf.writeBytes(AbstractByteBuf.java:881)
	at io.netty.channel.socket.nio.NioSocketChannel.doReadBytes(NioSocketChannel.java:242)
	at io.netty.channel.nio.AbstractNioByteChannel$NioByteUnsafe.read(AbstractNioByteChannel.java:119)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:511)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 05:45:01 ERROR TaskSchedulerImpl: Lost executor 15 on 128.110.152.141: Command exited with code 137
17/06/10 05:45:01 WARN TaskSetManager: Lost task 16.0 in stage 51.0 (TID 3313, 128.110.152.141): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 05:45:01 WARN TaskSetManager: Lost task 48.0 in stage 51.0 (TID 3345, 128.110.152.141): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 05:45:01 WARN TaskSetManager: Lost task 24.0 in stage 51.0 (TID 3321, 128.110.152.141): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 05:45:01 WARN TaskSetManager: Lost task 0.0 in stage 51.0 (TID 3297, 128.110.152.141): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 05:45:01 WARN TaskSetManager: Lost task 8.0 in stage 51.0 (TID 3305, 128.110.152.141): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 05:45:01 WARN TaskSetManager: Lost task 56.0 in stage 51.0 (TID 3353, 128.110.152.141): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 05:45:01 WARN TaskSetManager: Lost task 32.0 in stage 51.0 (TID 3329, 128.110.152.141): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 05:45:01 WARN TaskSetManager: Lost task 40.0 in stage 51.0 (TID 3337, 128.110.152.141): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Command exited with code 137
                                                                                Time elapsed: 33.263923662 seconds
res53: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 158  OR  partitionIndex = 159  OR   partitionIndex = 172  OR  partitionIndex = 173 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 158  OR  partitionIndex = 159  OR  partitionIndex = 172  OR  partitionIndex = 173 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.063737615 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 52:=======================================================>(55 + 1) / 56]                                                                                [Stage 53:================================================>       (49 + 8) / 57][Stage 53:=======================================================>(56 + 1) / 57]                                                                                Time elapsed: 18.284921647 seconds
res55: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 183  OR  partitionIndex = 192  OR   partitionIndex = 193  OR  partitionIndex = 208 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 183  OR  partitionIndex = 192  OR  partitionIndex = 193  OR  partitionIndex = 208 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.059704022 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.76276795 seconds
res57: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 42  OR  partitionIndex = 43  OR  pa rtitionIndex = 57  OR  partitionIndex = 58 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 42  OR  partitionIndex = 43  OR  partitionIndex = 57  OR  partitionIndex = 58 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056156848 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 56:======================================================> (62 + 2) / 64][Stage 56:=======================================================>(63 + 1) / 64]                                                                                [Stage 57:======================================================> (63 + 2) / 65][Stage 57:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 14.477180449 seconds
res59: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 2  OR  partitionIndex = 3  OR  part itionIndex = 16  OR  partitionIndex = 17 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 2  OR  partitionIndex = 3  OR  partitionIndex = 16  OR  partitionIndex = 17 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.069162986 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 58:=====================================================>  (61 + 3) / 64][Stage 58:======================================================> (62 + 2) / 64][Stage 58:=======================================================>(63 + 1) / 64]                                                                                [Stage 59:======================================================> (63 + 2) / 65][Stage 59:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 10.535275358 seconds
res61: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 139  OR  partitionIndex = 154  OR   partitionIndex = 155  OR  partitionIndex = 168 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 139  OR  partitionIndex = 154  OR  partitionIndex = 155  OR  partitionIndex = 168 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058343724 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.610308843 seconds
res63: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 198  OR  partitionIndex = 199  OR   partitionIndex = 213  OR  partitionIndex = 214 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 198  OR  partitionIndex = 199  OR  partitionIndex = 213  OR  partitionIndex = 214 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050200198 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.64295751 seconds
res65: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 204  OR  partitionIndex = 205  OR   partitionIndex = 250  OR  partitionIndex = 251 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 204  OR  partitionIndex = 205  OR  partitionIndex = 250  OR  partitionIndex = 251 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.060196802 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.704008311 seconds
res67: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 206  OR  partitionIndex = 207  OR   partitionIndex = 221  OR  partitionIndex = 222 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 206  OR  partitionIndex = 207  OR  partitionIndex = 221  OR  partitionIndex = 222 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053125993 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 66:=======================================================>(63 + 1) / 64]                                                                                [Stage 67:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 12.918797883 seconds
res69: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 78  OR  partitionIndex = 79  OR  pa rtitionIndex = 94  OR  partitionIndex = 95 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 78  OR  partitionIndex = 79  OR  partitionIndex = 94  OR  partitionIndex = 95 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054130212 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.573045867 seconds
res71: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 0  OR  partitionIndex = 1  OR  part itionIndex = 16  OR  partitionIndex = 17 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 0  OR  partitionIndex = 1  OR  partitionIndex = 16  OR  partitionIndex = 17 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056769048 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 70:=====================================================>  (61 + 3) / 64][Stage 70:======================================================> (62 + 2) / 64][Stage 70:=======================================================>(63 + 1) / 64]                                                                                [Stage 71:=====================================================>  (62 + 3) / 65][Stage 71:======================================================> (63 + 2) / 65][Stage 71:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 12.229016414 seconds
res73: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 40  OR  partitionIndex = 41  OR  pa rtitionIndex = 56  OR  partitionIndex = 57 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 40  OR  partitionIndex = 41  OR  partitionIndex = 56  OR  partitionIndex = 57 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.069080848 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 72:======================================================> (62 + 2) / 64][Stage 72:=======================================================>(63 + 1) / 64]17/06/10 05:46:45 ERROR TaskSchedulerImpl: Lost executor 16 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:46:45 WARN TaskSetManager: Lost task 34.0 in stage 72.0 (TID 4678, 128.110.152.141): ExecutorLostFailure (executor 16 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 73:==============================================>        (55 + 10) / 65][Stage 73:=====================================================>  (62 + 3) / 65][Stage 73:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 21.193585761 seconds
res75: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 22  OR  partitionIndex = 23  OR  pa rtitionIndex = 36  OR  partitionIndex = 37 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 22  OR  partitionIndex = 23  OR  partitionIndex = 36  OR  partitionIndex = 37 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.076763496 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 74:=======================================================>(63 + 1) / 64]                                                                                [Stage 75:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 11.891033478 seconds
res77: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 74  OR  partitionIndex = 75  OR  pa rtitionIndex = 89  OR  partitionIndex = 90 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 74  OR  partitionIndex = 75  OR  partitionIndex = 89  OR  partitionIndex = 90 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057483267 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.640126965 seconds
res79: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 230  OR  partitionIndex = 231  OR   partitionIndex = 244  OR  partitionIndex = 245 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 230  OR  partitionIndex = 231  OR  partitionIndex = 244  OR  partitionIndex = 245 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056152869 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 78:=======================================================>(63 + 1) / 64]                                                                                [Stage 79:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 11.582721517 seconds
res81: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 2  OR  partitionIndex = 3  OR  part itionIndex = 17  OR  partitionIndex = 18 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 2  OR  partitionIndex = 3  OR  partitionIndex = 17  OR  partitionIndex = 18 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055381111 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 80:=======================================================>(63 + 1) / 64]                                                                                17/06/10 05:47:37 ERROR TaskSchedulerImpl: Lost executor 13 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:47:37 WARN TaskSetManager: Lost task 0.0 in stage 81.0 (TID 5225, 128.110.152.145): ExecutorLostFailure (executor 13 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 81:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 11.005961659 seconds
res83: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 206  OR  partitionIndex = 207  OR   partitionIndex = 220  OR  partitionIndex = 221 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 206  OR  partitionIndex = 207  OR  partitionIndex = 220  OR  partitionIndex = 221 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.059707244 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 82:================================================>       (55 + 9) / 64][Stage 82:=======================================================>(63 + 1) / 64]                                                                                [Stage 83:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 11.73977325 seconds
res85: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 228  OR  partitionIndex = 229  OR   partitionIndex = 244  OR  partitionIndex = 245 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 228  OR  partitionIndex = 229  OR  partitionIndex = 244  OR  partitionIndex = 245 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.079761532 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 84:=======================================================>(63 + 1) / 64]                                                                                [Stage 85:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 12.453292559 seconds
res87: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 170  OR  partitionIndex = 171  OR   partitionIndex = 184  OR  partitionIndex = 185 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 170  OR  partitionIndex = 171  OR  partitionIndex = 184  OR  partitionIndex = 185 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053091654 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.730255468 seconds
res89: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 4  OR  partitionIndex = 35  OR  par titionIndex = 50  OR  partitionIndex = 51 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 4  OR  partitionIndex = 35  OR  partitionIndex = 50  OR  partitionIndex = 51 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049166101 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 88:=====================================================>  (61 + 3) / 64][Stage 88:======================================================> (62 + 2) / 64][Stage 88:=======================================================>(63 + 1) / 64]                                                                                [Stage 89:====================================================>   (61 + 4) / 65][Stage 89:=====================================================>  (62 + 3) / 65][Stage 89:======================================================> (63 + 2) / 65][Stage 89:=======================================================>(64 + 1) / 65]17/06/10 05:48:30 ERROR TaskSchedulerImpl: Lost executor 18 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:48:30 WARN TaskSetManager: Lost task 19.0 in stage 89.0 (TID 5761, 128.110.152.145): ExecutorLostFailure (executor 18 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:48:36 ERROR TaskSchedulerImpl: Lost executor 17 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:48:36 WARN TaskSetManager: Lost task 19.1 in stage 89.0 (TID 5807, 128.110.152.141): ExecutorLostFailure (executor 17 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 29.086139519 seconds
res91: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 39  OR  partitionIndex = 54  OR  pa rtitionIndex = 55  OR  partitionIndex = 64 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 39  OR  partitionIndex = 54  OR  partitionIndex = 55  OR  partitionIndex = 64 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051010079 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 90:========================================>              (47 + 17) / 64][Stage 90:=========================================>             (48 + 16) / 64][Stage 90:=======================================================>(63 + 1) / 64]                                                                                [Stage 91:======================================================> (63 + 2) / 65][Stage 91:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.408203791 seconds
res93: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 6  OR  partitionIndex = 7  OR  part itionIndex = 22  OR  partitionIndex = 23 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 6  OR  partitionIndex = 7  OR  partitionIndex = 22  OR  partitionIndex = 23 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.060128824 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 92:======================================================> (62 + 2) / 64][Stage 92:=======================================================>(63 + 1) / 64]                                                                                [Stage 93:======================================================> (63 + 2) / 65][Stage 93:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 11.805809818 seconds
res95: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 34  OR  partitionIndex = 35  OR  pa rtitionIndex = 48  OR  partitionIndex = 49 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 34  OR  partitionIndex = 35  OR  partitionIndex = 48  OR  partitionIndex = 49 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.082540869 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 94:=======================================================>(63 + 1) / 64]                                                                                [Stage 95:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 11.840207597 seconds
res97: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 137  OR  partitionIndex = 138  OR   partitionIndex = 152  OR  partitionIndex = 153 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 137  OR  partitionIndex = 138  OR  partitionIndex = 152  OR  partitionIndex = 153 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.061837021 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.657085276 seconds
res99: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 196  OR  partitionIndex = 197  OR   partitionIndex = 212  OR  partitionIndex = 243 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 196  OR  partitionIndex = 197  OR  partitionIndex = 212  OR  partitionIndex = 243 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047405705 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.589836003 seconds
res101: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 110  OR  partitionIndex = 111  OR   partitionIndex = 125  OR  partitionIndex = 126 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 110  OR  partitionIndex = 111  OR  partitionIndex = 125  OR  partitionIndex = 126 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047392385 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.610396351 seconds
res103: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 65  OR  partitionIndex = 66  OR  pa rtitionIndex = 80  OR  partitionIndex = 81 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 65  OR  partitionIndex = 66  OR  partitionIndex = 80  OR  partitionIndex = 81 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055443072 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.584386413 seconds
res105: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 129  OR  partitionIndex = 130  OR   partitionIndex = 144  OR  partitionIndex = 145 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 129  OR  partitionIndex = 130  OR  partitionIndex = 144  OR  partitionIndex = 145 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045782368 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.537972187 seconds
res107: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 170  OR  partitionIndex = 171  OR   partitionIndex = 186  OR  partitionIndex = 187 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 170  OR  partitionIndex = 171  OR  partitionIndex = 186  OR  partitionIndex = 187 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048447583 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.84520508 seconds
res109: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 182  OR  partitionIndex = 183  OR   partitionIndex = 192  OR  partitionIndex = 193 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 182  OR  partitionIndex = 183  OR  partitionIndex = 192  OR  partitionIndex = 193 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051560158 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 108:=========================================>            (49 + 15) / 64][Stage 108:==========================================>           (50 + 14) / 64][Stage 108:===========================================>          (51 + 13) / 64][Stage 108:===========================================>          (52 + 12) / 64][Stage 108:============================================>         (53 + 11) / 64][Stage 108:=============================================>        (54 + 10) / 64][Stage 108:===============================================>       (55 + 9) / 64][Stage 108:================================================>      (56 + 8) / 64][Stage 108:================================================>      (56 + 8) / 64][Stage 108:================================================>      (56 + 8) / 64][Stage 108:================================================>      (56 + 8) / 64][Stage 108:================================================>      (56 + 8) / 64][Stage 108:================================================>      (56 + 8) / 64]17/06/10 05:56:37 ERROR TaskSchedulerImpl: Lost executor 4 on 128.110.152.157: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:56:37 WARN TaskSetManager: Lost task 63.0 in stage 108.0 (TID 7033, 128.110.152.157): ExecutorLostFailure (executor 4 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:56:37 WARN TaskSetManager: Lost task 39.0 in stage 108.0 (TID 7009, 128.110.152.157): ExecutorLostFailure (executor 4 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:56:37 WARN TaskSetManager: Lost task 15.0 in stage 108.0 (TID 6985, 128.110.152.157): ExecutorLostFailure (executor 4 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:56:37 WARN TaskSetManager: Lost task 23.0 in stage 108.0 (TID 6993, 128.110.152.157): ExecutorLostFailure (executor 4 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:56:37 WARN TaskSetManager: Lost task 47.0 in stage 108.0 (TID 7017, 128.110.152.157): ExecutorLostFailure (executor 4 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:56:37 WARN TaskSetManager: Lost task 55.0 in stage 108.0 (TID 7025, 128.110.152.157): ExecutorLostFailure (executor 4 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:56:37 WARN TaskSetManager: Lost task 31.0 in stage 108.0 (TID 7001, 128.110.152.157): ExecutorLostFailure (executor 4 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:56:37 WARN TaskSetManager: Lost task 7.0 in stage 108.0 (TID 6977, 128.110.152.157): ExecutorLostFailure (executor 4 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 109:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 414.690388259 seconds
res111: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 79  OR  partitionIndex = 94  OR  pa rtitionIndex = 95  OR  partitionIndex = 108 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 79  OR  partitionIndex = 94  OR  partitionIndex = 95  OR  partitionIndex = 108 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049766725 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 110:================================================>      (56 + 8) / 64]                                                                                Time elapsed: 5.808429581 seconds
res113: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 94  OR  partitionIndex = 95  OR  pa rtitionIndex = 108  OR  partitionIndex = 109 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 94  OR  partitionIndex = 95  OR  partitionIndex = 108  OR  partitionIndex = 109 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052592061 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.722330493 seconds
res115: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 164  OR  partitionIndex = 165  OR   partitionIndex = 180  OR  partitionIndex = 181 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 164  OR  partitionIndex = 165  OR  partitionIndex = 180  OR  partitionIndex = 181 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049351846 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 114:======================================================>(63 + 1) / 64]                                                                                [Stage 115:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 16.705411715 seconds
res117: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 162  OR  partitionIndex = 163  OR   partitionIndex = 177  OR  partitionIndex = 178 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 162  OR  partitionIndex = 163  OR  partitionIndex = 177  OR  partitionIndex = 178 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050588224 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 116:======================================================>(63 + 1) / 64]                                                                                [Stage 117:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 12.680982957 seconds
res119: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 87  OR  partitionIndex = 100  OR  p artitionIndex = 101  OR  partitionIndex = 116 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 87  OR  partitionIndex = 100  OR  partitionIndex = 101  OR  partitionIndex = 116 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.062591107 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 118:=====================================================> (62 + 2) / 64][Stage 118:======================================================>(63 + 1) / 64]                                                                                [Stage 119:=====================================================> (63 + 2) / 65][Stage 119:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.336292383 seconds
res121: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 1  OR  partitionIndex = 2  OR  part itionIndex = 16  OR  partitionIndex = 17 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 1  OR  partitionIndex = 2  OR  partitionIndex = 16  OR  partitionIndex = 17 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.067489219 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 120:====================================================>  (61 + 3) / 64][Stage 120:=====================================================> (62 + 2) / 64][Stage 120:======================================================>(63 + 1) / 64]                                                                                [Stage 121:============================================>         (53 + 12) / 65][Stage 121:===================================================>   (61 + 4) / 65][Stage 121:=====================================================> (63 + 2) / 65]17/06/10 05:57:57 ERROR TaskSchedulerImpl: Lost executor 20 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:57:57 WARN TaskSetManager: Lost task 63.0 in stage 121.0 (TID 7879, 128.110.152.141): ExecutorLostFailure (executor 20 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 121:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 11.084744512 seconds
res123: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 10  OR  partitionIndex = 11  OR  pa rtitionIndex = 24  OR  partitionIndex = 25 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 10  OR  partitionIndex = 11  OR  partitionIndex = 24  OR  partitionIndex = 25 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050627605 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 122:=====================================================> (54 + 2) / 56][Stage 122:======================================================>(55 + 1) / 56]                                                                                [Stage 123:==============================================>        (48 + 9) / 57][Stage 123:===============================================>       (49 + 8) / 57][Stage 123:======================================================>(56 + 1) / 57]                                                                                Time elapsed: 11.847520742 seconds
res125: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 146  OR  partitionIndex = 147  OR   partitionIndex = 160  OR  partitionIndex = 161 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 146  OR  partitionIndex = 147  OR  partitionIndex = 160  OR  partitionIndex = 161 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047791229 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 124:=====================================================> (62 + 2) / 64][Stage 124:======================================================>(63 + 1) / 64]                                                                                [Stage 125:=====================================================> (63 + 2) / 65][Stage 125:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 16.491780967 seconds
res127: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 136  OR  partitionIndex = 137  OR   partitionIndex = 246  OR  partitionIndex = 247 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 136  OR  partitionIndex = 137  OR  partitionIndex = 246  OR  partitionIndex = 247 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056628096 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 126:=====================================================> (62 + 2) / 64][Stage 126:======================================================>(63 + 1) / 64]                                                                                [Stage 127:=====================================================> (63 + 2) / 65][Stage 127:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 14.050469102 seconds
res129: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 138  OR  partitionIndex = 139  OR   partitionIndex = 153  OR  partitionIndex = 154 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 138  OR  partitionIndex = 139  OR  partitionIndex = 153  OR  partitionIndex = 154 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.061050269 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 128:======================================================>(63 + 1) / 64]                                                                                [Stage 129:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 18.29499954 seconds
res131: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 14  OR  partitionIndex = 15  OR  pa rtitionIndex = 28  OR  partitionIndex = 29 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 14  OR  partitionIndex = 15  OR  partitionIndex = 28  OR  partitionIndex = 29 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.06096331 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 130:=====================================================> (62 + 2) / 64][Stage 130:======================================================>(63 + 1) / 64]                                                                                [Stage 131:=====================================================> (63 + 2) / 65][Stage 131:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 14.300694524 seconds
res133: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 159  OR  partitionIndex = 172  OR   partitionIndex = 173  OR  partitionIndex = 188 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 159  OR  partitionIndex = 172  OR  partitionIndex = 173  OR  partitionIndex = 188 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051656724 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.569563779 seconds
res135: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 55  OR  partitionIndex = 64  OR  pa rtitionIndex = 65  OR  partitionIndex = 80 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 55  OR  partitionIndex = 64  OR  partitionIndex = 65  OR  partitionIndex = 80 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049296387 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 134:======================================================>(63 + 1) / 64]                                                                                [Stage 135:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 10.703517272 seconds
res137: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68  OR  partitionIndex = 69  OR  pa rtitionIndex = 114  OR  partitionIndex = 115 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68  OR  partitionIndex = 69  OR  partitionIndex = 114  OR  partitionIndex = 115 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052375863 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 136:=====================================================> (62 + 2) / 64]17/06/10 05:59:48 ERROR TaskSchedulerImpl: Lost executor 19 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:59:48 WARN TaskSetManager: Lost task 8.0 in stage 136.0 (TID 8777, 128.110.152.145): ExecutorLostFailure (executor 19 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 136:======================================================>(63 + 1) / 64]                                                                                17/06/10 05:59:56 ERROR TaskSchedulerImpl: Lost executor 12 on 128.110.152.165: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:59:56 WARN TaskSetManager: Lost task 20.0 in stage 137.0 (TID 8854, 128.110.152.165): ExecutorLostFailure (executor 12 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 137:=============================================>        (55 + 10) / 65][Stage 137:=====================================================> (63 + 2) / 65][Stage 137:======================================================>(64 + 1) / 65]17/06/10 06:00:05 ERROR TaskSchedulerImpl: Lost executor 11 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:00:05 WARN TaskSetManager: Lost task 20.1 in stage 137.0 (TID 8899, 128.110.152.168): ExecutorLostFailure (executor 11 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 34.701234906 seconds
res139: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 4  OR  partitionIndex = 5  OR  part itionIndex = 20  OR  partitionIndex = 51 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 4  OR  partitionIndex = 5  OR  partitionIndex = 20  OR  partitionIndex = 51 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048243589 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 138:======================================>               (46 + 18) / 64][Stage 138:=======================================>              (47 + 17) / 64][Stage 138:================================================>      (56 + 8) / 64]                                                                                [Stage 139:=====================================================> (63 + 2) / 65][Stage 139:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 12.882105552 seconds
res141: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 12  OR  partitionIndex = 43  OR  pa rtitionIndex = 58  OR  partitionIndex = 59 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 12  OR  partitionIndex = 43  OR  partitionIndex = 58  OR  partitionIndex = 59 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.065455904 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 140:====================================================>  (61 + 3) / 64][Stage 140:=====================================================> (62 + 2) / 64][Stage 140:======================================================>(63 + 1) / 64]                                                                                [Stage 141:====================================================>  (62 + 3) / 65][Stage 141:=====================================================> (63 + 2) / 65][Stage 141:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.802990095 seconds
res143: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 238  OR  partitionIndex = 239  OR   partitionIndex = 252  OR  partitionIndex = 253 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 238  OR  partitionIndex = 239  OR  partitionIndex = 252  OR  partitionIndex = 253 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050433826 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.687260836 seconds
res145: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 141  OR  partitionIndex = 142  OR   partitionIndex = 156  OR  partitionIndex = 157 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 141  OR  partitionIndex = 142  OR  partitionIndex = 156  OR  partitionIndex = 157 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045618053 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 144:=====================================================> (62 + 2) / 64][Stage 144:======================================================>(63 + 1) / 64]                                                                                [Stage 145:=====================================================> (63 + 2) / 65][Stage 145:======================================================>(64 + 1) / 65]17/06/10 06:01:08 ERROR TaskSchedulerImpl: Lost executor 2 on 128.110.152.160: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:01:08 WARN TaskSetManager: Lost task 24.0 in stage 145.0 (TID 9376, 128.110.152.160): ExecutorLostFailure (executor 2 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:01:08 ERROR TaskSchedulerImpl: Lost executor 1 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:01:08 WARN TaskSetManager: Lost task 24.1 in stage 145.0 (TID 9417, 128.110.152.142): ExecutorLostFailure (executor 1 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 21.968022782 seconds
res147: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 106  OR  partitionIndex = 107  OR   partitionIndex = 120  OR  partitionIndex = 121 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 106  OR  partitionIndex = 107  OR  partitionIndex = 120  OR  partitionIndex = 121 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050659726 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 146:=======================================>              (47 + 17) / 64][Stage 146:===============================================>       (55 + 9) / 64][Stage 146:======================================================>(63 + 1) / 64]                                                                                [Stage 147:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.849869067 seconds
res149: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 194  OR  partitionIndex = 195  OR   partitionIndex = 210  OR  partitionIndex = 211 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 194  OR  partitionIndex = 195  OR  partitionIndex = 210  OR  partitionIndex = 211 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048961009 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 148:=====================================================> (62 + 2) / 64][Stage 148:======================================================>(63 + 1) / 64]17/06/10 06:01:45 ERROR TaskSchedulerImpl: Lost executor 14 on 128.110.152.152: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:01:45 WARN TaskSetManager: Lost task 37.0 in stage 148.0 (TID 9585, 128.110.152.152): ExecutorLostFailure (executor 14 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 149:=============================================>        (55 + 10) / 65][Stage 149:=====================================================> (63 + 2) / 65][Stage 149:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 24.589732517 seconds
res151: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 66  OR  partitionIndex = 67  OR  pa rtitionIndex = 82  OR  partitionIndex = 83 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 66  OR  partitionIndex = 67  OR  partitionIndex = 82  OR  partitionIndex = 83 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049180689 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 150:======================================================>(63 + 1) / 64]                                                                                [Stage 151:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 14.392236196 seconds
res153: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 138  OR  partitionIndex = 139  OR   partitionIndex = 152  OR  partitionIndex = 153 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 138  OR  partitionIndex = 139  OR  partitionIndex = 152  OR  partitionIndex = 153 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053192763 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 152:======================================================>(63 + 1) / 64]                                                                                [Stage 153:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.563654644 seconds
res155: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 170  OR  partitionIndex = 171  OR   partitionIndex = 185  OR  partitionIndex = 186 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 170  OR  partitionIndex = 171  OR  partitionIndex = 185  OR  partitionIndex = 186 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053292183 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.596934058 seconds
res157: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 173  OR  partitionIndex = 174  OR   partitionIndex = 188  OR  partitionIndex = 189 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 173  OR  partitionIndex = 174  OR  partitionIndex = 188  OR  partitionIndex = 189 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.060273693 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 156:======================================================>(63 + 1) / 64]                                                                                [Stage 157:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 17.159857017 seconds
res159: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 4  OR  partitionIndex = 5  OR  part itionIndex = 50  OR  partitionIndex = 51 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 4  OR  partitionIndex = 5  OR  partitionIndex = 50  OR  partitionIndex = 51 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052291324 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 158:=====================================================> (62 + 2) / 64][Stage 158:======================================================>(63 + 1) / 64]                                                                                [Stage 159:=====================================================> (63 + 2) / 65][Stage 159:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 12.870577778 seconds
res161: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 78  OR  partitionIndex = 79  OR  pa rtitionIndex = 93  OR  partitionIndex = 94 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 78  OR  partitionIndex = 79  OR  partitionIndex = 93  OR  partitionIndex = 94 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054610081 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 160:======================================================>(63 + 1) / 64]17/06/10 06:03:22 ERROR TaskSchedulerImpl: Lost executor 22 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:03:22 WARN TaskSetManager: Lost task 11.0 in stage 160.0 (TID 10334, 128.110.152.141): ExecutorLostFailure (executor 22 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 161:================================================>      (57 + 8) / 65][Stage 161:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 29.796635719 seconds
res163: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 15  OR  partitionIndex = 30  OR  pa rtitionIndex = 31  OR  partitionIndex = 44 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 15  OR  partitionIndex = 30  OR  partitionIndex = 31  OR  partitionIndex = 44 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046397314 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 162:=====================================================> (62 + 2) / 64][Stage 162:======================================================>(63 + 1) / 64]                                                                                [Stage 163:=====================================================> (63 + 2) / 65][Stage 163:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 12.656532408 seconds
res165: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 238  OR  partitionIndex = 239  OR   partitionIndex = 253  OR  partitionIndex = 254 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 238  OR  partitionIndex = 239  OR  partitionIndex = 253  OR  partitionIndex = 254 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053948191 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 164:======================================================>(63 + 1) / 64]                                                                                [Stage 165:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 12.017883015 seconds
res167: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 140  OR  partitionIndex = 141  OR   partitionIndex = 186  OR  partitionIndex = 187 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 140  OR  partitionIndex = 141  OR  partitionIndex = 186  OR  partitionIndex = 187 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050086025 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.73686157 seconds
res169: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 111  OR  partitionIndex = 126  OR   partitionIndex = 127  OR  partitionIndex = 128 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 111  OR  partitionIndex = 126  OR  partitionIndex = 127  OR  partitionIndex = 128 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049422364 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 168:======================================================>(63 + 1) / 64]                                                                                [Stage 169:======================================================>(64 + 1) / 65][Stage 169:======================================================>(64 + 1) / 65][Stage 169:======================================================>(64 + 1) / 65][Stage 169:======================================================>(64 + 1) / 65][Stage 169:======================================================>(64 + 1) / 65][Stage 169:======================================================>(64 + 1) / 65][Stage 169:======================================================>(64 + 1) / 65][Stage 169:======================================================>(64 + 1) / 65][Stage 169:======================================================>(64 + 1) / 65][Stage 169:======================================================>(64 + 1) / 65]17/06/10 06:13:56 ERROR TaskSchedulerImpl: Lost executor 29 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:13:56 WARN TaskSetManager: Lost task 24.0 in stage 169.0 (TID 10928, 128.110.152.141): ExecutorLostFailure (executor 29 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:13:56 ERROR TransportResponseHandler: Still have 1 requests outstanding when connection from /128.110.152.141:42666 is closed
17/06/10 06:13:56 WARN BlockManagerMaster: Failed to remove broadcast 253 with removeFromMaster = true - Connection from /128.110.152.141:42666 closed
java.io.IOException: Connection from /128.110.152.141:42666 closed
	at org.apache.spark.network.client.TransportResponseHandler.channelInactive(TransportResponseHandler.java:128)
	at org.apache.spark.network.server.TransportChannelHandler.channelInactive(TransportChannelHandler.java:109)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at io.netty.handler.timeout.IdleStateHandler.channelInactive(IdleStateHandler.java:257)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at org.apache.spark.network.util.TransportFrameDecoder.channelInactive(TransportFrameDecoder.java:182)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.DefaultChannelPipeline.fireChannelInactive(DefaultChannelPipeline.java:828)
	at io.netty.channel.AbstractChannel$AbstractUnsafe$7.run(AbstractChannel.java:621)
	at io.netty.util.concurrent.SingleThreadEventExecutor.runAllTasks(SingleThreadEventExecutor.java:357)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:357)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 06:13:56 ERROR ContextCleaner: Error cleaning broadcast 253
org.apache.spark.SparkException: Exception thrown in awaitResult
	at org.apache.spark.rpc.RpcTimeout$$anonfun$1.applyOrElse(RpcTimeout.scala:77)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$1.applyOrElse(RpcTimeout.scala:75)
	at scala.runtime.AbstractPartialFunction.apply(AbstractPartialFunction.scala:36)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$addMessageIfTimeout$1.applyOrElse(RpcTimeout.scala:59)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$addMessageIfTimeout$1.applyOrElse(RpcTimeout.scala:59)
	at scala.PartialFunction$OrElse.apply(PartialFunction.scala:167)
	at org.apache.spark.rpc.RpcTimeout.awaitResult(RpcTimeout.scala:83)
	at org.apache.spark.storage.BlockManagerMaster.removeBroadcast(BlockManagerMaster.scala:143)
	at org.apache.spark.broadcast.TorrentBroadcast$.unpersist(TorrentBroadcast.scala:267)
	at org.apache.spark.broadcast.TorrentBroadcastFactory.unbroadcast(TorrentBroadcastFactory.scala:45)
	at org.apache.spark.broadcast.BroadcastManager.unbroadcast(BroadcastManager.scala:60)
	at org.apache.spark.ContextCleaner.doCleanupBroadcast(ContextCleaner.scala:232)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1$$anonfun$apply$mcV$sp$2.apply(ContextCleaner.scala:188)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1$$anonfun$apply$mcV$sp$2.apply(ContextCleaner.scala:179)
	at scala.Option.foreach(Option.scala:257)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1.apply$mcV$sp(ContextCleaner.scala:179)
	at org.apache.spark.util.Utils$.tryOrStopSparkContext(Utils.scala:1252)
	at org.apache.spark.ContextCleaner.org$apache$spark$ContextCleaner$$keepCleaning(ContextCleaner.scala:172)
	at org.apache.spark.ContextCleaner$$anon$1.run(ContextCleaner.scala:67)
Caused by: java.io.IOException: Connection from /128.110.152.141:42666 closed
	at org.apache.spark.network.client.TransportResponseHandler.channelInactive(TransportResponseHandler.java:128)
	at org.apache.spark.network.server.TransportChannelHandler.channelInactive(TransportChannelHandler.java:109)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at io.netty.handler.timeout.IdleStateHandler.channelInactive(IdleStateHandler.java:257)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at org.apache.spark.network.util.TransportFrameDecoder.channelInactive(TransportFrameDecoder.java:182)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.DefaultChannelPipeline.fireChannelInactive(DefaultChannelPipeline.java:828)
	at io.netty.channel.AbstractChannel$AbstractUnsafe$7.run(AbstractChannel.java:621)
	at io.netty.util.concurrent.SingleThreadEventExecutor.runAllTasks(SingleThreadEventExecutor.java:357)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:357)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
                                                                                Time elapsed: 586.863838156 seconds
res171: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 166  OR  partitionIndex = 167  OR   partitionIndex = 181  OR  partitionIndex = 182 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 166  OR  partitionIndex = 167  OR  partitionIndex = 181  OR  partitionIndex = 182 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.066458738 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 170:===============================================>       (55 + 9) / 64][Stage 170:======================================================>(63 + 1) / 64]                                                                                [Stage 171:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 17.758990651 seconds
res173: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 95  OR  partitionIndex = 108  OR  p artitionIndex = 109  OR  partitionIndex = 124 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 95  OR  partitionIndex = 108  OR  partitionIndex = 109  OR  partitionIndex = 124 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052403557 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 172:=====================================================> (62 + 2) / 64][Stage 172:======================================================>(63 + 1) / 64]                                                                                [Stage 173:=====================================================> (63 + 2) / 65]                                                                                Time elapsed: 14.443735288 seconds
res175: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 214  OR  partitionIndex = 215  OR   partitionIndex = 228  OR  partitionIndex = 229 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 214  OR  partitionIndex = 215  OR  partitionIndex = 228  OR  partitionIndex = 229 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045345546 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.711138582 seconds
res177: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 30  OR  partitionIndex = 31  OR  pa rtitionIndex = 44  OR  partitionIndex = 45 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 30  OR  partitionIndex = 31  OR  partitionIndex = 44  OR  partitionIndex = 45 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048076351 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 176:=====================================================> (62 + 2) / 64][Stage 176:======================================================>(63 + 1) / 64]                                                                                [Stage 177:=====================================================> (63 + 2) / 65][Stage 177:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 16.361368735 seconds
res179: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 14  OR  partitionIndex = 15  OR  pa rtitionIndex = 30  OR  partitionIndex = 31 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 14  OR  partitionIndex = 15  OR  partitionIndex = 30  OR  partitionIndex = 31 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049149612 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 178:=====================================================> (62 + 2) / 64][Stage 178:======================================================>(63 + 1) / 64]                                                                                [Stage 179:=====================================================> (63 + 2) / 65][Stage 179:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 11.992111677 seconds
res181: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 237  OR  partitionIndex = 238  OR   partitionIndex = 252  OR  partitionIndex = 253 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 237  OR  partitionIndex = 238  OR  partitionIndex = 252  OR  partitionIndex = 253 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053044817 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 180:======================================================>(63 + 1) / 64]                                                                                [Stage 181:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 12.179001512 seconds
res183: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 203  OR  partitionIndex = 218  OR   partitionIndex = 219  OR  partitionIndex = 232 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 203  OR  partitionIndex = 218  OR  partitionIndex = 219  OR  partitionIndex = 232 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.066111416 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 182:=====================================================> (62 + 2) / 64][Stage 182:======================================================>(63 + 1) / 64]17/06/10 06:15:41 ERROR TaskSchedulerImpl: Lost executor 30 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:15:41 WARN TaskSetManager: Lost task 34.0 in stage 182.0 (TID 11778, 128.110.152.141): ExecutorLostFailure (executor 30 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 183:=============================================>        (55 + 10) / 65][Stage 183:=====================================================> (63 + 2) / 65][Stage 183:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 25.558552326 seconds
res185: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 38  OR  partitionIndex = 39  OR  pa rtitionIndex = 54  OR  partitionIndex = 55 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 38  OR  partitionIndex = 39  OR  partitionIndex = 54  OR  partitionIndex = 55 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046088986 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 184:=====================================================> (62 + 2) / 64][Stage 184:======================================================>(63 + 1) / 64]                                                                                [Stage 185:=====================================================> (63 + 2) / 65][Stage 185:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.307023933 seconds
res187: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 132  OR  partitionIndex = 163  OR   partitionIndex = 178  OR  partitionIndex = 179 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 132  OR  partitionIndex = 163  OR  partitionIndex = 178  OR  partitionIndex = 179 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.088431427 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 186:=====================================================> (62 + 2) / 64][Stage 186:======================================================>(63 + 1) / 64]17/06/10 06:16:25 ERROR TaskSchedulerImpl: Lost executor 21 on 128.110.152.157: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:16:25 WARN TaskSetManager: Lost task 37.0 in stage 186.0 (TID 12040, 128.110.152.157): ExecutorLostFailure (executor 21 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 187:=============================================>        (55 + 10) / 65][Stage 187:=====================================================> (63 + 2) / 65][Stage 187:======================================================>(64 + 1) / 65]17/06/10 06:16:38 ERROR TaskSchedulerImpl: Lost executor 25 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:16:38 WARN TaskSetManager: Lost task 24.0 in stage 187.0 (TID 12092, 128.110.152.168): ExecutorLostFailure (executor 25 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 29.512470324 seconds
res189: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 102  OR  partitionIndex = 103  OR   partitionIndex = 118  OR  partitionIndex = 119 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 102  OR  partitionIndex = 103  OR  partitionIndex = 118  OR  partitionIndex = 119 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.044632484 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 188:===============================================>       (55 + 9) / 64][Stage 188:=====================================================> (62 + 2) / 64][Stage 188:======================================================>(63 + 1) / 64]                                                                                17/06/10 06:17:03 ERROR TaskSchedulerImpl: Lost executor 27 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:17:03 WARN TaskSetManager: Lost task 20.0 in stage 189.0 (TID 12218, 128.110.152.142): ExecutorLostFailure (executor 27 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 189:=====================================================> (63 + 2) / 65][Stage 189:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 22.955047695 seconds
res191: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 54  OR  partitionIndex = 55  OR  pa rtitionIndex = 64  OR  partitionIndex = 65 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 54  OR  partitionIndex = 55  OR  partitionIndex = 64  OR  partitionIndex = 65 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05670228 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 190:===============================================>       (55 + 9) / 64][Stage 190:================================================>      (56 + 8) / 64]                                                                                [Stage 191:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 12.447461944 seconds
res193: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 194  OR  partitionIndex = 195  OR   partitionIndex = 208  OR  partitionIndex = 209 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 194  OR  partitionIndex = 195  OR  partitionIndex = 208  OR  partitionIndex = 209 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045784705 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 06:17:29 ERROR TaskSchedulerImpl: Lost executor 31 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:17:29 WARN TaskSetManager: Lost task 8.0 in stage 192.0 (TID 12401, 128.110.152.141): ExecutorLostFailure (executor 31 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:17:29 WARN TaskSetManager: Lost task 48.0 in stage 192.0 (TID 12441, 128.110.152.141): ExecutorLostFailure (executor 31 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 192:====================================================>  (61 + 1) / 64][Stage 192:=====================================================> (62 + 2) / 64][Stage 192:======================================================>(63 + 1) / 64]                                                                                [Stage 193:=============================================>        (55 + 10) / 65][Stage 193:=====================================================> (63 + 2) / 65][Stage 193:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 17.132266938 seconds
res195: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 172  OR  partitionIndex = 173  OR   partitionIndex = 188  OR  partitionIndex = 189 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 172  OR  partitionIndex = 173  OR  partitionIndex = 188  OR  partitionIndex = 189 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046574326 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.681720118 seconds
res197: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 199  OR  partitionIndex = 214  OR   partitionIndex = 215  OR  partitionIndex = 228 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 199  OR  partitionIndex = 214  OR  partitionIndex = 215  OR  partitionIndex = 228 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04302564 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 196:=====================================================> (62 + 2) / 64][Stage 196:======================================================>(63 + 1) / 64]                                                                                [Stage 197:=====================================================> (63 + 2) / 65][Stage 197:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 16.962247021 seconds
res199: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 66  OR  partitionIndex = 67  OR  pa rtitionIndex = 81  OR  partitionIndex = 82 ", 4))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 66  OR  partitionIndex = 67  OR  partitionIndex = 81  OR  partitionIndex = 82 ",4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057494341 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 198:======================================================>(63 + 1) / 64]                                                                                [Stage 199:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.822871469 seconds
res201: Int = 0

scala> 

scala> :quit
