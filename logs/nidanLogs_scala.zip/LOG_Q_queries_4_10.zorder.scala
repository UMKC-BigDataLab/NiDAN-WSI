Using Spark's default log4j profile: org/apache/spark/log4j-defaults.properties
Setting default log level to "WARN".
To adjust logging level use sc.setLogLevel(newLevel).
17/06/10 06:18:45 WARN NativeCodeLoader: Unable to load native-hadoop library for your platform... using builtin-java classes where applicable
17/06/10 06:18:47 WARN SparkContext: Use an existing SparkContext, some configuration may not take effect.
Spark context Web UI available at http://128.110.152.156:4040
Spark context available as 'sc' (master = spark://ctl:7077, app id = app-20170610061847-0062).
Spark session available as 'spark'.
Welcome to
      ____              __
     / __/__  ___ _____/ /__
    _\ \/ _ \/ _ `/ __/  '_/
   /___/ .__/\_,_/_/ /_/\_\   version 2.0.2
      /_/
         
Using Scala version 2.11.8 (OpenJDK 64-Bit Server VM, Java 1.8.0_131)
Type in expressions to have them evaluated.
Type :help for more information.

scala>  
     | import java.io.File
import java.io.File

scala> import java.io.FileOutputStream
import java.io.FileOutputStream

scala> import org.apache.spark.sql._
import org.apache.spark.sql._

scala> 

scala> def show_timing[T](proc: => T): T = {
     |     val start=System.nanoTime()
     |     val res = proc
     |     val end = System.nanoTime()
     |     println("Time elapsed: " + (end-start)/1000000000.0 + " seconds")
     |     res
     | }
show_timing: [T](proc: => T)T

scala> 

scala> val writeToLocal = (in:(Array[Byte], Long, String)) =>{
     |     val bytes = in._1
     |     val output = in._3
     |     
     |     val writer = new FileOutputStream(output)
     |     writer.write(bytes)
     |     writer.close
     |     1
     |   }
writeToLocal: ((Array[Byte], Long, String)) => Int = <function1>

scala> 

scala> val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)
warning: there was one deprecation warning; re-run with -deprecation for details
sqlContext: org.apache.spark.sql.hive.HiveContext = org.apache.spark.sql.hive.HiveContext@3ce7394f

scala>   
     | val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=150 AND partitionZIndex<=153", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=150 AND partitionZIndex<=153,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 15.774108936 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 0:>                                                        (0 + 64) / 64][Stage 0:>                                                        (1 + 63) / 64][Stage 0:================================================>        (55 + 9) / 64][Stage 0:=======================================================> (62 + 2) / 64][Stage 0:========================================================>(63 + 1) / 64]                                                                                [Stage 1:=======================================================> (63 + 2) / 65][Stage 1:========================================================>(64 + 1) / 65]                                                                                Time elapsed: 23.368524841 seconds
res3: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=69 AND partitionZIndex<=72", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=69 AND partitionZIndex<=72,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.14582234 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 2:>                                                         (0 + 0) / 64][Stage 2:=====================================================>   (60 + 4) / 64][Stage 2:======================================================>  (61 + 3) / 64][Stage 2:=======================================================> (62 + 2) / 64]                                                                                [Stage 3:======================================================>  (62 + 3) / 65][Stage 3:=======================================================> (63 + 2) / 65][Stage 3:========================================================>(64 + 1) / 65]                                                                                Time elapsed: 17.34448092 seconds
res5: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=155 AND partitionZIndex<=158", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=155 AND partitionZIndex<=158,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.164597684 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 4:=====================================================>   (60 + 4) / 64][Stage 4:=======================================================> (62 + 2) / 64][Stage 4:========================================================>(63 + 1) / 64]                                                                                [Stage 5:=======================================================> (63 + 2) / 65][Stage 5:========================================================>(64 + 1) / 65]                                                                                Time elapsed: 18.259723641 seconds
res7: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=125 AND partitionZIndex<=128", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=125 AND partitionZIndex<=128,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.122383086 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 6:========================================================>(63 + 1) / 64]                                                                                [Stage 7:========================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.321064836 seconds
res9: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=168 AND partitionZIndex<=171", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=168 AND partitionZIndex<=171,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.130301496 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 8:======================================================>  (61 + 3) / 64][Stage 8:=======================================================> (62 + 2) / 64][Stage 8:========================================================>(63 + 1) / 64]                                                                                [Stage 9:======================================================>  (62 + 3) / 65][Stage 9:=======================================================> (63 + 2) / 65]                                                                                Time elapsed: 16.749761464 seconds
res11: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=68 AND partitionZIndex<=71", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=68 AND partitionZIndex<=71,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.137604784 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 10:=====================================================>  (61 + 3) / 64][Stage 10:======================================================> (62 + 2) / 64][Stage 10:=======================================================>(63 + 1) / 64]                                                                                [Stage 11:=====================================================>  (62 + 3) / 65][Stage 11:======================================================> (63 + 2) / 65][Stage 11:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 17.905139585 seconds
res13: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=248 AND partitionZIndex<=251", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=248 AND partitionZIndex<=251,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.081041648 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.918888826 seconds
res15: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=197 AND partitionZIndex<=200", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=197 AND partitionZIndex<=200,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.08948198 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 14:=====================================================>  (61 + 3) / 64][Stage 14:======================================================> (62 + 2) / 64][Stage 14:=======================================================>(63 + 1) / 64]                                                                                [Stage 15:=============================================>         (54 + 11) / 65][Stage 15:=====================================================>  (62 + 3) / 65][Stage 15:======================================================> (63 + 2) / 65][Stage 15:=======================================================>(64 + 1) / 65]17/06/10 06:21:50 ERROR TaskSchedulerImpl: Lost executor 7 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:21:50 WARN TaskSetManager: Lost task 24.0 in stage 15.0 (TID 991, 128.110.152.145): ExecutorLostFailure (executor 7 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 25.694849909 seconds
res17: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=232 AND partitionZIndex<=235", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=232 AND partitionZIndex<=235,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.07498076 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 16:========================================>              (47 + 17) / 64][Stage 16:================================================>       (55 + 9) / 64][Stage 16:=================================================>      (56 + 8) / 64][Stage 16:=================================================>      (56 + 8) / 64][Stage 16:=================================================>      (56 + 8) / 64][Stage 16:=================================================>      (56 + 8) / 64][Stage 16:=================================================>      (56 + 8) / 64]17/06/10 06:27:01 ERROR TaskSchedulerImpl: Lost executor 5 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:27:01 WARN TaskSetManager: Lost task 46.0 in stage 16.0 (TID 1079, 128.110.152.141): ExecutorLostFailure (executor 5 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:27:01 WARN TaskSetManager: Lost task 22.0 in stage 16.0 (TID 1055, 128.110.152.141): ExecutorLostFailure (executor 5 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:27:01 WARN TaskSetManager: Lost task 54.0 in stage 16.0 (TID 1087, 128.110.152.141): ExecutorLostFailure (executor 5 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:27:01 WARN TaskSetManager: Lost task 30.0 in stage 16.0 (TID 1063, 128.110.152.141): ExecutorLostFailure (executor 5 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:27:01 WARN TaskSetManager: Lost task 6.0 in stage 16.0 (TID 1039, 128.110.152.141): ExecutorLostFailure (executor 5 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:27:01 WARN TaskSetManager: Lost task 14.0 in stage 16.0 (TID 1047, 128.110.152.141): ExecutorLostFailure (executor 5 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:27:01 WARN TaskSetManager: Lost task 62.0 in stage 16.0 (TID 1095, 128.110.152.141): ExecutorLostFailure (executor 5 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:27:01 WARN TaskSetManager: Lost task 38.0 in stage 16.0 (TID 1071, 128.110.152.141): ExecutorLostFailure (executor 5 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 16:=======================================================>(63 + 1) / 64]                                                                                [Stage 17:==============================================>        (55 + 10) / 65][Stage 17:======================================================> (63 + 2) / 65][Stage 17:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 309.265980692 seconds
res19: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=222 AND partitionZIndex<=225", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=222 AND partitionZIndex<=225,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.090852953 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 18:======================================================> (62 + 2) / 64][Stage 18:=======================================================>(63 + 1) / 64]                                                                                [Stage 19:======================================================> (63 + 2) / 65][Stage 19:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 14.074245422 seconds
res21: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=77 AND partitionZIndex<=80", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=77 AND partitionZIndex<=80,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.085762626 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 06:27:34 ERROR TaskSchedulerImpl: Lost executor 9 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:27:34 WARN TaskSetManager: Lost task 10.0 in stage 20.0 (TID 1309, 128.110.152.141): ExecutorLostFailure (executor 9 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 20:=====================================================>  (61 + 3) / 64][Stage 20:======================================================> (62 + 2) / 64][Stage 20:=======================================================>(63 + 1) / 64]17/06/10 06:27:40 ERROR TaskSchedulerImpl: Lost executor 8 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:27:40 WARN TaskSetManager: Lost task 10.1 in stage 20.0 (TID 1363, 128.110.152.145): ExecutorLostFailure (executor 8 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 21:=======================================>               (47 + 18) / 65][Stage 21:==============================================>        (55 + 10) / 65][Stage 21:=====================================================>  (62 + 3) / 65][Stage 21:======================================================> (63 + 2) / 65][Stage 21:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 25.53216556 seconds
res23: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=98 AND partitionZIndex<=101", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=98 AND partitionZIndex<=101,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.078538916 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 22:======================================================> (62 + 2) / 64][Stage 22:=======================================================>(63 + 1) / 64]17/06/10 06:28:09 ERROR TaskSchedulerImpl: Lost executor 3 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:28:09 WARN TaskSetManager: Lost task 24.0 in stage 22.0 (TID 1454, 128.110.152.168): ExecutorLostFailure (executor 3 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 23:==============================================>        (55 + 10) / 65][Stage 23:======================================================> (63 + 2) / 65][Stage 23:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 22.691365869 seconds
res25: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=112 AND partitionZIndex<=115", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=112 AND partitionZIndex<=115,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.067149622 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 24:======================================================> (62 + 2) / 64]                                                                                [Stage 25:======================================================> (63 + 2) / 65][Stage 25:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.368959096 seconds
res27: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=147 AND partitionZIndex<=150", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=147 AND partitionZIndex<=150,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.085732804 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 26:======================================================> (62 + 2) / 64][Stage 26:=======================================================>(63 + 1) / 64]                                                                                [Stage 27:======================================================> (63 + 2) / 65][Stage 27:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.484120099 seconds
res29: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=8 AND partitionZIndex<=11", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=8 AND partitionZIndex<=11,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.072615387 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 28:======================================================> (62 + 2) / 64][Stage 28:=======================================================>(63 + 1) / 64]                                                                                [Stage 29:======================================================> (63 + 2) / 65]17/06/10 06:29:12 ERROR TaskSchedulerImpl: Lost executor 10 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:29:12 WARN TaskSetManager: Lost task 3.0 in stage 29.0 (TID 1885, 128.110.152.141): ExecutorLostFailure (executor 10 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 29:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.827414254 seconds
res31: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=103 AND partitionZIndex<=106", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=103 AND partitionZIndex<=106,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.068793522 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 30:==============================================>        (54 + 10) / 64][Stage 30:======================================================> (62 + 2) / 64][Stage 30:=======================================================>(63 + 1) / 64]                                                                                [Stage 31:======================================================> (63 + 2) / 65][Stage 31:=======================================================>(64 + 1) / 65]17/06/10 06:29:38 ERROR TaskSchedulerImpl: Lost executor 13 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:29:38 WARN TaskSetManager: Lost task 8.0 in stage 31.0 (TID 2020, 128.110.152.141): ExecutorLostFailure (executor 13 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 24.1207216 seconds
res33: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=240 AND partitionZIndex<=243", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=240 AND partitionZIndex<=243,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.068514982 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 32:=================================================>      (56 + 8) / 64]                                                                                Time elapsed: 5.873161599 seconds
res35: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=80 AND partitionZIndex<=83", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=80 AND partitionZIndex<=83,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.07613055 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 34:=====================================================>  (61 + 3) / 64][Stage 34:======================================================> (62 + 2) / 64][Stage 34:=======================================================>(63 + 1) / 64]17/06/10 06:30:02 ERROR TaskSchedulerImpl: Lost executor 11 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:30:02 WARN TaskSetManager: Lost task 24.0 in stage 34.0 (TID 2231, 128.110.152.145): ExecutorLostFailure (executor 11 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 35:=============================================>         (54 + 11) / 65][Stage 35:=====================================================>  (62 + 3) / 65][Stage 35:======================================================> (63 + 2) / 65]                                                                                Time elapsed: 20.894757694 seconds
res37: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=170 AND partitionZIndex<=173", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=170 AND partitionZIndex<=173,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.068963842 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 36:=====================================================>  (61 + 3) / 64][Stage 36:======================================================> (62 + 2) / 64][Stage 36:=======================================================>(63 + 1) / 64]                                                                                [Stage 37:=====================================================>  (62 + 3) / 65][Stage 37:======================================================> (63 + 2) / 65][Stage 37:=======================================================>(64 + 1) / 65]17/06/10 06:30:57 ERROR TaskSchedulerImpl: Lost executor 0 on 128.110.152.165: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:30:57 WARN TaskSetManager: Lost task 48.0 in stage 37.0 (TID 2449, 128.110.152.165): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 46.70164651 seconds
res39: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=60 AND partitionZIndex<=63", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=60 AND partitionZIndex<=63,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.067562119 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 38:=============================================>         (53 + 11) / 64][Stage 38:==============================================>        (54 + 10) / 64][Stage 38:======================================================> (62 + 2) / 64][Stage 38:=======================================================>(63 + 1) / 64]                                                                                [Stage 39:=====================================================>  (62 + 3) / 65][Stage 39:======================================================> (63 + 2) / 65][Stage 39:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.480745537 seconds
res41: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=46 AND partitionZIndex<=49", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=46 AND partitionZIndex<=49,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.082016696 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 06:31:26 ERROR TaskSchedulerImpl: Lost executor 15 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:31:26 WARN TaskSetManager: Lost task 20.0 in stage 40.0 (TID 2616, 128.110.152.145): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 40:=====================================================>  (61 + 3) / 64][Stage 40:======================================================> (62 + 2) / 64][Stage 40:=======================================================>(63 + 1) / 64]                                                                                [Stage 41:==============================================>        (55 + 10) / 65][Stage 41:================================================>       (56 + 9) / 65][Stage 41:======================================================> (63 + 2) / 65][Stage 41:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 18.498698509 seconds
res43: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=193 AND partitionZIndex<=196", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=193 AND partitionZIndex<=196,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.062974633 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 42:=====================================================>  (61 + 3) / 64][Stage 42:======================================================> (62 + 2) / 64][Stage 42:=======================================================>(63 + 1) / 64]                                                                                17/06/10 06:31:56 ERROR TaskSchedulerImpl: Lost executor 14 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:31:56 WARN TaskSetManager: Lost task 48.0 in stage 43.0 (TID 2838, 128.110.152.141): ExecutorLostFailure (executor 14 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 43:=====================================================>  (62 + 3) / 65][Stage 43:======================================================> (63 + 2) / 65][Stage 43:=======================================================>(64 + 1) / 65]17/06/10 06:32:06 ERROR TaskSchedulerImpl: Lost executor 2 on 128.110.152.160: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:32:06 WARN TaskSetManager: Lost task 20.0 in stage 43.0 (TID 2810, 128.110.152.160): ExecutorLostFailure (executor 2 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:32:16 ERROR TaskSchedulerImpl: Lost executor 1 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:32:16 WARN TaskSetManager: Lost task 20.1 in stage 43.0 (TID 2856, 128.110.152.142): ExecutorLostFailure (executor 1 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 38.930499967 seconds
res45: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=174 AND partitionZIndex<=177", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=174 AND partitionZIndex<=177,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.062145211 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 44:================================>                      (38 + 26) / 64][Stage 44:======================================>                (45 + 19) / 64][Stage 44:=============================================>         (53 + 11) / 64][Stage 44:=====================================================>  (61 + 3) / 64][Stage 44:======================================================> (62 + 2) / 64][Stage 44:=======================================================>(63 + 1) / 64]                                                                                [Stage 45:==============================================>        (55 + 10) / 65]17/06/10 06:32:45 ERROR TaskSchedulerImpl: Lost executor 18 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:32:45 WARN TaskSetManager: Lost task 50.0 in stage 45.0 (TID 2972, 128.110.152.141): ExecutorLostFailure (executor 18 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 45:================================================>       (56 + 9) / 65][Stage 45:=================================================>      (57 + 8) / 65][Stage 45:=================================================>      (57 + 8) / 65][Stage 45:=================================================>      (57 + 8) / 65][Stage 45:=================================================>      (57 + 8) / 65][Stage 45:=================================================>      (57 + 8) / 65][Stage 45:=================================================>      (57 + 8) / 65][Stage 45:=================================================>      (57 + 8) / 65][Stage 45:=================================================>      (57 + 8) / 65][Stage 45:=================================================>      (57 + 8) / 65][Stage 45:=================================================>      (57 + 8) / 65][Stage 45:=================================================>      (57 + 8) / 65][Stage 45:=================================================>      (57 + 8) / 65][Stage 45:=================================================>      (57 + 8) / 65][Stage 45:=================================================>      (57 + 8) / 65][Stage 45:=================================================>      (57 + 8) / 65][Stage 45:=================================================>      (57 + 8) / 65][Stage 45:=================================================>      (57 + 8) / 65][Stage 45:=================================================>      (57 + 8) / 65][Stage 45:=================================================>      (57 + 8) / 65][Stage 45:=================================================>      (57 + 8) / 65][Stage 45:=================================================>      (57 + 8) / 65][Stage 45:=================================================>      (57 + 8) / 65]17/06/10 06:54:41 ERROR TaskSchedulerImpl: Lost executor 17 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:54:41 WARN TaskSetManager: Lost task 32.0 in stage 45.0 (TID 2954, 128.110.152.145): ExecutorLostFailure (executor 17 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:54:41 WARN TaskSetManager: Lost task 8.0 in stage 45.0 (TID 2930, 128.110.152.145): ExecutorLostFailure (executor 17 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:54:41 WARN TaskSetManager: Lost task 56.0 in stage 45.0 (TID 2978, 128.110.152.145): ExecutorLostFailure (executor 17 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:54:41 WARN TaskSetManager: Lost task 40.0 in stage 45.0 (TID 2962, 128.110.152.145): ExecutorLostFailure (executor 17 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:54:41 WARN TaskSetManager: Lost task 16.0 in stage 45.0 (TID 2938, 128.110.152.145): ExecutorLostFailure (executor 17 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:54:41 WARN TaskSetManager: Lost task 48.0 in stage 45.0 (TID 2970, 128.110.152.145): ExecutorLostFailure (executor 17 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:54:41 WARN TaskSetManager: Lost task 24.0 in stage 45.0 (TID 2946, 128.110.152.145): ExecutorLostFailure (executor 17 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:54:41 WARN TaskSetManager: Lost task 0.0 in stage 45.0 (TID 2922, 128.110.152.145): ExecutorLostFailure (executor 17 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 45:======================================================> (63 + 2) / 65][Stage 45:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 1340.202906984 seconds
res47: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=199 AND partitionZIndex<=202", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=199 AND partitionZIndex<=202,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.078783131 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 46:================================================>       (55 + 9) / 64][Stage 46:=====================================================>  (61 + 3) / 64][Stage 46:======================================================> (62 + 2) / 64][Stage 46:=======================================================>(63 + 1) / 64]                                                                                [Stage 47:=====================================================>  (62 + 3) / 65][Stage 47:======================================================> (63 + 2) / 65][Stage 47:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 21.033087478 seconds
res49: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=22 AND partitionZIndex<=25", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=22 AND partitionZIndex<=25,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.063130248 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 48:======================================================> (62 + 2) / 64][Stage 48:=======================================================>(63 + 1) / 64]                                                                                [Stage 49:======================================================> (63 + 2) / 65][Stage 49:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 16.241370697 seconds
res51: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=59 AND partitionZIndex<=62", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=59 AND partitionZIndex<=62,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.059957096 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 50:=====================================================>  (61 + 3) / 64][Stage 50:======================================================> (62 + 2) / 64][Stage 50:=======================================================>(63 + 1) / 64]                                                                                [Stage 51:=====================================================>  (62 + 3) / 65][Stage 51:======================================================> (63 + 2) / 65][Stage 51:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 17.200501177 seconds
res53: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=215 AND partitionZIndex<=218", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=215 AND partitionZIndex<=218,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.059040891 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 52:======================================================> (62 + 2) / 64][Stage 52:=======================================================>(63 + 1) / 64]17/06/10 06:55:58 ERROR TaskSchedulerImpl: Lost executor 22 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:55:58 WARN TaskSetManager: Lost task 37.0 in stage 52.0 (TID 3420, 128.110.152.145): ExecutorLostFailure (executor 22 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 53:==============================================>        (55 + 10) / 65][Stage 53:======================================================> (63 + 2) / 65][Stage 53:=======================================================>(64 + 1) / 65]17/06/10 06:56:16 ERROR TaskSchedulerImpl: Lost executor 21 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:56:16 WARN TaskSetManager: Lost task 37.0 in stage 53.0 (TID 3485, 128.110.152.141): ExecutorLostFailure (executor 21 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:56:37 ERROR TaskSchedulerImpl: Lost executor 12 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:56:37 WARN TaskSetManager: Lost task 37.1 in stage 53.0 (TID 3513, 128.110.152.168): ExecutorLostFailure (executor 12 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 54.672579759 seconds
res55: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=160 AND partitionZIndex<=163", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=160 AND partitionZIndex<=163,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.070663294 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 54:=========================================>             (48 + 16) / 64]                                                                                Time elapsed: 5.742002389 seconds
res57: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=76 AND partitionZIndex<=79", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=76 AND partitionZIndex<=79,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055937937 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 56:=====================================================>  (61 + 3) / 64][Stage 56:======================================================> (62 + 2) / 64][Stage 56:=======================================================>(63 + 1) / 64]                                                                                [Stage 57:=====================================================>  (62 + 3) / 65][Stage 57:======================================================> (63 + 2) / 65][Stage 57:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 16.482129323 seconds
res59: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=3 AND partitionZIndex<=6", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=3 AND partitionZIndex<=6,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054930632 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 58:======================================================> (62 + 2) / 64][Stage 58:=======================================================>(63 + 1) / 64]17/06/10 06:57:23 ERROR TaskSchedulerImpl: Lost executor 23 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:57:23 WARN TaskSetManager: Lost task 1.0 in stage 58.0 (TID 3774, 128.110.152.145): ExecutorLostFailure (executor 23 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 59:================================================>       (56 + 9) / 65][Stage 59:======================================================> (63 + 2) / 65][Stage 59:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 18.750574991 seconds
res61: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=198 AND partitionZIndex<=201", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=198 AND partitionZIndex<=201,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053464706 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.713093765 seconds
res63: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=180 AND partitionZIndex<=183", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=180 AND partitionZIndex<=183,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053331705 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.67805343 seconds
res65: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=239 AND partitionZIndex<=242", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=239 AND partitionZIndex<=242,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.076234354 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.616881533 seconds
res67: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=244 AND partitionZIndex<=247", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=244 AND partitionZIndex<=247,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054952531 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 66:=======================================================>(63 + 1) / 64]                                                                                [Stage 67:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 11.939771911 seconds
res69: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=117 AND partitionZIndex<=120", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=117 AND partitionZIndex<=120,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.063282383 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 68:>                                                        (0 + 0) / 64]                                                                                Time elapsed: 0.717804034 seconds
res71: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=1 AND partitionZIndex<=4", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=1 AND partitionZIndex<=4,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.067353599 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 70:=====================================================>  (61 + 3) / 64][Stage 70:======================================================> (62 + 2) / 64][Stage 70:=======================================================>(63 + 1) / 64]                                                                                [Stage 71:=====================================================>  (62 + 3) / 65][Stage 71:======================================================> (63 + 2) / 65][Stage 71:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 11.842361505 seconds
res73: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=73 AND partitionZIndex<=76", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=73 AND partitionZIndex<=76,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.060290951 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.603095888 seconds
res75: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=23 AND partitionZIndex<=26", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=23 AND partitionZIndex<=26,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052843322 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 74:======================================================> (62 + 2) / 64][Stage 74:=======================================================>(63 + 1) / 64]                                                                                [Stage 75:======================================================> (63 + 2) / 65][Stage 75:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 14.403915661 seconds
res77: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=100 AND partitionZIndex<=103", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=100 AND partitionZIndex<=103,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055517012 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.535749205 seconds
res79: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=187 AND partitionZIndex<=190", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=187 AND partitionZIndex<=190,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052691181 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 78:=====================================================>  (61 + 3) / 64][Stage 78:======================================================> (62 + 2) / 64][Stage 78:=======================================================>(63 + 1) / 64]                                                                                [Stage 79:=====================================================>  (62 + 3) / 65][Stage 79:======================================================> (63 + 2) / 65][Stage 79:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 16.820512453 seconds
res81: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=4 AND partitionZIndex<=7", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=4 AND partitionZIndex<=7,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052211119 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 80:=======================================================>(63 + 1) / 64]                                                                                [Stage 81:======================================================> (63 + 2) / 65][Stage 81:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 10.328864421 seconds
res83: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=243 AND partitionZIndex<=246", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=243 AND partitionZIndex<=246,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055439111 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 82:=======================================================>(63 + 1) / 64]                                                                                [Stage 83:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 10.903450951 seconds
res85: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=185 AND partitionZIndex<=188", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=185 AND partitionZIndex<=188,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057907979 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 84:=====================================================>  (61 + 3) / 64]17/06/10 06:59:30 ERROR TaskSchedulerImpl: Lost executor 26 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:59:30 WARN TaskSetManager: Lost task 47.0 in stage 84.0 (TID 5498, 128.110.152.145): ExecutorLostFailure (executor 26 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:59:31 ERROR TaskSchedulerImpl: Lost executor 24 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:59:31 WARN TaskSetManager: Lost task 47.1 in stage 84.0 (TID 5515, 128.110.152.141): ExecutorLostFailure (executor 24 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 06:59:31 WARN TaskSetManager: Lost task 34.0 in stage 84.0 (TID 5485, 128.110.152.141): ExecutorLostFailure (executor 24 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 84:======================================================> (62 + 2) / 64][Stage 84:=======================================================>(63 + 1) / 64]                                                                                [Stage 85:=======================================>               (47 + 18) / 65][Stage 85:==============================================>        (55 + 10) / 65][Stage 85:=====================================================>  (62 + 3) / 65][Stage 85:======================================================> (63 + 2) / 65][Stage 85:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 27.285281369 seconds
res87: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=203 AND partitionZIndex<=206", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=203 AND partitionZIndex<=206,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.072167833 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.736465241 seconds
res89: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=14 AND partitionZIndex<=17", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=14 AND partitionZIndex<=17,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048513163 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 88:=====================================================>  (61 + 3) / 64][Stage 88:======================================================> (62 + 2) / 64][Stage 88:=======================================================>(63 + 1) / 64]17/06/10 07:00:02 ERROR TaskSchedulerImpl: Lost executor 28 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:00:02 WARN TaskSetManager: Lost task 21.0 in stage 88.0 (TID 5733, 128.110.152.141): ExecutorLostFailure (executor 28 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:00:05 ERROR TaskSchedulerImpl: Lost executor 6 on 128.110.152.152: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:00:05 WARN TaskSetManager: Lost task 21.1 in stage 88.0 (TID 5776, 128.110.152.152): ExecutorLostFailure (executor 6 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 89:=======================================>               (47 + 18) / 65]17/06/10 07:00:12 ERROR TaskSchedulerImpl: Lost executor 25 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:00:12 WARN TaskSetManager: Lost task 21.0 in stage 89.0 (TID 5799, 128.110.152.168): ExecutorLostFailure (executor 25 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 89:=====================================================>  (62 + 3) / 65][Stage 89:======================================================> (63 + 2) / 65][Stage 89:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 26.623327689 seconds
res91: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=30 AND partitionZIndex<=33", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=30 AND partitionZIndex<=33,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052194996 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 90:================================================>       (55 + 9) / 64][Stage 90:=================================================>      (56 + 8) / 64]                                                                                [Stage 91:=======================================================>(64 + 1) / 65]17/06/10 07:00:36 ERROR TaskSchedulerImpl: Lost executor 27 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:00:36 WARN TaskSetManager: Lost task 25.0 in stage 91.0 (TID 5933, 128.110.152.145): ExecutorLostFailure (executor 27 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 19.486701141 seconds
res93: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=21 AND partitionZIndex<=24", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=21 AND partitionZIndex<=24,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052436437 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 92:=============================================>         (53 + 11) / 64][Stage 92:==============================================>        (54 + 10) / 64][Stage 92:================================================>       (55 + 9) / 64][Stage 92:=================================================>      (56 + 8) / 64]                                                                                [Stage 93:=====================================================>  (62 + 3) / 65][Stage 93:======================================================> (63 + 2) / 65][Stage 93:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 12.235276761 seconds
res95: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=11 AND partitionZIndex<=14", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=11 AND partitionZIndex<=14,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055693349 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 94:======================================================> (62 + 2) / 64][Stage 94:=======================================================>(63 + 1) / 64]                                                                                [Stage 95:======================================================> (63 + 2) / 65][Stage 95:=======================================================>(64 + 1) / 65]                                                                                Time elapsed: 12.901305295 seconds
res97: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=194 AND partitionZIndex<=197", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=194 AND partitionZIndex<=197,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052788817 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.626530438 seconds
res99: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=176 AND partitionZIndex<=179", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=176 AND partitionZIndex<=179,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050481548 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.575262406 seconds
res101: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=124 AND partitionZIndex<=127", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=124 AND partitionZIndex<=127,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049945187 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.584786421 seconds
res103: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=34 AND partitionZIndex<=37", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=34 AND partitionZIndex<=37,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055630988 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 102:=====================================================> (62 + 2) / 64][Stage 102:======================================================>(63 + 1) / 64]                                                                                [Stage 103:=====================================================> (63 + 2) / 65][Stage 103:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 14.109627437 seconds
res105: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=130 AND partitionZIndex<=133", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=130 AND partitionZIndex<=133,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052477395 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.541204014 seconds
res107: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=205 AND partitionZIndex<=208", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=205 AND partitionZIndex<=208,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049805985 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.566950668 seconds
res109: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=159 AND partitionZIndex<=162", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=159 AND partitionZIndex<=162,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047309216 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 108:====================================================>  (61 + 3) / 64][Stage 108:=====================================================> (62 + 2) / 64][Stage 108:======================================================>(63 + 1) / 64]                                                                                [Stage 109:====================================================>  (62 + 3) / 65][Stage 109:=====================================================> (63 + 2) / 65][Stage 109:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 14.226351453 seconds
res111: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=118 AND partitionZIndex<=121", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=118 AND partitionZIndex<=121,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054744783 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.51487523 seconds
res113: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=119 AND partitionZIndex<=122", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=119 AND partitionZIndex<=122,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051485771 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.49106506 seconds
res115: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=153 AND partitionZIndex<=156", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=153 AND partitionZIndex<=156,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058327777 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 07:02:06 ERROR TaskSchedulerImpl: Lost executor 29 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:02:06 WARN TaskSetManager: Lost task 59.0 in stage 114.0 (TID 7452, 128.110.152.141): ExecutorLostFailure (executor 29 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:02:06 WARN TaskSetManager: Lost task 35.0 in stage 114.0 (TID 7428, 128.110.152.141): ExecutorLostFailure (executor 29 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:02:06 ERROR TaskSchedulerImpl: Lost executor 4 on 128.110.152.157: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:02:06 WARN TaskSetManager: Lost task 20.0 in stage 114.0 (TID 7413, 128.110.152.157): ExecutorLostFailure (executor 4 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 114:=====================================================> (62 + 2) / 64][Stage 114:======================================================>(63 + 1) / 64]17/06/10 07:02:16 ERROR TaskSchedulerImpl: Lost executor 32 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:02:16 WARN TaskSetManager: Lost task 20.1 in stage 114.0 (TID 7459, 128.110.152.145): ExecutorLostFailure (executor 32 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 115:=================================>                    (40 + 25) / 65][Stage 115:===================================>                  (43 + 22) / 65][Stage 115:===============================================>       (56 + 9) / 65][Stage 115:=====================================================> (63 + 2) / 65][Stage 115:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 33.413647097 seconds
res117: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=140 AND partitionZIndex<=143", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=140 AND partitionZIndex<=143,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050186465 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 116:=====================================================> (62 + 2) / 64][Stage 116:======================================================>(63 + 1) / 64]                                                                                [Stage 117:=====================================================> (63 + 2) / 65]                                                                                Time elapsed: 15.662537023 seconds
res119: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=56 AND partitionZIndex<=59", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=56 AND partitionZIndex<=59,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.073739731 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 118:====================================================>  (61 + 3) / 64]17/06/10 07:03:06 ERROR TaskSchedulerImpl: Lost executor 16 on 128.110.152.165: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:03:06 WARN TaskSetManager: Lost task 24.0 in stage 118.0 (TID 7679, 128.110.152.165): ExecutorLostFailure (executor 16 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:03:06 WARN TaskSetManager: Lost task 0.0 in stage 118.0 (TID 7655, 128.110.152.165): ExecutorLostFailure (executor 16 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 118:=====================================================> (62 + 2) / 64][Stage 118:======================================================>(63 + 1) / 64]                                                                                17/06/10 07:03:13 ERROR TaskSchedulerImpl: Lost executor 20 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:03:13 WARN TaskSetManager: Lost task 24.0 in stage 119.0 (TID 7745, 128.110.152.142): ExecutorLostFailure (executor 20 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:03:13 WARN TaskSetManager: Lost task 0.0 in stage 119.0 (TID 7721, 128.110.152.142): ExecutorLostFailure (executor 20 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:03:13 WARN TaskSetManager: Lost task 48.0 in stage 119.0 (TID 7769, 128.110.152.142): ExecutorLostFailure (executor 20 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:03:13 WARN TaskSetManager: Lost task 32.0 in stage 119.0 (TID 7753, 128.110.152.142): ExecutorLostFailure (executor 20 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:03:13 WARN TaskSetManager: Lost task 8.0 in stage 119.0 (TID 7729, 128.110.152.142): ExecutorLostFailure (executor 20 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:03:13 WARN TaskSetManager: Lost task 64.0 in stage 119.0 (TID 7785, 128.110.152.142): ExecutorLostFailure (executor 20 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 119:============================================>         (54 + 11) / 65][Stage 119:====================================================>  (62 + 3) / 65][Stage 119:=====================================================> (63 + 2) / 65][Stage 119:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 21.985350823 seconds
res121: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=2 AND partitionZIndex<=5", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=2 AND partitionZIndex<=5,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058613655 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 120:=============================================>        (54 + 10) / 64][Stage 120:===============================================>       (55 + 9) / 64][Stage 120:======================================================>(63 + 1) / 64]                                                                                [Stage 121:=====================================================> (63 + 2) / 65]17/06/10 07:03:32 ERROR TaskSchedulerImpl: Lost executor 35 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:03:32 WARN TaskSetManager: Lost task 56.0 in stage 121.0 (TID 7912, 128.110.152.145): ExecutorLostFailure (executor 35 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:03:32 WARN TaskSetManager: Lost task 0.0 in stage 121.0 (TID 7856, 128.110.152.145): ExecutorLostFailure (executor 35 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:03:32 ERROR TaskSchedulerImpl: Lost executor 33 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:03:32 WARN TaskSetManager: Lost task 0.1 in stage 121.0 (TID 7921, 128.110.152.141): ExecutorLostFailure (executor 33 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 121:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.561587401 seconds
res123: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=67 AND partitionZIndex<=70", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=67 AND partitionZIndex<=70,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055654384 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 122:=====================================>                (45 + 19) / 64][Stage 122:====================================================>  (61 + 3) / 64][Stage 122:=====================================================> (62 + 2) / 64]                                                                                [Stage 123:====================================================>  (62 + 3) / 65][Stage 123:=====================================================> (63 + 2) / 65][Stage 123:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 17.080386665 seconds
res125: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=135 AND partitionZIndex<=138", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=135 AND partitionZIndex<=138,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051104486 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 124:=====================================================> (62 + 2) / 64][Stage 124:======================================================>(63 + 1) / 64]                                                                                [Stage 125:====================================================>  (62 + 3) / 65][Stage 125:=====================================================> (63 + 2) / 65][Stage 125:======================================================>(64 + 1) / 65][Stage 125:======================================================>(64 + 1) / 65]17/06/10 07:06:12 ERROR TaskSchedulerImpl: Lost executor 39 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:06:12 WARN TaskSetManager: Lost task 20.0 in stage 125.0 (TID 8137, 128.110.152.141): ExecutorLostFailure (executor 39 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 125:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 140.965948953 seconds
res127: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=191 AND partitionZIndex<=194", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=191 AND partitionZIndex<=194,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.065443894 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 126:============================================>         (53 + 11) / 64][Stage 126:====================================================>  (61 + 3) / 64][Stage 126:=====================================================> (62 + 2) / 64][Stage 126:======================================================>(63 + 1) / 64]17/06/10 07:06:32 ERROR TaskSchedulerImpl: Lost executor 38 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:06:32 WARN TaskSetManager: Lost task 24.0 in stage 126.0 (TID 8207, 128.110.152.145): ExecutorLostFailure (executor 38 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 127:============================================>         (54 + 11) / 65][Stage 127:=============================================>        (55 + 10) / 65][Stage 127:=====================================================> (63 + 2) / 65][Stage 127:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 23.510791922 seconds
res129: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=196 AND partitionZIndex<=199", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=196 AND partitionZIndex<=199,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058538169 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 128:====================================================>  (61 + 3) / 64][Stage 128:=====================================================> (62 + 2) / 64][Stage 128:======================================================>(63 + 1) / 64]                                                                                [Stage 129:====================================================>  (62 + 3) / 65]17/06/10 07:06:59 ERROR TaskSchedulerImpl: Lost executor 40 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:06:59 WARN TaskSetManager: Lost task 50.0 in stage 129.0 (TID 8427, 128.110.152.141): ExecutorLostFailure (executor 40 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 129:=====================================================> (63 + 2) / 65][Stage 129:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 17.966476916 seconds
res131: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=83 AND partitionZIndex<=86", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=83 AND partitionZIndex<=86,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050825581 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 130:================================================>      (56 + 8) / 64]                                                                                Time elapsed: 5.741151026 seconds
res133: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=216 AND partitionZIndex<=219", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=216 AND partitionZIndex<=219,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049345456 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.693933804 seconds
res135: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=32 AND partitionZIndex<=35", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=32 AND partitionZIndex<=35,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048561152 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 134:=====================================================> (62 + 2) / 64][Stage 134:======================================================>(63 + 1) / 64]                                                                                17/06/10 07:07:26 ERROR TaskSchedulerImpl: Lost executor 41 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:07:26 WARN TaskSetManager: Lost task 21.0 in stage 135.0 (TID 8786, 128.110.152.145): ExecutorLostFailure (executor 41 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 135:=====================================================> (63 + 2) / 65]17/06/10 07:07:33 ERROR TaskSchedulerImpl: Lost executor 37 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:07:33 WARN TaskSetManager: Lost task 21.1 in stage 135.0 (TID 8830, 128.110.152.142): ExecutorLostFailure (executor 37 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:07:33 WARN TaskSetManager: Lost task 36.0 in stage 135.0 (TID 8801, 128.110.152.142): ExecutorLostFailure (executor 37 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 22.436808705 seconds
res137: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=47 AND partitionZIndex<=50", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=47 AND partitionZIndex<=50,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048952633 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 136:=====================================>                (45 + 19) / 64][Stage 136:====================================================>  (61 + 3) / 64][Stage 136:=====================================================> (62 + 2) / 64][Stage 136:======================================================>(63 + 1) / 64]                                                                                [Stage 137:====================================================>  (62 + 3) / 65][Stage 137:=====================================================> (63 + 2) / 65][Stage 137:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 18.432343451 seconds
res139: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=16 AND partitionZIndex<=19", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=16 AND partitionZIndex<=19,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048844572 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 138:======================================================>(63 + 1) / 64]                                                                                [Stage 139:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 12.452077911 seconds
res141: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=78 AND partitionZIndex<=81", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=78 AND partitionZIndex<=81,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050414018 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 140:====================================================>  (61 + 3) / 64][Stage 140:=====================================================> (62 + 2) / 64][Stage 140:======================================================>(63 + 1) / 64]                                                                                [Stage 141:====================================================>  (62 + 3) / 65][Stage 141:=====================================================> (63 + 2) / 65][Stage 141:======================================================>(64 + 1) / 65]17/06/10 07:08:37 ERROR TaskSchedulerImpl: Lost executor 42 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:08:37 WARN TaskSetManager: Lost task 20.0 in stage 141.0 (TID 9175, 128.110.152.141): ExecutorLostFailure (executor 42 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 27.033606554 seconds
res143: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=251 AND partitionZIndex<=254", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=251 AND partitionZIndex<=254,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052726385 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 142:================================================>      (56 + 8) / 64][Stage 142:======================================================>(63 + 1) / 64]                                                                                Time elapsed: 5.666252734 seconds
res145: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=210 AND partitionZIndex<=213", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=210 AND partitionZIndex<=213,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045806941 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 144:====================================================>  (61 + 3) / 64][Stage 144:=====================================================> (62 + 2) / 64]17/06/10 07:09:02 ERROR TaskSchedulerImpl: Lost executor 31 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:09:02 WARN TaskSetManager: Lost task 37.0 in stage 144.0 (TID 9387, 128.110.152.168): ExecutorLostFailure (executor 31 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:09:03 ERROR TaskSchedulerImpl: Lost executor 45 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:09:03 WARN TaskSetManager: Lost task 24.0 in stage 144.0 (TID 9374, 128.110.152.141): ExecutorLostFailure (executor 45 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 144:======================================================>(63 + 1) / 64]                                                                                [Stage 145:======================================>               (46 + 19) / 65][Stage 145:=======================================>              (47 + 18) / 65][Stage 145:=====================================================> (63 + 2) / 65][Stage 145:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 22.960209379 seconds
res147: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=107 AND partitionZIndex<=110", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=107 AND partitionZIndex<=110,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050076275 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 146:=====================================================> (62 + 2) / 64][Stage 146:======================================================>(63 + 1) / 64]                                                                                17/06/10 07:09:28 ERROR TaskSchedulerImpl: Lost executor 19 on 128.110.152.160: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:09:28 WARN TaskSetManager: Lost task 11.0 in stage 147.0 (TID 9556, 128.110.152.160): ExecutorLostFailure (executor 19 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:09:28 WARN TaskSetManager: Lost task 64.0 in stage 147.0 (TID 9609, 128.110.152.160): ExecutorLostFailure (executor 19 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 147:=====================================================> (63 + 2) / 65][Stage 147:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 16.471355201 seconds
res149: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=165 AND partitionZIndex<=168", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=165 AND partitionZIndex<=168,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.067196914 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 148:============================================>         (53 + 11) / 64][Stage 148:====================================================>  (61 + 3) / 64][Stage 148:=====================================================> (62 + 2) / 64][Stage 148:======================================================>(63 + 1) / 64]                                                                                [Stage 149:====================================================>  (62 + 3) / 65][Stage 149:=====================================================> (63 + 2) / 65][Stage 149:======================================================>(64 + 1) / 65]17/06/10 07:09:57 ERROR TaskSchedulerImpl: Lost executor 47 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:09:57 WARN TaskSetManager: Lost task 20.0 in stage 149.0 (TID 9696, 128.110.152.141): ExecutorLostFailure (executor 47 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:09:57 ERROR TaskSchedulerImpl: Lost executor 43 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:09:57 WARN TaskSetManager: Lost task 20.1 in stage 149.0 (TID 9741, 128.110.152.145): ExecutorLostFailure (executor 43 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 26.863624614 seconds
res151: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=37 AND partitionZIndex<=40", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=37 AND partitionZIndex<=40,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050243334 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 150:======================================>               (46 + 18) / 64][Stage 150:=============================================>        (54 + 10) / 64][Stage 150:=====================================================> (62 + 2) / 64][Stage 150:======================================================>(63 + 1) / 64]                                                                                [Stage 151:=====================================================> (63 + 2) / 65][Stage 151:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.842077042 seconds
res153: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=195 AND partitionZIndex<=198", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=195 AND partitionZIndex<=198,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052708662 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 152:====================================================>  (61 + 3) / 64][Stage 152:=====================================================> (62 + 2) / 64][Stage 152:======================================================>(63 + 1) / 64]                                                                                [Stage 153:====================================================>  (62 + 3) / 65][Stage 153:=====================================================> (63 + 2) / 65]                                                                                Time elapsed: 14.560526042 seconds
res155: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=204 AND partitionZIndex<=207", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=204 AND partitionZIndex<=207,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04917621 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.681924397 seconds
res157: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=218 AND partitionZIndex<=221", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=218 AND partitionZIndex<=221,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048669149 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 156:=====================================================> (62 + 2) / 64][Stage 156:======================================================>(63 + 1) / 64]                                                                                [Stage 157:=====================================================> (63 + 2) / 65][Stage 157:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 17.379146672 seconds
res159: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=15 AND partitionZIndex<=18", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=15 AND partitionZIndex<=18,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057976799 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 158:=====================================================> (62 + 2) / 64][Stage 158:======================================================>(63 + 1) / 64]                                                                                [Stage 159:=====================================================> (63 + 2) / 65][Stage 159:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 11.967795787 seconds
res161: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=116 AND partitionZIndex<=119", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=116 AND partitionZIndex<=119,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050538614 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 160:=====================================================> (62 + 2) / 64][Stage 160:======================================================>(63 + 1) / 64]                                                                                [Stage 161:=====================================================> (63 + 2) / 65]17/06/10 07:11:27 ERROR TaskSchedulerImpl: Lost executor 49 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:11:27 WARN TaskSetManager: Lost task 11.0 in stage 161.0 (TID 10463, 128.110.152.141): ExecutorLostFailure (executor 49 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 161:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 17.410363296 seconds
res163: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=86 AND partitionZIndex<=89", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=86 AND partitionZIndex<=89,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054333706 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 162:=============================================>        (54 + 10) / 64][Stage 162:===============================================>       (55 + 9) / 64][Stage 162:=====================================================> (62 + 2) / 64][Stage 162:======================================================>(63 + 1) / 64]                                                                                [Stage 163:====================================================>  (62 + 3) / 65][Stage 163:=====================================================> (63 + 2) / 65][Stage 163:======================================================>(64 + 1) / 65]17/06/10 07:12:00 ERROR TaskSchedulerImpl: Lost executor 30 on 128.110.152.152: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:12:00 WARN TaskSetManager: Lost task 11.0 in stage 163.0 (TID 10593, 128.110.152.152): ExecutorLostFailure (executor 30 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 28.861755894 seconds
res165: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=252 AND partitionZIndex<=255", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=252 AND partitionZIndex<=255,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05284792 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 164:================================================>      (56 + 8) / 64][Stage 164:======================================================>(63 + 1) / 64]                                                                                [Stage 165:======================================================>(64 + 1) / 65]17/06/10 07:12:28 ERROR TaskSchedulerImpl: Lost executor 50 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:12:28 WARN TaskSetManager: Lost task 50.0 in stage 165.0 (TID 10762, 128.110.152.145): ExecutorLostFailure (executor 50 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 25.032839238 seconds
res167: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=207 AND partitionZIndex<=210", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=207 AND partitionZIndex<=210,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047230961 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 166:================================================>      (56 + 8) / 64]                                                                                Time elapsed: 5.700923045 seconds
res169: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=126 AND partitionZIndex<=129", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=126 AND partitionZIndex<=129,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047612702 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 168:====================================================>  (61 + 3) / 64][Stage 168:======================================================>(63 + 1) / 64]                                                                                17/06/10 07:12:51 ERROR TaskSchedulerImpl: Lost executor 51 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:12:51 WARN TaskSetManager: Lost task 24.0 in stage 169.0 (TID 10995, 128.110.152.141): ExecutorLostFailure (executor 51 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 169:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.237704161 seconds
res171: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=156 AND partitionZIndex<=159", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=156 AND partitionZIndex<=159,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049092246 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 170:===============================================>       (55 + 9) / 64][Stage 170:=====================================================> (62 + 2) / 64][Stage 170:======================================================>(63 + 1) / 64]                                                                                [Stage 171:=====================================================> (63 + 2) / 65][Stage 171:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 22.137088906 seconds
res173: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=120 AND partitionZIndex<=123", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=120 AND partitionZIndex<=123,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.078905307 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 172:======================================================>(63 + 1) / 64]                                                                                [Stage 173:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 14.762179598 seconds
res175: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=183 AND partitionZIndex<=186", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=183 AND partitionZIndex<=186,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051116673 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.700467085 seconds
res177: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=87 AND partitionZIndex<=90", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=87 AND partitionZIndex<=90,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045527953 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 176:>                                                       (0 + 0) / 64]                                                                                Time elapsed: 0.899476336 seconds
res179: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=85 AND partitionZIndex<=88", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=85 AND partitionZIndex<=88,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.064123217 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 07:13:49 ERROR TaskSchedulerImpl: Lost executor 54 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:13:49 WARN TaskSetManager: Lost task 20.0 in stage 178.0 (TID 11573, 128.110.152.141): ExecutorLostFailure (executor 54 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 178:====================================================>  (61 + 3) / 64][Stage 178:=====================================================> (62 + 2) / 64]17/06/10 07:13:57 ERROR TaskSchedulerImpl: Lost executor 44 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:13:57 WARN TaskSetManager: Lost task 8.0 in stage 178.0 (TID 11561, 128.110.152.142): ExecutorLostFailure (executor 44 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:13:57 WARN TaskSetManager: Lost task 0.0 in stage 178.0 (TID 11553, 128.110.152.142): ExecutorLostFailure (executor 44 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 178:======================================================>(63 + 1) / 64]                                                                                [Stage 179:======================================>               (46 + 19) / 65][Stage 179:============================================>         (54 + 11) / 65][Stage 179:====================================================>  (62 + 3) / 65][Stage 179:=====================================================> (63 + 2) / 65][Stage 179:======================================================>(64 + 1) / 65]17/06/10 07:14:14 ERROR TaskSchedulerImpl: Lost executor 36 on 128.110.152.165: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:14:14 WARN TaskSetManager: Lost task 20.0 in stage 179.0 (TID 11640, 128.110.152.165): ExecutorLostFailure (executor 36 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 34.220134303 seconds
res181: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=250 AND partitionZIndex<=253", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=250 AND partitionZIndex<=253,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051519373 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 180:===============================================>       (55 + 9) / 64][Stage 180:======================================================>(63 + 1) / 64]                                                                                [Stage 181:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 11.443460795 seconds
res183: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=230 AND partitionZIndex<=233", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=230 AND partitionZIndex<=233,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051457693 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 182:=====================================================> (62 + 2) / 64][Stage 182:======================================================>(63 + 1) / 64]                                                                                [Stage 183:=====================================================> (63 + 2) / 65]17/06/10 07:14:53 ERROR TaskSchedulerImpl: Lost executor 46 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:14:53 WARN TaskSetManager: Lost task 50.0 in stage 183.0 (TID 11929, 128.110.152.168): ExecutorLostFailure (executor 46 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 183:======================================================>(64 + 1) / 65]17/06/10 07:15:00 ERROR TaskSchedulerImpl: Lost executor 53 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:15:00 WARN TaskSetManager: Lost task 50.1 in stage 183.0 (TID 11944, 128.110.152.145): ExecutorLostFailure (executor 53 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 29.541191168 seconds
res185: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=29 AND partitionZIndex<=32", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=29 AND partitionZIndex<=32,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045665618 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 184:=======================================>              (47 + 17) / 64][Stage 184:===============================================>       (55 + 9) / 64][Stage 184:=====================================================> (62 + 2) / 64][Stage 184:======================================================>(63 + 1) / 64]                                                                                [Stage 185:=====================================================> (63 + 2) / 65][Stage 185:======================================================>(64 + 1) / 65]17/06/10 07:15:27 ERROR TaskSchedulerImpl: Lost executor 55 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:15:27 WARN TaskSetManager: Lost task 21.0 in stage 185.0 (TID 12031, 128.110.152.141): ExecutorLostFailure (executor 55 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 28.359936644 seconds
res187: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=142 AND partitionZIndex<=145", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=142 AND partitionZIndex<=145,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047604609 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 186:=============================================>        (54 + 10) / 64][Stage 186:=====================================================> (62 + 2) / 64]17/06/10 07:15:46 ERROR TaskSchedulerImpl: Lost executor 34 on 128.110.152.157: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:15:46 WARN TaskSetManager: Lost task 37.0 in stage 186.0 (TID 12113, 128.110.152.157): ExecutorLostFailure (executor 34 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 186:======================================================>(63 + 1) / 64]                                                                                [Stage 187:=============================================>        (55 + 10) / 65][Stage 187:=====================================================> (63 + 2) / 65][Stage 187:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 19.534108436 seconds
res189: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=61 AND partitionZIndex<=64", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=61 AND partitionZIndex<=64,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045404815 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 188:====================================================>  (61 + 3) / 64][Stage 188:=====================================================> (62 + 2) / 64][Stage 188:======================================================>(63 + 1) / 64]                                                                                [Stage 189:====================================================>  (62 + 3) / 65][Stage 189:=====================================================> (63 + 2) / 65][Stage 189:======================================================>(64 + 1) / 65]17/06/10 07:16:28 ERROR TaskSchedulerImpl: Lost executor 60 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:16:28 WARN TaskSetManager: Lost task 23.0 in stage 189.0 (TID 12293, 128.110.152.141): ExecutorLostFailure (executor 60 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 35.859247556 seconds
res191: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=31 AND partitionZIndex<=34", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=31 AND partitionZIndex<=34,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048408092 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 190:===============================================>       (55 + 9) / 64][Stage 190:=====================================================> (62 + 2) / 64][Stage 190:======================================================>(63 + 1) / 64]                                                                                [Stage 191:=====================================================> (63 + 2) / 65][Stage 191:======================================================>(64 + 1) / 65]17/06/10 07:17:01 ERROR TaskSchedulerImpl: Lost executor 62 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:17:01 WARN TaskSetManager: Lost task 20.0 in stage 191.0 (TID 12420, 128.110.152.141): ExecutorLostFailure (executor 62 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 29.826954933 seconds
res193: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=163 AND partitionZIndex<=166", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=163 AND partitionZIndex<=166,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046780342 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 192:=============================================>        (54 + 10) / 64][Stage 192:====================================================>  (61 + 3) / 64][Stage 192:======================================================>(63 + 1) / 64]                                                                                [Stage 193:=======================================>              (47 + 18) / 65][Stage 193:=========================================>            (50 + 15) / 65][Stage 193:============================================>         (54 + 11) / 65][Stage 193:=============================================>        (55 + 10) / 65][Stage 193:===============================================>       (56 + 9) / 65][Stage 193:================================================>      (57 + 8) / 65][Stage 193:================================================>      (57 + 8) / 65][Stage 193:================================================>      (57 + 8) / 65][Stage 193:================================================>      (57 + 8) / 65]17/06/10 07:21:23 ERROR TaskSchedulerImpl: Lost executor 59 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:21:23 WARN TaskSetManager: Lost task 51.0 in stage 193.0 (TID 12581, 128.110.152.145): ExecutorLostFailure (executor 59 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:21:23 WARN TaskSetManager: Lost task 27.0 in stage 193.0 (TID 12557, 128.110.152.145): ExecutorLostFailure (executor 59 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:21:23 WARN TaskSetManager: Lost task 3.0 in stage 193.0 (TID 12533, 128.110.152.145): ExecutorLostFailure (executor 59 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:21:23 WARN TaskSetManager: Lost task 11.0 in stage 193.0 (TID 12541, 128.110.152.145): ExecutorLostFailure (executor 59 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:21:23 WARN TaskSetManager: Lost task 59.0 in stage 193.0 (TID 12589, 128.110.152.145): ExecutorLostFailure (executor 59 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:21:23 WARN TaskSetManager: Lost task 35.0 in stage 193.0 (TID 12565, 128.110.152.145): ExecutorLostFailure (executor 59 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:21:23 WARN TaskSetManager: Lost task 43.0 in stage 193.0 (TID 12573, 128.110.152.145): ExecutorLostFailure (executor 59 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:21:23 WARN TaskSetManager: Lost task 19.0 in stage 193.0 (TID 12549, 128.110.152.145): ExecutorLostFailure (executor 59 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:21:23 ERROR TransportResponseHandler: Still have 1 requests outstanding when connection from /128.110.152.145:44676 is closed
17/06/10 07:21:23 WARN BlockManagerMaster: Failed to remove broadcast 289 with removeFromMaster = true - Connection from /128.110.152.145:44676 closed
java.io.IOException: Connection from /128.110.152.145:44676 closed
	at org.apache.spark.network.client.TransportResponseHandler.channelInactive(TransportResponseHandler.java:128)
	at org.apache.spark.network.server.TransportChannelHandler.channelInactive(TransportChannelHandler.java:109)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at io.netty.handler.timeout.IdleStateHandler.channelInactive(IdleStateHandler.java:257)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at org.apache.spark.network.util.TransportFrameDecoder.channelInactive(TransportFrameDecoder.java:182)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.DefaultChannelPipeline.fireChannelInactive(DefaultChannelPipeline.java:828)
	at io.netty.channel.AbstractChannel$AbstractUnsafe$7.run(AbstractChannel.java:621)
	at io.netty.util.concurrent.SingleThreadEventExecutor.runAllTasks(SingleThreadEventExecutor.java:357)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:357)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 07:21:23 ERROR ContextCleaner: Error cleaning broadcast 289
org.apache.spark.SparkException: Exception thrown in awaitResult
	at org.apache.spark.rpc.RpcTimeout$$anonfun$1.applyOrElse(RpcTimeout.scala:77)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$1.applyOrElse(RpcTimeout.scala:75)
	at scala.runtime.AbstractPartialFunction.apply(AbstractPartialFunction.scala:36)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$addMessageIfTimeout$1.applyOrElse(RpcTimeout.scala:59)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$addMessageIfTimeout$1.applyOrElse(RpcTimeout.scala:59)
	at scala.PartialFunction$OrElse.apply(PartialFunction.scala:167)
	at org.apache.spark.rpc.RpcTimeout.awaitResult(RpcTimeout.scala:83)
	at org.apache.spark.storage.BlockManagerMaster.removeBroadcast(BlockManagerMaster.scala:143)
	at org.apache.spark.broadcast.TorrentBroadcast$.unpersist(TorrentBroadcast.scala:267)
	at org.apache.spark.broadcast.TorrentBroadcastFactory.unbroadcast(TorrentBroadcastFactory.scala:45)
	at org.apache.spark.broadcast.BroadcastManager.unbroadcast(BroadcastManager.scala:60)
	at org.apache.spark.ContextCleaner.doCleanupBroadcast(ContextCleaner.scala:232)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1$$anonfun$apply$mcV$sp$2.apply(ContextCleaner.scala:188)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1$$anonfun$apply$mcV$sp$2.apply(ContextCleaner.scala:179)
	at scala.Option.foreach(Option.scala:257)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1.apply$mcV$sp(ContextCleaner.scala:179)
	at org.apache.spark.util.Utils$.tryOrStopSparkContext(Utils.scala:1252)
	at org.apache.spark.ContextCleaner.org$apache$spark$ContextCleaner$$keepCleaning(ContextCleaner.scala:172)
	at org.apache.spark.ContextCleaner$$anon$1.run(ContextCleaner.scala:67)
Caused by: java.io.IOException: Connection from /128.110.152.145:44676 closed
	at org.apache.spark.network.client.TransportResponseHandler.channelInactive(TransportResponseHandler.java:128)
	at org.apache.spark.network.server.TransportChannelHandler.channelInactive(TransportChannelHandler.java:109)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at io.netty.handler.timeout.IdleStateHandler.channelInactive(IdleStateHandler.java:257)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at org.apache.spark.network.util.TransportFrameDecoder.channelInactive(TransportFrameDecoder.java:182)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.DefaultChannelPipeline.fireChannelInactive(DefaultChannelPipeline.java:828)
	at io.netty.channel.AbstractChannel$AbstractUnsafe$7.run(AbstractChannel.java:621)
	at io.netty.util.concurrent.SingleThreadEventExecutor.runAllTasks(SingleThreadEventExecutor.java:357)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:357)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
[Stage 193:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 259.149686017 seconds
res195: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=217 AND partitionZIndex<=220", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=217 AND partitionZIndex<=220,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.065515802 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 194:================================================>      (56 + 8) / 64]                                                                                Time elapsed: 5.787226557 seconds
res197: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=182 AND partitionZIndex<=185", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=182 AND partitionZIndex<=185,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.044510539 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 196:===============================================>       (55 + 9) / 64][Stage 196:====================================================>  (61 + 3) / 64]17/06/10 07:21:47 ERROR TaskSchedulerImpl: Lost executor 63 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:21:47 WARN TaskSetManager: Lost task 50.0 in stage 196.0 (TID 12782, 128.110.152.141): ExecutorLostFailure (executor 63 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 196:=====================================================> (62 + 2) / 64][Stage 196:======================================================>(63 + 1) / 64]                                                                                [Stage 197:============================================>         (54 + 11) / 65][Stage 197:====================================================>  (62 + 3) / 65][Stage 197:=====================================================> (63 + 2) / 65][Stage 197:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 20.49460075 seconds
res199: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=36 AND partitionZIndex<=39", 4))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=36 AND partitionZIndex<=39,4))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054486816 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 198:=====================================================> (62 + 2) / 64]17/06/10 07:22:10 ERROR TaskSchedulerImpl: Lost executor 52 on 128.110.152.152: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:22:10 WARN TaskSetManager: Lost task 0.0 in stage 198.0 (TID 12862, 128.110.152.152): ExecutorLostFailure (executor 52 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:22:12 ERROR TaskSchedulerImpl: Lost executor 65 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 07:22:12 WARN TaskSetManager: Lost task 11.0 in stage 198.0 (TID 12873, 128.110.152.141): ExecutorLostFailure (executor 65 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 198:======================================================>(63 + 1) / 64]                                                                                [Stage 199:=======================================>              (47 + 18) / 65][Stage 199:============================================>         (53 + 12) / 65][Stage 199:=============================================>        (55 + 10) / 65][Stage 199:=====================================================> (63 + 2) / 65][Stage 199:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 24.769247347 seconds
res201: Int = 0

scala> 

scala> :quit
