Using Spark's default log4j profile: org/apache/spark/log4j-defaults.properties
Setting default log level to "WARN".
To adjust logging level use sc.setLogLevel(newLevel).
17/06/10 01:58:01 WARN NativeCodeLoader: Unable to load native-hadoop library for your platform... using builtin-java classes where applicable
17/06/10 01:58:04 WARN SparkContext: Use an existing SparkContext, some configuration may not take effect.
Spark context Web UI available at http://128.110.152.156:4040
Spark context available as 'sc' (master = spark://ctl:7077, app id = app-20170610015804-0056).
Spark session available as 'spark'.
Welcome to
      ____              __
     / __/__  ___ _____/ /__
    _\ \/ _ \/ _ `/ __/  '_/
   /___/ .__/\_,_/_/ /_/\_\   version 2.0.2
      /_/
         
Using Scala version 2.11.8 (OpenJDK 64-Bit Server VM, Java 1.8.0_131)
Type in expressions to have them evaluated.
Type :help for more information.

scala>  
     | import java.io.File
import java.io.File

scala> import java.io.FileOutputStream
import java.io.FileOutputStream

scala> import org.apache.spark.sql._
import org.apache.spark.sql._

scala> 

scala> def show_timing[T](proc: => T): T = {
     |     val start=System.nanoTime()
     |     val res = proc
     |     val end = System.nanoTime()
     |     println("Time elapsed: " + (end-start)/1000000000.0 + " seconds")
     |     res
     | }
show_timing: [T](proc: => T)T

scala> 

scala> val writeToLocal = (in:(Array[Byte], Long, String)) =>{
     |     val bytes = in._1
     |     val output = in._3
     |     
     |     val writer = new FileOutputStream(output)
     |     writer.write(bytes)
     |     writer.close
     |     1
     |   }
writeToLocal: ((Array[Byte], Long, String)) => Int = <function1>

scala> 

scala> val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)
warning: there was one deprecation warning; re-run with -deprecation for details
sqlContext: org.apache.spark.sql.hive.HiveContext = org.apache.spark.sql.hive.HiveContext@984de01

scala>   
     |  
     | import java.io.File
import java.io.File

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
<console>:35: error: not found: value dataSource
       show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
                                                         ^

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
<console>:37: error: not found: value queries
       show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, index) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
                                  ^

scala> 

scala> import org.apache.spark.sql._
import org.apache.spark.sql._

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
<console>:38: error: not found: value dataSource
       show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
                                                         ^

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
<console>:40: error: not found: value queries
       show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, index) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
                                  ^

scala> 

scala>     val start=System.nanoTime()
start: Long = 1399813083288409

scala>     val res = proc
<console>:32: error: not found: value proc
           val res = proc
                     ^

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
<console>:38: error: not found: value dataSource
       show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
                                                         ^

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
<console>:40: error: not found: value queries
       show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, index) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
                                  ^

scala> 

scala>     println("Time elapsed: " + (end-start)/1000000000.0 + " seconds")
<console>:35: error: not found: value end
           println("Time elapsed: " + (end-start)/1000000000.0 + " seconds")
                                       ^

scala>     res
<console>:33: error: not found: value res
           res
           ^

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
<console>:38: error: not found: value dataSource
       show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
                                                         ^

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
<console>:40: error: not found: value queries
       show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, index) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
                                  ^

scala> 

scala> 

scala> val writeToLocal = (in:(Array[Byte], Long, String)) =>{
     | 
     | 
You typed two blank lines.  Starting a new command.

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
<console>:38: error: not found: value dataSource
       show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
                                                         ^

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
<console>:40: error: not found: value queries
       show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, index) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
                                  ^

scala> 

scala>     val output = in._3
<console>:32: error: not found: value in
           val output = in._3
                        ^

scala>     
     | 
     | 
You typed two blank lines.  Starting a new command.

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
<console>:38: error: not found: value dataSource
       show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
                                                         ^

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
<console>:40: error: not found: value queries
       show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, index) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
                                  ^

scala> 

scala>     writer.write(bytes)
<console>:33: error: not found: value writer
           writer.write(bytes)
           ^
<console>:33: error: not found: value bytes
           writer.write(bytes)
                        ^

scala>     writer.close
<console>:33: error: not found: value writer
           writer.close
           ^

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
<console>:38: error: not found: value dataSource
       show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
                                                         ^

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
<console>:40: error: not found: value queries
       show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, index) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
                                  ^

scala> 

scala>   }
<console>:1: error: eof expected but '}' found.
  }
  ^

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
<console>:38: error: not found: value dataSource
       show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
                                                         ^

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
<console>:40: error: not found: value queries
       show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, index) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
                                  ^

scala> 

scala>   
     | val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 18.183918088 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
<console>:40: error: not found: value queries
       show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, index) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
                                  ^

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.14625091 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
<console>:40: error: not found: value queries
       show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, index) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
                                  ^

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
<console>:40: error: not found: value queries
       show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, index) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
                                  ^

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.133164847 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
<console>:40: error: not found: value queries
       show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, index) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
                                  ^

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 73 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 73 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.120478205 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 0:>                                                      (0 + 104) / 105][Stage 0:============================>                          (54 + 51) / 105][Stage 0:======================================================>(104 + 1) / 105]                                                                                [Stage 1:======================================================>(105 + 1) / 106]                                                                                Time elapsed: 23.763945328 seconds
res35: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.10978708 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 2:=====================================>                 (72 + 33) / 105][Stage 2:======================================================>(104 + 1) / 105]                                                                                [Stage 3:======================================================>(105 + 1) / 106]                                                                                Time elapsed: 17.662602483 seconds
res37: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.13636143 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 4:======================================================>(104 + 1) / 105]                                                                                [Stage 5:======================================================>(105 + 1) / 106]                                                                                Time elapsed: 16.06099201 seconds
res39: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 148 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 148 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.112769893 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 1.20807165 seconds
res41: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.092029691 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.085237319 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 1.230841161 seconds
res44: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.147516644 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 1.238889438 seconds
res46: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.096997776 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 1.197222533 seconds
res48: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.840857504 seconds
res49: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.104795574 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 1.131033047 seconds
res51: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 141 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 141 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.135710525 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 1.426017672 seconds
res53: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.116664592 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.767235022 seconds
res55: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.090795205 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 1.096076213 seconds
res57: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 131 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 131 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.076723596 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 24:=====================================================>(104 + 1) / 105]                                                                                [Stage 25:=====================================================>(105 + 1) / 106]                                                                                Time elapsed: 20.020031387 seconds
res59: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.077225758 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.071599691 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 26:=====================================================>(104 + 1) / 105]                                                                                [Stage 27:=====================================================>(105 + 1) / 106]                                                                                Time elapsed: 18.959278209 seconds
res62: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.086301602 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 28:=====================================================>(103 + 1) / 104]                                                                                [Stage 29:=====================================================>(104 + 1) / 105]                                                                                Time elapsed: 14.98453363 seconds
res64: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.084833335 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 02:01:27 ERROR TaskSchedulerImpl: Lost executor 10 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:01:27 WARN TaskSetManager: Lost task 103.0 in stage 30.0 (TID 3244, 128.110.152.145): ExecutorLostFailure (executor 10 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:01:27 WARN TaskSetManager: Lost task 12.0 in stage 30.0 (TID 3153, 128.110.152.145): ExecutorLostFailure (executor 10 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:01:27 WARN TaskSetManager: Lost task 38.0 in stage 30.0 (TID 3179, 128.110.152.145): ExecutorLostFailure (executor 10 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 30:=====================================================>(103 + 1) / 104]                                                                                [Stage 31:==================================================>    (96 + 9) / 105][Stage 31:=====================================================>(104 + 1) / 105]                                                                                Time elapsed: 15.212694403 seconds
res66: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 32:=====================================================>(103 + 1) / 104]                                                                                [Stage 33:=====================================================>(104 + 1) / 105]                                                                                Time elapsed: 15.06222803 seconds
res67: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.061832281 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 34:=====================================================>(103 + 1) / 104]                                                                                [Stage 35:=====================================================>(104 + 1) / 105]                                                                                Time elapsed: 15.608705233 seconds
res69: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 93 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 93 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.066880386 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 36:=====================================================>(103 + 1) / 104]                                                                                [Stage 37:=====================================================>(104 + 1) / 105]                                                                                Time elapsed: 14.507179502 seconds
res71: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.059728051 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 38:=====================================================>(103 + 1) / 104]                                                                                [Stage 39:=====================================================>(104 + 1) / 105]                                                                                Time elapsed: 14.975756167 seconds
res73: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.0656197 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 40:=====================================================>(103 + 1) / 104]                                                                                [Stage 41:=====================================================>(104 + 1) / 105]                                                                                Time elapsed: 14.844324489 seconds
res75: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 8 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 8 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058669506 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 42:====================================================> (103 + 2) / 105][Stage 42:=====================================================>(104 + 1) / 105]                                                                                [Stage 43:====================================================> (104 + 2) / 106][Stage 43:=====================================================>(105 + 1) / 106]                                                                                Time elapsed: 12.848839812 seconds
res77: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.072785814 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.060718395 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 44:====================================================> (103 + 2) / 105][Stage 44:=====================================================>(104 + 1) / 105]                                                                                [Stage 45:====================================================> (104 + 2) / 106][Stage 45:=====================================================>(105 + 1) / 106]                                                                                Time elapsed: 11.53370192 seconds
res80: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.064304772 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 46:=====================================================>(103 + 1) / 104]                                                                                [Stage 47:=====================================================>(104 + 1) / 105]                                                                                Time elapsed: 8.106553952 seconds
res82: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.120617345 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 48:=====================================================>(103 + 1) / 104]                                                                                [Stage 49:=====================================================>(104 + 1) / 105]                                                                                Time elapsed: 7.214267105 seconds
res84: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 50:=====================================================>(103 + 1) / 104]                                                                                [Stage 51:=====================================================>(104 + 1) / 105]                                                                                Time elapsed: 7.680427012 seconds
res85: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.059102826 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 52:=====================================================>(103 + 1) / 104]                                                                                [Stage 53:=====================================================>(104 + 1) / 105]                                                                                Time elapsed: 8.258234416 seconds
res87: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 58 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 58 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.063562168 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 54:=====================================================>(103 + 1) / 104]17/06/10 02:04:18 ERROR TaskSchedulerImpl: Lost executor 2 on 128.110.152.146: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:04:18 WARN TaskSetManager: Lost task 78.0 in stage 54.0 (TID 5734, 128.110.152.146): ExecutorLostFailure (executor 2 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 55:==================================================>    (96 + 9) / 105][Stage 55:==================================================>    (97 + 8) / 105]                                                                                Time elapsed: 16.253048301 seconds
res89: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058980065 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 56:=====================================================>(103 + 1) / 104]                                                                                [Stage 57:=====================================================>(104 + 1) / 105]                                                                                Time elapsed: 10.621780582 seconds
res91: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.061766079 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 58:=====================================================>(103 + 1) / 104]                                                                                [Stage 59:=====================================================>(104 + 1) / 105]                                                                                Time elapsed: 10.302005546 seconds
res93: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 116 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 116 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.080314489 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.877558684 seconds
res95: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.081067792 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049173178 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.571985466 seconds
res98: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052859096 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.48593163 seconds
res100: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.059267807 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.541517078 seconds
res102: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.648301055 seconds
res103: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.071067024 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.491899878 seconds
res105: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 234 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 234 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052474594 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.605802448 seconds
res107: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052857715 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.443311702 seconds
res109: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.068500631 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.637519001 seconds
res111: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 155 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 155 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.069399975 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.596858444 seconds
res113: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051485169 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047357069 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.512276515 seconds
res116: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048612935 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 82:=====================================================>(104 + 1) / 105]                                                                                [Stage 83:=====================================================>(105 + 1) / 106]17/06/10 02:05:27 ERROR TaskSchedulerImpl: Lost executor 13 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:05:27 WARN TaskSetManager: Lost task 60.0 in stage 83.0 (TID 8738, 128.110.152.145): ExecutorLostFailure (executor 13 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 15.021090981 seconds
res118: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.063999169 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 84:==================================================>    (96 + 9) / 105][Stage 84:=====================================================>(104 + 1) / 105]                                                                                [Stage 85:=====================================================>(105 + 1) / 106]                                                                                Time elapsed: 13.979834801 seconds
res120: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 86:=====================================================>(104 + 1) / 105]                                                                                [Stage 87:=====================================================>(105 + 1) / 106]                                                                                Time elapsed: 13.577398154 seconds
res121: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055396987 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 88:=====================================================>(104 + 1) / 105]                                                                                [Stage 89:=====================================================>(105 + 1) / 106]                                                                                Time elapsed: 13.16264231 seconds
res123: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 233 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 233 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.091004479 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 90:=====================================================>(104 + 1) / 105]                                                                                [Stage 91:=====================================================>(105 + 1) / 106]                                                                                Time elapsed: 11.094565727 seconds
res125: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054994485 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 92:>                                                       (0 + 0) / 105][Stage 92:=====================================================>(104 + 1) / 105]                                                                                [Stage 93:=====================================================>(105 + 1) / 106]                                                                                Time elapsed: 11.495821108 seconds
res127: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054240841 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 94:=====================================================>(104 + 1) / 105]                                                                                [Stage 95:=====================================================>(105 + 1) / 106]                                                                                Time elapsed: 11.403253989 seconds
res129: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 221 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 221 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.093934512 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 96:>                                                       (0 + 0) / 103]                                                                                Time elapsed: 0.581469316 seconds
res131: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053807379 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.064798012 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.557994983 seconds
res134: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056653012 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 100:====================================================>(104 + 1) / 105]                                                                                [Stage 101:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 11.422126392 seconds
res136: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054636642 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 102:====================================================>(104 + 1) / 105]                                                                                [Stage 103:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 11.702330765 seconds
res138: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 104:====================================================>(104 + 1) / 105]                                                                                [Stage 105:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 11.204465743 seconds
res139: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.062940862 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 106:====================================================>(104 + 1) / 105]                                                                                [Stage 107:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 11.217992476 seconds
res141: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 17 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 17 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.062729821 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 108:====================================================>(104 + 1) / 105]17/06/10 02:08:04 ERROR TaskSchedulerImpl: Lost executor 9 on 128.110.152.176: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:08:04 WARN TaskSetManager: Lost task 0.0 in stage 108.0 (TID 11309, 128.110.152.176): ExecutorLostFailure (executor 9 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 109:=================================================>    (98 + 8) / 106][Stage 109:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 27.149608318 seconds
res143: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052661512 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 110:====================================================>(104 + 1) / 105]                                                                                [Stage 111:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 14.263802912 seconds
res145: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053653117 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 112:====================================================>(104 + 1) / 105]                                                                                [Stage 113:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 14.403516231 seconds
res147: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 237 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 237 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05230579 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.691280706 seconds
res149: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047606207 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047060885 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.487463331 seconds
res152: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051627787 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 118:====================================================>(103 + 1) / 104]                                                                                [Stage 119:====================================================>(104 + 1) / 105]17/06/10 02:09:38 ERROR TaskSchedulerImpl: Lost executor 7 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:09:38 WARN TaskSetManager: Lost task 81.0 in stage 119.0 (TID 12550, 128.110.152.141): ExecutorLostFailure (executor 7 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 42.999619454 seconds
res154: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.064768849 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 120:>                                                      (0 + 0) / 104][Stage 120:=================================================>    (95 + 9) / 104][Stage 120:==================================================>  (100 + 4) / 104]                                                                                [Stage 121:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.21285131 seconds
res156: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 122:====================================================>(103 + 1) / 104]                                                                                [Stage 123:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 12.024494791 seconds
res157: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051653186 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 124:====================================================>(103 + 1) / 104]                                                                                [Stage 125:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 10.945830198 seconds
res159: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 223 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 223 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050676421 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 126:====================================================>(103 + 1) / 104]                                                                                [Stage 127:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.775644598 seconds
res161: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054126397 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 128:====================================================>(103 + 1) / 104]                                                                                [Stage 129:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.240984022 seconds
res163: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.160367603 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 130:====================================================>(103 + 1) / 104]                                                                                [Stage 131:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.168120125 seconds
res165: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 163 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 163 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048178589 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.592144795 seconds
res167: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04838823 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047009924 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.486648794 seconds
res170: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04820793 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 136:====================================================>(103 + 1) / 104]                                                                                [Stage 137:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 16.820190357 seconds
res172: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049480255 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 02:11:25 ERROR TaskSchedulerImpl: Lost executor 14 on 128.110.152.146: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:11:25 WARN TaskSetManager: Lost task 62.0 in stage 138.0 (TID 14522, 128.110.152.146): ExecutorLostFailure (executor 14 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 138:====================================================>(103 + 1) / 104]                                                                                [Stage 139:=================================================>    (96 + 9) / 105][Stage 139:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 16.479849377 seconds
res174: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 140:====================================================>(103 + 1) / 104]                                                                                [Stage 141:====================================================>(104 + 1) / 105]17/06/10 02:12:00 ERROR TaskSchedulerImpl: Lost executor 11 on 128.110.152.163: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:12:00 WARN TaskSetManager: Lost task 62.0 in stage 141.0 (TID 14836, 128.110.152.163): ExecutorLostFailure (executor 11 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 26.247788759 seconds
res175: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.066942297 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 142:=================================================>    (95 + 9) / 104][Stage 142:====================================================>(103 + 1) / 104]                                                                                [Stage 143:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 16.779525422 seconds
res177: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 230 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 230 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048226149 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 144:====================================================>(103 + 1) / 104]                                                                                [Stage 145:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 12.370838526 seconds
res179: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058231736 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 146:====================================================>(103 + 1) / 104]                                                                                [Stage 147:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.146698438 seconds
res181: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052155766 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 148:====================================================>(103 + 1) / 104]                                                                                [Stage 149:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 12.159140619 seconds
res183: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 142 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 142 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049966977 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.644477748 seconds
res185: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046851701 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042506181 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.586335672 seconds
res188: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045393094 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.497932494 seconds
res190: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047962607 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.670461749 seconds
res192: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.499419901 seconds
res193: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049280173 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.464899858 seconds
res195: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 226 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 226 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.044231569 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.559707265 seconds
res197: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045391315 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.474249201 seconds
res199: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.0507634 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.489370833 seconds
res201: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.044594771 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 168:====================================================>(104 + 1) / 105]                                                                                [Stage 169:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 14.793194556 seconds
res203: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049205172 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049650575 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 170:====================================================>(104 + 1) / 105]                                                                                [Stage 171:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 16.202616858 seconds
res206: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05731427 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 172:====================================================>(104 + 1) / 105]                                                                                [Stage 173:====================================================>(105 + 1) / 106]17/06/10 02:14:10 ERROR TaskSchedulerImpl: Lost executor 8 on 128.110.152.152: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:14:10 WARN TaskSetManager: Lost task 13.0 in stage 173.0 (TID 18127, 128.110.152.152): ExecutorLostFailure (executor 8 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 15.901981821 seconds
res208: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047010322 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 02:14:18 ERROR TaskSchedulerImpl: Lost executor 12 on 128.110.152.155: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:14:18 WARN TaskSetManager: Lost task 13.0 in stage 174.0 (TID 18234, 128.110.152.155): ExecutorLostFailure (executor 12 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 174:=================================================>    (96 + 9) / 105][Stage 174:====================================================>(104 + 1) / 105]                                                                                [Stage 175:=================================================>    (97 + 9) / 106][Stage 175:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 15.299249407 seconds
res210: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 176:====================================================>(104 + 1) / 105]                                                                                [Stage 177:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 15.028563462 seconds
res211: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045971796 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 178:====================================================>(104 + 1) / 105]                                                                                [Stage 179:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 15.43176571 seconds
res213: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 19 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 19 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052086065 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 180:====================================================>(104 + 1) / 105]                                                                                17/06/10 02:15:26 ERROR TaskSchedulerImpl: Lost executor 17 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:15:26 WARN TaskSetManager: Lost task 0.0 in stage 181.0 (TID 18960, 128.110.152.141): ExecutorLostFailure (executor 17 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:15:26 WARN TaskSetManager: Lost task 26.0 in stage 181.0 (TID 18986, 128.110.152.141): ExecutorLostFailure (executor 17 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:15:26 WARN TaskSetManager: Lost task 13.0 in stage 181.0 (TID 18973, 128.110.152.141): ExecutorLostFailure (executor 17 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 181:===========================================>         (86 + 20) / 106][Stage 181:===========================================>         (87 + 19) / 106][Stage 181:============================================>        (88 + 18) / 106][Stage 181:============================================>        (89 + 17) / 106][Stage 181:=============================================>       (90 + 16) / 106][Stage 181:=============================================>       (91 + 15) / 106][Stage 181:==============================================>      (92 + 14) / 106][Stage 181:=================================================>    (97 + 9) / 106][Stage 181:=================================================>    (98 + 8) / 106][Stage 181:=================================================>    (98 + 8) / 106][Stage 181:=================================================>    (98 + 8) / 106][Stage 181:=================================================>    (98 + 8) / 106][Stage 181:=================================================>    (98 + 8) / 106][Stage 181:=================================================>    (98 + 8) / 106]17/06/10 02:21:39 ERROR TaskSchedulerImpl: Lost executor 0 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:21:39 WARN TaskSetManager: Lost task 18.0 in stage 181.0 (TID 18978, 128.110.152.142): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:21:39 WARN TaskSetManager: Lost task 83.0 in stage 181.0 (TID 19043, 128.110.152.142): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:21:39 WARN TaskSetManager: Lost task 5.0 in stage 181.0 (TID 18965, 128.110.152.142): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:21:39 WARN TaskSetManager: Lost task 44.0 in stage 181.0 (TID 19004, 128.110.152.142): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:21:39 WARN TaskSetManager: Lost task 70.0 in stage 181.0 (TID 19030, 128.110.152.142): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:21:39 WARN TaskSetManager: Lost task 31.0 in stage 181.0 (TID 18991, 128.110.152.142): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:21:39 WARN TaskSetManager: Lost task 57.0 in stage 181.0 (TID 19017, 128.110.152.142): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:21:39 WARN TaskSetManager: Lost task 96.0 in stage 181.0 (TID 19056, 128.110.152.142): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 181:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 395.874340745 seconds
res215: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050745135 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 182:>                                                      (0 + 0) / 105][Stage 182:=================================================>    (96 + 9) / 105][Stage 182:====================================================>(104 + 1) / 105]                                                                                [Stage 183:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 10.924865941 seconds
res217: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.161529267 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 184:====================================================>(104 + 1) / 105]                                                                                [Stage 185:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 11.870869592 seconds
res219: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 216 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 216 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045852492 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 186:>                                                      (0 + 0) / 105]                                                                                Time elapsed: 0.679328641 seconds
res221: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046456675 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042624997 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.514312618 seconds
res224: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.043780582 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 190:====================================================>(104 + 1) / 105]                                                                                [Stage 191:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 14.699322204 seconds
res226: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051274657 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 192:====================================================>(104 + 1) / 105]                                                                                [Stage 193:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 14.483349743 seconds
res228: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 194:====================================================>(104 + 1) / 105]                                                                                [Stage 195:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 13.919185841 seconds
res229: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.06720197 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 196:====================================================>(104 + 1) / 105]17/06/10 02:23:10 ERROR TaskSchedulerImpl: Lost executor 15 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:23:10 WARN TaskSetManager: Lost task 78.0 in stage 196.0 (TID 20632, 128.110.152.145): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 197:=================================================>    (97 + 9) / 106][Stage 197:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 22.266043318 seconds
res231: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 151 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 151 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051616598 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 198:====================================================>(104 + 1) / 105]                                                                                [Stage 199:====================================================>(105 + 1) / 106]17/06/10 02:23:44 ERROR TaskSchedulerImpl: Lost executor 21 on 128.110.152.155: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:23:44 WARN TaskSetManager: Lost task 32.0 in stage 199.0 (TID 20903, 128.110.152.155): ExecutorLostFailure (executor 21 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 27.67504446 seconds
res233: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051688958 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 200:=================================================>    (97 + 8) / 105][Stage 200:====================================================>(104 + 1) / 105]                                                                                [Stage 201:====================================================>(105 + 1) / 106]17/06/10 02:24:21 ERROR TaskSchedulerImpl: Lost executor 22 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:24:21 WARN TaskSetManager: Lost task 32.0 in stage 201.0 (TID 21115, 128.110.152.141): ExecutorLostFailure (executor 22 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 33.742620653 seconds
res235: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046221753 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 202:=================================================>    (96 + 9) / 105][Stage 202:====================================================>(104 + 1) / 105]17/06/10 02:24:38 ERROR TaskSchedulerImpl: Lost executor 5 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:24:38 WARN TaskSetManager: Lost task 32.0 in stage 202.0 (TID 21222, 128.110.152.168): ExecutorLostFailure (executor 5 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 203:=================================================>    (97 + 9) / 106][Stage 203:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 25.637206286 seconds
res237: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 161 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 161 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052448621 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 204:====================================================>(103 + 1) / 104]17/06/10 02:25:06 ERROR TaskSchedulerImpl: Lost executor 18 on 128.110.152.146: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:25:06 WARN TaskSetManager: Lost task 62.0 in stage 204.0 (TID 21464, 128.110.152.146): ExecutorLostFailure (executor 18 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 205:=================================================>    (96 + 9) / 105][Stage 205:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 24.435797088 seconds
res239: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.08482651 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055200374 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 206:====================================================>(103 + 1) / 104]                                                                                [Stage 207:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 15.323205379 seconds
res242: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047181577 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 208:====================================================>(104 + 1) / 105]                                                                                [Stage 209:====================================================>(105 + 1) / 106]17/06/10 02:25:49 ERROR TaskSchedulerImpl: Lost executor 24 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:25:49 WARN TaskSetManager: Lost task 60.0 in stage 209.0 (TID 21986, 128.110.152.145): ExecutorLostFailure (executor 24 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 13.641489664 seconds
res244: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.070096862 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 210:=================================================>    (96 + 9) / 105][Stage 210:==================================================>  (100 + 5) / 105][Stage 210:====================================================>(104 + 1) / 105]                                                                                [Stage 211:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 12.956271249 seconds
res246: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 212:====================================================>(104 + 1) / 105]                                                                                [Stage 213:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 12.837723735 seconds
res247: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047628058 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 214:====================================================>(104 + 1) / 105]                                                                                [Stage 215:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 11.676201768 seconds
res249: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 38 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 38 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055170613 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 216:====================================================>(104 + 1) / 105]17/06/10 02:26:44 ERROR TaskSchedulerImpl: Lost executor 16 on 128.110.152.176: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:26:44 WARN TaskSetManager: Lost task 0.0 in stage 216.0 (TID 22666, 128.110.152.176): ExecutorLostFailure (executor 16 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 217:=================================================>    (97 + 9) / 106][Stage 217:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 20.991524559 seconds
res251: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047221596 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 218:====================================================>(104 + 1) / 105]                                                                                [Stage 219:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 14.239515516 seconds
res253: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052095699 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 220:>                                                      (0 + 0) / 105][Stage 220:====================================================>(104 + 1) / 105]                                                                                [Stage 221:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 14.103559457 seconds
res255: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 241 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 241 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051374795 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 222:====================================================>(103 + 1) / 104]                                                                                [Stage 223:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.472984887 seconds
res257: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.044457323 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045485408 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 224:====================================================>(103 + 1) / 104]                                                                                [Stage 225:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 10.644432519 seconds
res260: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045229486 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 226:====================================================>(103 + 1) / 104]                                                                                [Stage 227:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.255515126 seconds
res262: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.069853559 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 228:====================================================>(103 + 1) / 104]                                                                                [Stage 229:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.111750628 seconds
res264: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 230:====================================================>(103 + 1) / 104]                                                                                [Stage 231:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.036871464 seconds
res265: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.059549552 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 232:====================================================>(103 + 1) / 104]                                                                                [Stage 233:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 10.805289887 seconds
res267: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 114 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 114 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045555108 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 234:====================================================>(103 + 1) / 104]                                                                                [Stage 235:====================================================>(104 + 1) / 105]17/06/10 02:29:00 ERROR TaskSchedulerImpl: Lost executor 26 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:29:00 WARN TaskSetManager: Lost task 38.0 in stage 235.0 (TID 24696, 128.110.152.141): ExecutorLostFailure (executor 26 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 20.81139551 seconds
res269: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047577037 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 236:=================================================>    (95 + 9) / 104][Stage 236:====================================================>(103 + 1) / 104]                                                                                [Stage 237:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 15.148373569 seconds
res271: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045298206 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 238:====================================================>(103 + 1) / 104]                                                                                [Stage 239:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 14.860888582 seconds
res273: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 208 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 208 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046656772 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 240:====================================================>(103 + 1) / 104]                                                                                [Stage 241:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.021429369 seconds
res275: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051160393 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.041341588 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 242:====================================================>(103 + 1) / 104]                                                                                [Stage 243:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 10.612287388 seconds
res278: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.044885704 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.494349406 seconds
res280: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048175259 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.48194601 seconds
res282: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.505879858 seconds
res283: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.041036806 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.484542741 seconds
res285: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 6 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 6 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045816928 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 252:====================================================>(102 + 1) / 103]                                                                                [Stage 253:====================================================>(103 + 1) / 104]                                                                                Time elapsed: 8.122667831 seconds
res287: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048841961 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 254:====================================================>(102 + 1) / 103]17/06/10 02:30:28 ERROR TaskSchedulerImpl: Lost executor 4 on 128.110.152.144: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:30:28 WARN TaskSetManager: Lost task 0.0 in stage 254.0 (TID 26635, 128.110.152.144): ExecutorLostFailure (executor 4 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 255:====================================================>(103 + 1) / 104]                                                                                Time elapsed: 12.451150967 seconds
res289: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046166589 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 256:=================================================>    (94 + 9) / 103][Stage 256:=================================================>    (95 + 8) / 103]                                                                                [Stage 257:====================================================>(103 + 1) / 104]                                                                                Time elapsed: 9.469847694 seconds
res291: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 144 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 144 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.044776204 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.796236392 seconds
res293: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.041524388 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.040553923 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.544701711 seconds
res296: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.044992744 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 262:====================================================>(104 + 1) / 105]                                                                                [Stage 263:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 17.877752931 seconds
res298: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.062043561 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 264:====================================================>(104 + 1) / 105]                                                                                [Stage 265:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 18.334085524 seconds
res300: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 266:====================================================>(104 + 1) / 105]                                                                                [Stage 267:====================================================>(105 + 1) / 106]17/06/10 02:31:50 ERROR TaskSchedulerImpl: Lost executor 28 on 128.110.152.146: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:31:50 WARN TaskSetManager: Lost task 32.0 in stage 267.0 (TID 28023, 128.110.152.146): ExecutorLostFailure (executor 28 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 27.987207964 seconds
res301: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051468992 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 268:=================================================>    (96 + 9) / 105][Stage 268:====================================================>(104 + 1) / 105]                                                                                [Stage 269:====================================================>(105 + 1) / 106]17/06/10 02:32:20 ERROR TaskSchedulerImpl: Lost executor 31 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:32:20 WARN TaskSetManager: Lost task 32.0 in stage 269.0 (TID 28235, 128.110.152.141): ExecutorLostFailure (executor 31 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 27.906930913 seconds
res303: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 90 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 90 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049599024 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 270:=================================================>    (97 + 8) / 105][Stage 270:====================================================>(104 + 1) / 105]                                                                                [Stage 271:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 20.539977406 seconds
res305: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.059283328 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 02:32:52 ERROR TaskSchedulerImpl: Lost executor 34 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:32:52 WARN TaskSetManager: Lost task 26.0 in stage 272.0 (TID 28547, 128.110.152.141): ExecutorLostFailure (executor 34 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:32:52 WARN TaskSetManager: Lost task 13.0 in stage 272.0 (TID 28534, 128.110.152.141): ExecutorLostFailure (executor 34 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:32:52 WARN TaskSetManager: Lost task 0.0 in stage 272.0 (TID 28521, 128.110.152.141): ExecutorLostFailure (executor 34 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 272:====================================================>(104 + 1) / 105]                                                                                [Stage 273:=================================================>    (97 + 9) / 106][Stage 273:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 14.636951127 seconds
res307: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050682769 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 274:====================================================>(104 + 1) / 105]                                                                                [Stage 275:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 14.286942491 seconds
res309: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 20 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 20 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045397305 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 276:====================================================>(104 + 1) / 105]                                                                                [Stage 277:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 11.047030222 seconds
res311: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.043073535 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.039254575 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 278:====================================================>(104 + 1) / 105]                                                                                [Stage 279:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 11.47029959 seconds
res314: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057155336 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 280:====================================================>(104 + 1) / 105]                                                                                [Stage 281:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 10.822486162 seconds
res316: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051639035 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 282:====================================================>(104 + 1) / 105]17/06/10 02:34:14 ERROR TaskSchedulerImpl: Lost executor 1 on 128.110.152.165: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:34:14 WARN TaskSetManager: Lost task 19.0 in stage 282.0 (TID 29598, 128.110.152.165): ExecutorLostFailure (executor 1 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 283:=================================================>    (97 + 9) / 106][Stage 283:====================================================>(105 + 1) / 106]17/06/10 02:34:27 ERROR TaskSchedulerImpl: Lost executor 19 on 128.110.152.163: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:34:27 WARN TaskSetManager: Lost task 19.0 in stage 283.0 (TID 29704, 128.110.152.163): ExecutorLostFailure (executor 19 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 32.257705205 seconds
res318: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 284:=================================================>    (96 + 9) / 105][Stage 284:====================================================>(104 + 1) / 105]                                                                                [Stage 285:====================================================>(105 + 1) / 106]17/06/10 02:34:42 ERROR TaskSchedulerImpl: Lost executor 29 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:34:42 WARN TaskSetManager: Lost task 19.0 in stage 285.0 (TID 29916, 128.110.152.145): ExecutorLostFailure (executor 29 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 12.590058355 seconds
res319: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.043084443 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 286:=================================================>    (96 + 9) / 105][Stage 286:====================================================>(104 + 1) / 105]17/06/10 02:34:55 ERROR TaskSchedulerImpl: Lost executor 35 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 02:34:55 WARN TaskSetManager: Lost task 19.0 in stage 286.0 (TID 30023, 128.110.152.141): ExecutorLostFailure (executor 35 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 287:=================================================>    (97 + 9) / 106][Stage 287:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 18.707688877 seconds
res321: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 104 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 104 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042744581 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.792623298 seconds
res323: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04220062 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 291:=================================================>    (97 + 9) / 106][Stage 291:=================================================>    (98 + 8) / 106][Stage 291:=================================================>    (98 + 8) / 106][Stage 291:=================================================>    (98 + 8) / 106][Stage 291:=================================================>    (98 + 8) / 106][Stage 291:=================================================>    (98 + 8) / 106][Stage 291:=================================================>    (98 + 8) / 106][Stage 291:=================================================>    (98 + 8) / 106][Stage 291:=================================================>    (98 + 8) / 106][Stage 291:=================================================>    (98 + 8) / 106][Stage 291:==================================================>   (99 + 7) / 106][Stage 291:==================================================>   (99 + 7) / 106][Stage 291:==================================================>   (99 + 7) / 106][Stage 291:==================================================>  (100 + 6) / 106][Stage 291:==================================================>  (101 + 5) / 106][Stage 291:===================================================> (102 + 4) / 106][Stage 291:===================================================> (103 + 3) / 106][Stage 291:===================================================> (103 + 3) / 106][Stage 291:====================================================>(105 + 1) / 106][Stage 291:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 904.722607241 seconds
res325: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042825282 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 292:===============================================>     (94 + 11) / 105][Stage 292:===============================================>     (95 + 10) / 105][Stage 292:=================================================>    (96 + 9) / 105][Stage 292:=================================================>    (97 + 8) / 105][Stage 292:=================================================>    (97 + 8) / 105][Stage 292:=================================================>    (97 + 8) / 105][Stage 292:=================================================>    (97 + 8) / 105][Stage 292:=================================================>    (97 + 8) / 105][Stage 292:=================================================>    (97 + 8) / 105][Stage 292:=================================================>    (97 + 8) / 105][Stage 292:=================================================>    (97 + 8) / 105][Stage 292:=================================================>    (97 + 8) / 105][Stage 292:=================================================>    (97 + 8) / 105][Stage 292:=================================================>    (97 + 8) / 105]17/06/10 03:01:16 ERROR TaskSchedulerImpl: Lost executor 20 on 128.110.152.152: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:01:16 WARN TaskSetManager: Lost task 57.0 in stage 292.0 (TID 30695, 128.110.152.152): ExecutorLostFailure (executor 20 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:01:16 WARN TaskSetManager: Lost task 96.0 in stage 292.0 (TID 30734, 128.110.152.152): ExecutorLostFailure (executor 20 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:01:16 WARN TaskSetManager: Lost task 18.0 in stage 292.0 (TID 30656, 128.110.152.152): ExecutorLostFailure (executor 20 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:01:16 WARN TaskSetManager: Lost task 44.0 in stage 292.0 (TID 30682, 128.110.152.152): ExecutorLostFailure (executor 20 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:01:16 WARN TaskSetManager: Lost task 83.0 in stage 292.0 (TID 30721, 128.110.152.152): ExecutorLostFailure (executor 20 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:01:16 WARN TaskSetManager: Lost task 5.0 in stage 292.0 (TID 30643, 128.110.152.152): ExecutorLostFailure (executor 20 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:01:16 WARN TaskSetManager: Lost task 70.0 in stage 292.0 (TID 30708, 128.110.152.152): ExecutorLostFailure (executor 20 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:01:16 WARN TaskSetManager: Lost task 31.0 in stage 292.0 (TID 30669, 128.110.152.152): ExecutorLostFailure (executor 20 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 659.091940075 seconds
res327: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 253 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 253 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.060718341 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 294:======================================================>(94 + 1) / 95]                                                                                [Stage 295:==================================================>    (89 + 7) / 96][Stage 295:======================================================>(95 + 1) / 96]                                                                                Time elapsed: 16.701794302 seconds
res329: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049812087 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.041952836 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 296:====================================================>(103 + 1) / 104]                                                                                [Stage 297:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.482524643 seconds
res332: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048732326 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 298:====================================================>(103 + 1) / 104]                                                                                [Stage 299:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 12.005266903 seconds
res334: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.0442761 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 03:02:03 ERROR TaskSchedulerImpl: Lost executor 30 on 128.110.152.176: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:02:03 WARN TaskSetManager: Lost task 78.0 in stage 300.0 (TID 31544, 128.110.152.176): ExecutorLostFailure (executor 30 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 300:====================================================>(103 + 1) / 104]                                                                                [Stage 301:=================================================>    (96 + 9) / 105][Stage 301:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 12.879349773 seconds
res336: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 302:====================================================>(103 + 1) / 104]                                                                                [Stage 303:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.098970168 seconds
res337: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049525069 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 304:====================================================>(103 + 1) / 104]                                                                                [Stage 305:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 12.469519605 seconds
res339: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 189 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 189 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.107287668 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 306:====================================================>(103 + 1) / 104]                                                                                [Stage 307:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 17.618443906 seconds
res341: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05705214 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 308:====================================================>(103 + 1) / 104]17/06/10 03:03:11 ERROR TaskSchedulerImpl: Lost executor 39 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:03:11 WARN TaskSetManager: Lost task 56.0 in stage 308.0 (TID 32359, 128.110.152.141): ExecutorLostFailure (executor 39 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 309:=================================================>    (96 + 9) / 105][Stage 309:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 25.053739072 seconds
res343: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04239374 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 310:====================================================>(103 + 1) / 104]                                                                                [Stage 311:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 17.039432669 seconds
res345: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 225 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 225 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056225 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.815016879 seconds
res347: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04198208 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.059929485 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 315:=================================================>    (98 + 8) / 106]                                                                                Time elapsed: 1.838338438 seconds
res350: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.110477497 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 316:====================================================>(103 + 1) / 104]                                                                                [Stage 317:====================================================>(104 + 1) / 105]17/06/10 03:04:02 ERROR TaskSchedulerImpl: Lost executor 25 on 128.110.152.155: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:04:02 WARN TaskSetManager: Lost task 78.0 in stage 317.0 (TID 33326, 128.110.152.155): ExecutorLostFailure (executor 25 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 14.580033889 seconds
res352: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042518521 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 318:=================================================>    (95 + 9) / 104][Stage 318:====================================================>(103 + 1) / 104]                                                                                [Stage 319:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 12.706065179 seconds
res354: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 320:====================================================>(103 + 1) / 104]                                                                                [Stage 321:====================================================>(104 + 1) / 105]17/06/10 03:04:36 ERROR TaskSchedulerImpl: Lost executor 6 on 128.110.152.157: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:04:36 WARN TaskSetManager: Lost task 78.0 in stage 321.0 (TID 33745, 128.110.152.157): ExecutorLostFailure (executor 6 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 19.299544391 seconds
res355: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042986122 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 322:>                                                      (0 + 0) / 104][Stage 322:=================================================>    (95 + 9) / 104][Stage 322:====================================================>(103 + 1) / 104]17/06/10 03:04:50 ERROR TaskSchedulerImpl: Lost executor 38 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:04:50 WARN TaskSetManager: Lost task 78.0 in stage 322.0 (TID 33851, 128.110.152.145): ExecutorLostFailure (executor 38 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 323:=================================================>    (96 + 9) / 105][Stage 323:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 18.832813834 seconds
res357: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 18 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 18 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053324559 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 324:====================================================>(103 + 1) / 104]                                                                                [Stage 325:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.780479633 seconds
res359: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042727523 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 326:====================================================>(103 + 1) / 104]                                                                                [Stage 327:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.270543226 seconds
res361: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.043878705 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 328:====================================================>(103 + 1) / 104]                                                                                [Stage 329:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 10.801058667 seconds
res363: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 185 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 185 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051270677 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.632957322 seconds
res365: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052683279 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.043648685 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.486197545 seconds
res368: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.043150365 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 334:====================================================>(104 + 1) / 105]                                                                                [Stage 335:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 12.001871608 seconds
res370: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049656354 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 336:====================================================>(104 + 1) / 105]                                                                                [Stage 337:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 13.21916779 seconds
res372: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 338:====================================================>(104 + 1) / 105]                                                                                [Stage 339:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 13.046512432 seconds
res373: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042103284 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 340:====================================================>(104 + 1) / 105]                                                                                [Stage 341:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 13.426036333 seconds
res375: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 222 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 222 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042461705 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 342:>                                                      (0 + 0) / 105][Stage 342:====================================================>(104 + 1) / 105]                                                                                [Stage 343:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 11.030635385 seconds
res377: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042963506 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 344:====================================================>(104 + 1) / 105]                                                                                [Stage 345:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 11.836544216 seconds
res379: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047499453 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 346:====================================================>(104 + 1) / 105]                                                                                [Stage 347:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 11.536972139 seconds
res381: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 53 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 53 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.041770465 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 348:====================================================>(104 + 1) / 105]                                                                                [Stage 349:====================================================>(105 + 1) / 106]17/06/10 03:07:30 ERROR TaskSchedulerImpl: Lost executor 45 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:07:30 WARN TaskSetManager: Lost task 18.0 in stage 349.0 (TID 36632, 128.110.152.145): ExecutorLostFailure (executor 45 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:07:39 ERROR TaskSchedulerImpl: Lost executor 23 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:07:39 WARN TaskSetManager: Lost task 18.1 in stage 349.0 (TID 36720, 128.110.152.142): ExecutorLostFailure (executor 23 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 24.567615351 seconds
res383: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047033953 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05115604 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 350:============================================>        (88 + 17) / 105][Stage 350:====================================================>(104 + 1) / 105]17/06/10 03:07:57 ERROR TaskSchedulerImpl: Lost executor 43 on 128.110.152.155: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:07:57 WARN TaskSetManager: Lost task 18.0 in stage 350.0 (TID 36740, 128.110.152.155): ExecutorLostFailure (executor 43 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 351:=================================================>    (97 + 9) / 106][Stage 351:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 24.896278662 seconds
res386: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042282087 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 03:08:15 ERROR TaskSchedulerImpl: Lost executor 3 on 128.110.152.160: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:08:15 WARN TaskSetManager: Lost task 85.0 in stage 352.0 (TID 37019, 128.110.152.160): ExecutorLostFailure (executor 3 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 352:====================================================>(104 + 1) / 105]                                                                                [Stage 353:=================================================>    (97 + 9) / 106][Stage 353:=================================================>    (98 + 8) / 106]                                                                                Time elapsed: 10.335736462 seconds
res388: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04414063 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 354:====================================================>(104 + 1) / 105]                                                                                [Stage 355:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 8.629750465 seconds
res390: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 356:====================================================>(104 + 1) / 105]                                                                                [Stage 357:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 9.21592102 seconds
res391: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046700894 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 358:====================================================>(104 + 1) / 105]                                                                                [Stage 359:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 9.331971438 seconds
res393: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 195 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 195 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.041743027 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.62649992 seconds
res395: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.037990401 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.491488425 seconds
res397: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.040755165 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.524777638 seconds
res399: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 248 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 248 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042829648 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 366:====================================================>(104 + 1) / 105]                                                                                [Stage 367:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 11.274857862 seconds
res401: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04978982 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04985116 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 368:====================================================>(104 + 1) / 105]                                                                                [Stage 369:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 10.988855 seconds
res404: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045067313 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 03:09:29 ERROR TaskSchedulerImpl: Lost executor 33 on 128.110.152.146: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:09:29 WARN TaskSetManager: Lost task 78.0 in stage 370.0 (TID 38912, 128.110.152.146): ExecutorLostFailure (executor 33 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 370:====================================================>(103 + 1) / 104]                                                                                [Stage 371:=================================================>    (96 + 9) / 105][Stage 371:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 12.277820919 seconds
res406: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047574777 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 372:====================================================>(103 + 1) / 104]                                                                                [Stage 373:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 12.516696456 seconds
res408: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 374:====================================================>(103 + 1) / 104]                                                                                [Stage 375:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 12.477322162 seconds
res409: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045756715 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 376:====================================================>(103 + 1) / 104]                                                                                [Stage 377:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 12.750169599 seconds
res411: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 97 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 97 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.043004591 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 378:====================================================>(103 + 1) / 104]                                                                                [Stage 379:====================================================>(104 + 1) / 105]17/06/10 03:10:41 ERROR TaskSchedulerImpl: Lost executor 27 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:10:41 WARN TaskSetManager: Lost task 14.0 in stage 379.0 (TID 39789, 128.110.152.168): ExecutorLostFailure (executor 27 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 25.569976575 seconds
res413: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046270477 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 380:=================================================>    (95 + 9) / 104][Stage 380:====================================================>(103 + 1) / 104]                                                                                [Stage 381:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 15.370650715 seconds
res415: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047341958 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 382:====================================================>(103 + 1) / 104]17/06/10 03:11:16 ERROR TaskSchedulerImpl: Lost executor 41 on 128.110.152.176: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:11:16 WARN TaskSetManager: Lost task 14.0 in stage 382.0 (TID 40104, 128.110.152.176): ExecutorLostFailure (executor 41 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 383:=================================================>    (96 + 9) / 105][Stage 383:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 24.1788013 seconds
res417: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 140 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 140 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04177175 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 384:====================================================>(103 + 1) / 104]                                                                                [Stage 385:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 18.043187546 seconds
res419: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042974513 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.040812769 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 386:====================================================>(103 + 1) / 104]                                                                                [Stage 387:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 17.411248756 seconds
res422: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.044890296 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 388:====================================================>(103 + 1) / 104]                                                                                [Stage 389:====================================================>(104 + 1) / 105]17/06/10 03:12:30 ERROR TaskSchedulerImpl: Lost executor 42 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:12:30 WARN TaskSetManager: Lost task 40.0 in stage 389.0 (TID 40862, 128.110.152.141): ExecutorLostFailure (executor 42 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 27.389854207 seconds
res424: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042691053 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 390:=================================================>    (95 + 9) / 104][Stage 390:====================================================>(103 + 1) / 104]                                                                                [Stage 391:====================================================>(104 + 1) / 105]17/06/10 03:12:57 ERROR TaskSchedulerImpl: Lost executor 50 on 128.110.152.146: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:12:57 WARN TaskSetManager: Lost task 40.0 in stage 391.0 (TID 41072, 128.110.152.146): ExecutorLostFailure (executor 50 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 25.712795531 seconds
res426: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 392:=================================================>    (95 + 9) / 104][Stage 392:====================================================>(103 + 1) / 104]                                                                                [Stage 393:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 15.877852835 seconds
res427: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046086199 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 394:====================================================>(103 + 1) / 104]                                                                                [Stage 395:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 16.328119036 seconds
res429: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 199 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 199 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.062147149 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 396:====================================================>(103 + 1) / 104]                                                                                [Stage 397:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 15.89707905 seconds
res431: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042194234 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 398:====================================================>(103 + 1) / 104]                                                                                [Stage 399:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 17.388979954 seconds
res433: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.041919694 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 400:====================================================>(103 + 1) / 104]                                                                                17/06/10 03:14:26 ERROR TaskSchedulerImpl: Lost executor 48 on 128.110.152.155: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:14:26 WARN TaskSetManager: Lost task 62.0 in stage 401.0 (TID 42140, 128.110.152.155): ExecutorLostFailure (executor 48 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 401:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 16.150589044 seconds
res435: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 82 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 82 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050298689 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 402:=================================================>    (97 + 8) / 105]                                                                                Time elapsed: 5.688945404 seconds
res437: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.03972683 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.037067006 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.608042799 seconds
res440: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.038747708 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 406:====================================================>(104 + 1) / 105]                                                                                [Stage 407:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 15.039763242 seconds
res442: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049214348 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 408:====================================================>(104 + 1) / 105]                                                                                [Stage 409:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 14.714378642 seconds
res444: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 410:====================================================>(104 + 1) / 105]                                                                                [Stage 411:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 15.016327297 seconds
res445: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.043114437 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 412:====================================================>(104 + 1) / 105]                                                                                [Stage 413:============================================>        (88 + 18) / 106][Stage 413:============================================>        (89 + 17) / 106][Stage 413:=============================================>       (90 + 16) / 106][Stage 413:=============================================>       (91 + 15) / 106][Stage 413:==============================================>      (92 + 14) / 106][Stage 413:==============================================>      (93 + 13) / 106][Stage 413:===============================================>     (94 + 12) / 106][Stage 413:===============================================>     (95 + 11) / 106][Stage 413:================================================>    (96 + 10) / 106]17/06/10 03:16:08 WARN TransportChannelHandler: Exception in connection from /128.110.152.145:45978
java.io.IOException: Connection reset by peer
	at sun.nio.ch.FileDispatcherImpl.read0(Native Method)
	at sun.nio.ch.SocketDispatcher.read(SocketDispatcher.java:39)
	at sun.nio.ch.IOUtil.readIntoNativeBuffer(IOUtil.java:223)
	at sun.nio.ch.IOUtil.read(IOUtil.java:192)
	at sun.nio.ch.SocketChannelImpl.read(SocketChannelImpl.java:380)
	at io.netty.buffer.PooledUnsafeDirectByteBuf.setBytes(PooledUnsafeDirectByteBuf.java:313)
	at io.netty.buffer.AbstractByteBuf.writeBytes(AbstractByteBuf.java:881)
	at io.netty.channel.socket.nio.NioSocketChannel.doReadBytes(NioSocketChannel.java:242)
	at io.netty.channel.nio.AbstractNioByteChannel$NioByteUnsafe.read(AbstractNioByteChannel.java:119)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:511)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 03:16:08 ERROR TaskSchedulerImpl: Lost executor 46 on 128.110.152.145: Command exited with code 137
17/06/10 03:16:08 WARN TaskSetManager: Lost task 91.0 in stage 413.0 (TID 43435, 128.110.152.145): ExecutorLostFailure (executor 46 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 03:16:08 WARN TaskSetManager: Lost task 13.0 in stage 413.0 (TID 43357, 128.110.152.145): ExecutorLostFailure (executor 46 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 03:16:08 WARN TaskSetManager: Lost task 52.0 in stage 413.0 (TID 43396, 128.110.152.145): ExecutorLostFailure (executor 46 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 03:16:08 WARN TaskSetManager: Lost task 78.0 in stage 413.0 (TID 43422, 128.110.152.145): ExecutorLostFailure (executor 46 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 03:16:08 WARN TaskSetManager: Lost task 39.0 in stage 413.0 (TID 43383, 128.110.152.145): ExecutorLostFailure (executor 46 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 03:16:08 WARN TaskSetManager: Lost task 0.0 in stage 413.0 (TID 43344, 128.110.152.145): ExecutorLostFailure (executor 46 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 03:16:08 WARN TaskSetManager: Lost task 26.0 in stage 413.0 (TID 43370, 128.110.152.145): ExecutorLostFailure (executor 46 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 03:16:08 WARN TaskSetManager: Lost task 65.0 in stage 413.0 (TID 43409, 128.110.152.145): ExecutorLostFailure (executor 46 exited caused by one of the running tasks) Reason: Command exited with code 137
[Stage 413:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 34.688534013 seconds
res447: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 251 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 251 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.044918422 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 414:======================================================>(95 + 1) / 96]                                                                                [Stage 415:=================================================>     (88 + 9) / 97][Stage 415:======================================================>(96 + 1) / 97]                                                                                Time elapsed: 11.304533974 seconds
res449: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.041416355 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 416:====================================================>(104 + 1) / 105]                                                                                [Stage 417:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 11.625145148 seconds
res451: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.041248156 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 418:====================================================>(104 + 1) / 105]                                                                                [Stage 419:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 11.168586241 seconds
res453: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 162 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 162 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042706778 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 420:====================================================>(104 + 1) / 105]                                                                                [Stage 421:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 13.055815749 seconds
res455: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057045345 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.041397796 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 422:====================================================>(104 + 1) / 105]                                                                                [Stage 423:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 13.010207636 seconds
res458: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.044947863 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.503410651 seconds
res460: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.038872692 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.502117629 seconds
res462: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.436016247 seconds
res463: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.038796012 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.450286973 seconds
res465: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 85 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 85 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.043507481 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 432:>                                                      (0 + 0) / 104]                                                                                Time elapsed: 0.530530903 seconds
res467: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.037558849 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.422307383 seconds
res469: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.03784821 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.659914184 seconds
res471: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 164 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 164 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.043569421 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 438:====================================================>(104 + 1) / 105]                                                                                [Stage 439:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 17.328228948 seconds
res473: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047868589 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.039203413 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 440:====================================================>(104 + 1) / 105]                                                                                [Stage 441:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 17.887987832 seconds
res476: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.043289081 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.466111194 seconds
res478: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042198439 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.414059316 seconds
res480: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.44827066 seconds
res481: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.038420992 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.425684078 seconds
res483: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 123 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 123 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.039707934 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.50635339 seconds
res485: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.03755663 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.421260811 seconds
res487: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045494886 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.477737597 seconds
res489: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 100 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 100 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.039712534 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 456:====================================================>(104 + 1) / 105]                                                                                17/06/10 03:18:29 ERROR TaskSchedulerImpl: Lost executor 53 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:18:29 WARN TaskSetManager: Lost task 13.0 in stage 457.0 (TID 47947, 128.110.152.141): ExecutorLostFailure (executor 53 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 457:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 16.122681906 seconds
res491: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050904516 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.039014713 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 458:=================================================>    (96 + 9) / 105][Stage 458:====================================================>(104 + 1) / 105]                                                                                [Stage 459:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 14.797478269 seconds
res494: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04230362 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 460:====================================================>(103 + 1) / 104]                                                                                [Stage 461:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 13.714363481 seconds
res496: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042575921 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 462:====================================================>(103 + 1) / 104]                                                                                [Stage 463:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 15.271120067 seconds
res498: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 464:====================================================>(103 + 1) / 104]                                                                                [Stage 465:====================================================>(104 + 1) / 105]17/06/10 03:19:42 ERROR TaskSchedulerImpl: Lost executor 57 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:19:42 WARN TaskSetManager: Lost task 20.0 in stage 465.0 (TID 48794, 128.110.152.141): ExecutorLostFailure (executor 57 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 24.563614556 seconds
res499: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.065823887 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 466:=================================================>    (95 + 9) / 104][Stage 466:====================================================>(103 + 1) / 104]                                                                                [Stage 467:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 15.019389239 seconds
res501: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 252 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 252 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.041708801 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 468:====================================================>(103 + 1) / 104]                                                                                [Stage 469:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 12.876596765 seconds
res503: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.040567998 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 470:====================================================>(103 + 1) / 104]17/06/10 03:20:29 ERROR TaskSchedulerImpl: Lost executor 55 on 128.110.152.155: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:20:29 WARN TaskSetManager: Lost task 84.0 in stage 470.0 (TID 49382, 128.110.152.155): ExecutorLostFailure (executor 55 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 471:=================================================>    (96 + 9) / 105][Stage 471:====================================================>(104 + 1) / 105]17/06/10 03:20:41 ERROR TaskSchedulerImpl: Lost executor 56 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:20:41 WARN TaskSetManager: Lost task 84.0 in stage 471.0 (TID 49487, 128.110.152.145): ExecutorLostFailure (executor 56 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 25.006720978 seconds
res505: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.041348781 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 472:=================================================>    (95 + 9) / 104][Stage 472:====================================================>(103 + 1) / 104]                                                                                [Stage 473:====================================================>(104 + 1) / 105]17/06/10 03:21:01 ERROR TaskSchedulerImpl: Lost executor 52 on 128.110.152.176: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:21:01 WARN TaskSetManager: Lost task 84.0 in stage 473.0 (TID 49697, 128.110.152.176): ExecutorLostFailure (executor 52 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 17.877815018 seconds
res507: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 203 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 203 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04048788 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 474:=================================================>    (96 + 8) / 104][Stage 474:====================================================>(103 + 1) / 104]                                                                                [Stage 475:====================================================>(104 + 1) / 105]17/06/10 03:21:32 ERROR TaskSchedulerImpl: Lost executor 61 on 128.110.152.176: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:21:32 WARN TaskSetManager: Lost task 56.0 in stage 475.0 (TID 49879, 128.110.152.176): ExecutorLostFailure (executor 61 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 31.302621579 seconds
res509: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.044559948 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.037877214 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 03:21:42 ERROR TaskSchedulerImpl: Lost executor 58 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:21:42 WARN TaskSetManager: Lost task 56.0 in stage 476.0 (TID 49985, 128.110.152.141): ExecutorLostFailure (executor 58 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 476:=================================================>    (95 + 9) / 104][Stage 476:====================================================>(103 + 1) / 104]17/06/10 03:21:49 ERROR TaskSchedulerImpl: Lost executor 32 on 128.110.152.144: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:21:49 WARN TaskSetManager: Lost task 56.1 in stage 476.0 (TID 50033, 128.110.152.144): ExecutorLostFailure (executor 32 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 477:============================================>        (88 + 17) / 105][Stage 477:=================================================>    (96 + 9) / 105][Stage 477:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 22.762051119 seconds
res512: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.043505066 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.662026872 seconds
res514: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.041023182 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.547282646 seconds
res516: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.567158745 seconds
res517: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.040561641 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.498472709 seconds
res519: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 117 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 117 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.037700155 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.612479036 seconds
res521: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.037836435 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.59363138 seconds
res523: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.0400183 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.500062033 seconds
res525: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 250 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 250 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.040732261 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 492:====================================================>(103 + 1) / 104]                                                                                [Stage 493:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 12.407392585 seconds
res527: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.044377888 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.03967416 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 494:====================================================>(103 + 1) / 104]                                                                                [Stage 495:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.634334197 seconds
res530: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048025956 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 496:====================================================>(103 + 1) / 104]                                                                                [Stage 497:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.332246697 seconds
res532: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.040962162 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 498:====================================================>(103 + 1) / 104]                                                                                [Stage 499:====================================================>(104 + 1) / 105]17/06/10 03:23:11 ERROR TaskSchedulerImpl: Lost executor 40 on 128.110.152.152: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:23:11 WARN TaskSetManager: Lost task 84.0 in stage 499.0 (TID 52418, 128.110.152.152): ExecutorLostFailure (executor 40 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 17.659504052 seconds
res534: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 500:=================================================>    (95 + 9) / 104][Stage 500:====================================================>(103 + 1) / 104]                                                                                [Stage 501:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.336266979 seconds
res535: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04424145 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 502:====================================================>(103 + 1) / 104]                                                                                [Stage 503:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.958776201 seconds
res537: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 57 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 57 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04923992 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 504:====================================================>(103 + 1) / 104]                                                                                [Stage 505:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 15.326986994 seconds
res539: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.0495972 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 506:====================================================>(103 + 1) / 104]                                                                                [Stage 507:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 14.715465098 seconds
res541: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045756033 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 508:====================================================>(103 + 1) / 104]17/06/10 03:24:17 ERROR TaskSchedulerImpl: Lost executor 54 on 128.110.152.146: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:24:17 WARN TaskSetManager: Lost task 20.0 in stage 508.0 (TID 53296, 128.110.152.146): ExecutorLostFailure (executor 54 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 509:=================================================>    (96 + 9) / 105][Stage 509:====================================================>(104 + 1) / 105]17/06/10 03:24:34 ERROR TaskSchedulerImpl: Lost executor 63 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:24:34 WARN TaskSetManager: Lost task 20.0 in stage 509.0 (TID 53401, 128.110.152.141): ExecutorLostFailure (executor 63 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 25.667062691 seconds
res543: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 15 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 15 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04383723 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 510:===============================================>     (94 + 10) / 104][Stage 510:=================================================>    (95 + 9) / 104][Stage 510:====================================================>(103 + 1) / 104]                                                                                [Stage 511:===================================================> (103 + 2) / 105][Stage 511:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.488474956 seconds
res545: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054626672 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.040537063 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 512:===================================================> (102 + 2) / 104][Stage 512:====================================================>(103 + 1) / 104]                                                                                [Stage 513:===================================================> (103 + 2) / 105][Stage 513:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.260600872 seconds
res548: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.044234191 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 514:====================================================>(103 + 1) / 104]                                                                                [Stage 515:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 12.121304932 seconds
res550: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.044010571 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 516:====================================================>(103 + 1) / 104]                                                                                [Stage 517:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.422855895 seconds
res552: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 518:====================================================>(103 + 1) / 104]                                                                                [Stage 519:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.619327224 seconds
res553: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04817564 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 520:====================================================>(103 + 1) / 104]                                                                                [Stage 521:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.135676858 seconds
res555: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 197 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 197 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045674235 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.56581718 seconds
res557: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.0382839 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.482248385 seconds
res559: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.036803217 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.69518345 seconds
res561: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 115 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 115 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.044928754 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 528:====================================================>(103 + 1) / 104]                                                                                [Stage 529:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 15.881973541 seconds
res563: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04272039 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.039031322 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 530:====================================================>(103 + 1) / 104]                                                                                [Stage 531:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 16.250340431 seconds
res566: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.040534586 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 532:====================================================>(104 + 1) / 105]17/06/10 03:26:59 ERROR TaskSchedulerImpl: Lost executor 67 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:26:59 WARN TaskSetManager: Lost task 39.0 in stage 532.0 (TID 55825, 128.110.152.141): ExecutorLostFailure (executor 67 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 533:=================================================>    (97 + 9) / 106][Stage 533:====================================================>(105 + 1) / 106]17/06/10 03:27:12 ERROR TaskSchedulerImpl: Lost executor 66 on 128.110.152.146: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:27:12 WARN TaskSetManager: Lost task 39.0 in stage 533.0 (TID 55931, 128.110.152.146): ExecutorLostFailure (executor 66 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 36.740259535 seconds
res568: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.041392973 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 534:=================================================>    (96 + 9) / 105][Stage 534:====================================================>(104 + 1) / 105]                                                                                [Stage 535:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 14.544069669 seconds
res570: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 536:====================================================>(104 + 1) / 105]                                                                                [Stage 537:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 14.130644649 seconds
res571: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.040580475 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 538:====================================================>(104 + 1) / 105]                                                                                [Stage 539:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 16.553160292 seconds
res573: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 118 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 118 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053235315 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 540:====================================================>(104 + 1) / 105]                                                                                [Stage 541:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 15.27146796 seconds
res575: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.059050746 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 03:28:26 ERROR TaskSchedulerImpl: Lost executor 59 on 128.110.152.155: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:28:26 WARN TaskSetManager: Lost task 39.0 in stage 542.0 (TID 56882, 128.110.152.155): ExecutorLostFailure (executor 59 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 542:====================================================>(104 + 1) / 105]                                                                                [Stage 543:=================================================>    (97 + 9) / 106][Stage 543:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 14.054860483 seconds
res577: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.041034776 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 544:====================================================>(104 + 1) / 105]                                                                                [Stage 545:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 14.29839411 seconds
res579: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 50 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 50 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.040401978 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 546:====================================================>(103 + 1) / 104]                                                                                [Stage 547:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.506760528 seconds
res581: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.040913796 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.039688339 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 548:====================================================>(103 + 1) / 104]                                                                                [Stage 549:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 11.466655419 seconds
res584: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.064349902 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 550:====================================================>(104 + 1) / 105]                                                                                [Stage 551:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 13.289555397 seconds
res586: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052442601 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 552:====================================================>(104 + 1) / 105]                                                                                [Stage 553:====================================================>(105 + 1) / 106]17/06/10 03:29:54 ERROR TaskSchedulerImpl: Lost executor 68 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:29:54 WARN TaskSetManager: Lost task 0.0 in stage 553.0 (TID 58000, 128.110.152.141): ExecutorLostFailure (executor 68 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 21.916909028 seconds
res588: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 03:30:02 ERROR TaskSchedulerImpl: Lost executor 60 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:30:02 WARN TaskSetManager: Lost task 0.0 in stage 554.0 (TID 58107, 128.110.152.145): ExecutorLostFailure (executor 60 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 554:=================================================>    (96 + 9) / 105][Stage 554:====================================================>(104 + 1) / 105]                                                                                [Stage 555:=================================================>    (97 + 9) / 106][Stage 555:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 15.056616592 seconds
res589: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055135759 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 556:====================================================>(104 + 1) / 105]                                                                                [Stage 557:====================================================>(105 + 1) / 106]17/06/10 03:30:32 ERROR TaskSchedulerImpl: Lost executor 71 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:30:32 WARN TaskSetManager: Lost task 0.0 in stage 557.0 (TID 58424, 128.110.152.141): ExecutorLostFailure (executor 71 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:30:40 ERROR TaskSchedulerImpl: Lost executor 70 on 128.110.152.155: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:30:40 WARN TaskSetManager: Lost task 0.1 in stage 557.0 (TID 58530, 128.110.152.155): ExecutorLostFailure (executor 70 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 28.884324719 seconds
res591: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 249 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 249 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.043441137 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 558:============================================>        (88 + 17) / 105][Stage 558:====================================================>(104 + 1) / 105]                                                                                [Stage 559:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 11.734155931 seconds
res593: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.113143516 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 560:====================================================>(104 + 1) / 105]                                                                                [Stage 561:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 11.880182528 seconds
res595: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.043239278 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 562:====================================================>(104 + 1) / 105]                                                                                [Stage 563:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 10.314497592 seconds
res597: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 59 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 59 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042823779 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 564:====================================================>(104 + 1) / 105]17/06/10 03:31:36 ERROR TaskSchedulerImpl: Lost executor 69 on 128.110.152.146: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:31:36 WARN TaskSetManager: Lost task 18.0 in stage 564.0 (TID 59183, 128.110.152.146): ExecutorLostFailure (executor 69 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 565:=================================================>    (97 + 9) / 106][Stage 565:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 23.991159467 seconds
res599: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051291648 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.036949648 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 566:====================================================>(104 + 1) / 105]                                                                                [Stage 567:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 15.697313488 seconds
res602: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042600541 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 568:====================================================>(104 + 1) / 105]                                                                                [Stage 569:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 14.559233998 seconds
res604: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046252637 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 570:====================================================>(104 + 1) / 105]                                                                                [Stage 571:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 15.673014343 seconds
res606: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 572:====================================================>(104 + 1) / 105]                                                                                [Stage 573:====================================================>(105 + 1) / 106]17/06/10 03:32:59 ERROR TaskSchedulerImpl: Lost executor 72 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:32:59 WARN TaskSetManager: Lost task 18.0 in stage 573.0 (TID 60133, 128.110.152.145): ExecutorLostFailure (executor 72 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 24.326088164 seconds
res607: Int = 0

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056648764 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 574:=================================================>    (96 + 9) / 105][Stage 574:====================================================>(104 + 1) / 105]                                                                                [Stage 575:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 15.348198408 seconds
res609: Int = 0

scala> 

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 136 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 136 ",1))

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.040067247 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 576:====================================================>(104 + 1) / 105]17/06/10 03:33:31 ERROR TaskSchedulerImpl: Lost executor 62 on 128.110.152.176: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:33:31 WARN TaskSetManager: Lost task 39.0 in stage 576.0 (TID 60472, 128.110.152.176): ExecutorLostFailure (executor 62 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                17/06/10 03:33:38 ERROR TaskSchedulerImpl: Lost executor 37 on 128.110.152.163: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:33:38 WARN TaskSetManager: Lost task 104.0 in stage 577.0 (TID 60643, 128.110.152.163): ExecutorLostFailure (executor 37 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:33:38 WARN TaskSetManager: Lost task 65.0 in stage 577.0 (TID 60604, 128.110.152.163): ExecutorLostFailure (executor 37 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:33:38 WARN TaskSetManager: Lost task 105.0 in stage 577.0 (TID 60644, 128.110.152.163): ExecutorLostFailure (executor 37 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:33:38 WARN TaskSetManager: Lost task 39.0 in stage 577.0 (TID 60578, 128.110.152.163): ExecutorLostFailure (executor 37 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 577:=================================================>    (97 + 9) / 106][Stage 577:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 22.107100129 seconds
res611: Int = 0

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047402378 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 578:=================================================>    (96 + 9) / 105][Stage 578:====================================================>(104 + 1) / 105]                                                                                [Stage 579:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 15.595557944 seconds
res613: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.043357123 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 580:====================================================>(104 + 1) / 105]                                                                                17/06/10 03:34:12 ERROR TaskSchedulerImpl: Lost executor 73 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:34:12 WARN TaskSetManager: Lost task 39.0 in stage 581.0 (TID 61004, 128.110.152.141): ExecutorLostFailure (executor 73 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 581:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 14.454953739 seconds
res615: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 2 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 2 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.039772949 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 582:===============================================>     (94 + 10) / 104][Stage 582:=================================================>    (95 + 9) / 104][Stage 582:=================================================>    (96 + 8) / 104]                                                                                [Stage 583:===================================================> (103 + 2) / 105][Stage 583:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 9.059404231 seconds
res617: Int = 0

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048044958 seconds

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049760197 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 584:===================================================> (102 + 2) / 104][Stage 584:====================================================>(103 + 1) / 104]                                                                                [Stage 585:===================================================> (103 + 2) / 105][Stage 585:====================================================>(104 + 1) / 105]                                                                                Time elapsed: 7.14459948 seconds
res620: Int = 0

scala> 

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.037218033 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 586:===================================================> (103 + 2) / 105][Stage 586:====================================================>(104 + 1) / 105]                                                                                [Stage 587:====================================================>(104 + 2) / 106][Stage 587:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 14.653350719 seconds
res622: Int = 0

scala> 

scala> 

scala> 

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042638286 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 588:===================================================> (103 + 2) / 105][Stage 588:====================================================>(104 + 1) / 105]                                                                                [Stage 589:====================================================>(104 + 2) / 106][Stage 589:====================================================>(105 + 1) / 106]17/06/10 03:35:09 ERROR TaskSchedulerImpl: Lost executor 75 on 128.110.152.146: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:35:09 WARN TaskSetManager: Lost task 0.0 in stage 589.0 (TID 61806, 128.110.152.146): ExecutorLostFailure (executor 75 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:35:09 ERROR TaskSchedulerImpl: Lost executor 51 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:35:09 WARN TaskSetManager: Lost task 0.1 in stage 589.0 (TID 61912, 128.110.152.168): ExecutorLostFailure (executor 51 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 19.378040383 seconds
res624: Int = 0

scala> 

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 590:===========================================>         (87 + 18) / 105][Stage 590:============================================>        (88 + 17) / 105][Stage 590:=================================================>    (96 + 9) / 105][Stage 590:====================================================>(104 + 1) / 105]                                                                                [Stage 591:====================================================>(104 + 2) / 106][Stage 591:====================================================>(105 + 1) / 106]                                                                                Time elapsed: 13.673455617 seconds
res625: Int = 0

scala> 

scala> :quit
