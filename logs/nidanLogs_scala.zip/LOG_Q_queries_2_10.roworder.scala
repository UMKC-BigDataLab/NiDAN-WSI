Using Spark's default log4j profile: org/apache/spark/log4j-defaults.properties
Setting default log level to "WARN".
To adjust logging level use sc.setLogLevel(newLevel).
17/06/10 04:34:49 WARN NativeCodeLoader: Unable to load native-hadoop library for your platform... using builtin-java classes where applicable
17/06/10 04:34:52 WARN SparkContext: Use an existing SparkContext, some configuration may not take effect.
Spark context Web UI available at http://128.110.152.156:4040
Spark context available as 'sc' (master = spark://ctl:7077, app id = app-20170610043451-0059).
Spark session available as 'spark'.
Welcome to
      ____              __
     / __/__  ___ _____/ /__
    _\ \/ _ \/ _ `/ __/  '_/
   /___/ .__/\_,_/_/ /_/\_\   version 2.0.2
      /_/
         
Using Scala version 2.11.8 (OpenJDK 64-Bit Server VM, Java 1.8.0_131)
Type in expressions to have them evaluated.
Type :help for more information.

scala>  
     | import java.io.File
import java.io.File

scala> import java.io.FileOutputStream
import java.io.FileOutputStream

scala> import org.apache.spark.sql._
import org.apache.spark.sql._

scala> 

scala> def show_timing[T](proc: => T): T = {
     |     val start=System.nanoTime()
     |     val res = proc
     |     val end = System.nanoTime()
     |     println("Time elapsed: " + (end-start)/1000000000.0 + " seconds")
     |     res
     | }
show_timing: [T](proc: => T)T

scala> 

scala> val writeToLocal = (in:(Array[Byte], Long, String)) =>{
     |     val bytes = in._1
     |     val output = in._3
     |     
     |     val writer = new FileOutputStream(output)
     |     writer.write(bytes)
     |     writer.close
     |     1
     |   }
writeToLocal: ((Array[Byte], Long, String)) => Int = <function1>

scala> 

scala> val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)
warning: there was one deprecation warning; re-run with -deprecation for details
sqlContext: org.apache.spark.sql.hive.HiveContext = org.apache.spark.sql.hive.HiveContext@7757a37f

scala>   
     | val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 103  OR  partitionIndex = 118 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 103  OR  partitionIndex = 118 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 15.646040537 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 0:>                                                        (0 + 72) / 73][Stage 0:====================================================>    (67 + 6) / 73][Stage 0:=======================================================> (71 + 2) / 73][Stage 0:========================================================>(72 + 1) / 73]                                                                                [Stage 1:=======================================================> (72 + 2) / 74][Stage 1:========================================================>(73 + 1) / 74]                                                                                Time elapsed: 24.418258196 seconds
res3: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 92  OR  partitionIndex = 93 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 92  OR  partitionIndex = 93 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.165612773 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 2:================================>                       (42 + 30) / 72][Stage 2:========================================================>(71 + 1) / 72]                                                                                [Stage 3:========================================================>(72 + 1) / 73]                                                                                Time elapsed: 16.721101965 seconds
res5: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 34  OR  partitionIndex = 35 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 34  OR  partitionIndex = 35 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.124921199 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 4:========================================================>(71 + 1) / 72]                                                                                [Stage 5:========================================================>(72 + 1) / 73]                                                                                Time elapsed: 12.962595686 seconds
res7: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 230  OR  partitionIndex = 231 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 230  OR  partitionIndex = 231 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.113733395 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.986502267 seconds
res9: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 6  OR  partitionIndex = 21 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 6  OR  partitionIndex = 21 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.104708003 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 8:=======================================================> (70 + 2) / 72][Stage 8:========================================================>(71 + 1) / 72]                                                                                [Stage 9:=======================================================> (71 + 2) / 73][Stage 9:========================================================>(72 + 1) / 73]                                                                                Time elapsed: 12.870180976 seconds
res11: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 198  OR  partitionIndex = 199 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 198  OR  partitionIndex = 199 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.111935016 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 10:=======================================================>(71 + 1) / 72]                                                                                [Stage 11:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 17.719473661 seconds
res13: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 142  OR  partitionIndex = 157 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 142  OR  partitionIndex = 157 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.108054769 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 1.071168302 seconds
res15: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 44  OR  partitionIndex = 45 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 44  OR  partitionIndex = 45 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.105494438 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 14:=======================================================>(71 + 1) / 72]                                                                                [Stage 15:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 11.868612601 seconds
res17: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 31  OR  partitionIndex = 44 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 31  OR  partitionIndex = 44 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.09511811 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 16:=======================================================>(71 + 1) / 72]                                                                                [Stage 17:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 12.832741314 seconds
res19: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 107  OR  partitionIndex = 122 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 107  OR  partitionIndex = 122 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.102783888 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 18:=======================================================>(71 + 1) / 72]                                                                                [Stage 19:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 17.261351932 seconds
res21: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 14  OR  partitionIndex = 29 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 14  OR  partitionIndex = 29 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.081721933 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 20:======================================================> (70 + 2) / 72][Stage 20:=======================================================>(71 + 1) / 72]                                                                                [Stage 21:======================================================> (71 + 2) / 73]17/06/10 04:38:15 ERROR TaskSchedulerImpl: Lost executor 6 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:38:15 WARN TaskSetManager: Lost task 13.0 in stage 21.0 (TID 1537, 128.110.152.141): ExecutorLostFailure (executor 6 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 21:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 15.271822303 seconds
res23: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 39  OR  partitionIndex = 54 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 39  OR  partitionIndex = 54 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.074396696 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 22:===============================================>       (62 + 10) / 72][Stage 22:======================================================> (70 + 2) / 72][Stage 22:=======================================================>(71 + 1) / 72]                                                                                [Stage 23:======================================================> (71 + 2) / 73][Stage 23:=======================================================>(72 + 1) / 73]17/06/10 04:38:38 ERROR TaskSchedulerImpl: Lost executor 8 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:38:38 WARN TaskSetManager: Lost task 9.0 in stage 23.0 (TID 1679, 128.110.152.145): ExecutorLostFailure (executor 8 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:38:38 ERROR TransportResponseHandler: Still have 1 requests outstanding when connection from /128.110.152.145:39554 is closed
                                                                                Time elapsed: 21.649764096 seconds
res25: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 72  OR  partitionIndex = 73 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 72  OR  partitionIndex = 73 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.071006128 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 24:=================================================>      (64 + 8) / 72]                                                                                Time elapsed: 5.86711959 seconds
res27: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 134  OR  partitionIndex = 135 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 134  OR  partitionIndex = 135 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.08034938 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.805742273 seconds
res29: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 111  OR  partitionIndex = 126 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 111  OR  partitionIndex = 126 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.062129134 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 28:=======================================================>(71 + 1) / 72]                                                                                [Stage 29:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 17.146747594 seconds
res31: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 12  OR  partitionIndex = 59 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 12  OR  partitionIndex = 59 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.069537534 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 30:=====================================================>  (69 + 3) / 72][Stage 30:======================================================> (70 + 2) / 72][Stage 30:=======================================================>(71 + 1) / 72]                                                                                [Stage 31:=====================================================>  (70 + 3) / 73][Stage 31:======================================================> (71 + 2) / 73][Stage 31:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 15.172238793 seconds
res33: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 11  OR  partitionIndex = 26 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 11  OR  partitionIndex = 26 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.061765617 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 32:======================================================> (71 + 2) / 73][Stage 32:=======================================================>(72 + 1) / 73]                                                                                [Stage 33:======================================================> (72 + 2) / 74][Stage 33:=======================================================>(73 + 1) / 74]                                                                                Time elapsed: 10.976219016 seconds
res35: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 139  OR  partitionIndex = 154 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 139  OR  partitionIndex = 154 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.075647977 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.931982731 seconds
res37: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 146  OR  partitionIndex = 147 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 146  OR  partitionIndex = 147 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.063664532 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.624710259 seconds
res39: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 232  OR  partitionIndex = 233 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 232  OR  partitionIndex = 233 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.062070857 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 38:>                                                        (0 + 0) / 72][Stage 38:=======================================================>(71 + 1) / 72]                                                                                [Stage 39:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 11.73351054 seconds
res41: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 27  OR  partitionIndex = 40 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 27  OR  partitionIndex = 40 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.076332576 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 40:======================================================> (70 + 2) / 72][Stage 40:=======================================================>(71 + 1) / 72]17/06/10 04:40:18 ERROR TaskSchedulerImpl: Lost executor 9 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:40:18 WARN TaskSetManager: Lost task 28.0 in stage 40.0 (TID 2934, 128.110.152.141): ExecutorLostFailure (executor 9 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:40:27 ERROR TaskSchedulerImpl: Lost executor 10 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:40:27 WARN TaskSetManager: Lost task 28.1 in stage 40.0 (TID 2978, 128.110.152.145): ExecutorLostFailure (executor 10 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 41:=========================================>             (55 + 18) / 73]17/06/10 04:40:36 ERROR TaskSchedulerImpl: Lost executor 3 on 128.110.152.144: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:40:36 WARN TaskSetManager: Lost task 45.0 in stage 41.0 (TID 3025, 128.110.152.144): ExecutorLostFailure (executor 3 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 41:======================================================> (71 + 2) / 73][Stage 41:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 31.126221374 seconds
res43: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 219  OR  partitionIndex = 232 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 219  OR  partitionIndex = 232 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.073926565 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 42:=================================================>      (65 + 8) / 73][Stage 42:=======================================================>(72 + 1) / 73]                                                                                [Stage 43:=======================================================>(73 + 1) / 74]                                                                                Time elapsed: 17.313395336 seconds
res45: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 140  OR  partitionIndex = 187 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 140  OR  partitionIndex = 187 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.067031465 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.784734105 seconds
res47: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 202  OR  partitionIndex = 203 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 202  OR  partitionIndex = 203 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056887995 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 46:=======================================================>(71 + 1) / 72]                                                                                [Stage 47:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 13.738793164 seconds
res49: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 222  OR  partitionIndex = 223 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 222  OR  partitionIndex = 223 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.065044672 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 48:=======================================================>(71 + 1) / 72]                                                                                [Stage 49:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 11.320508434 seconds
res51: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 162  OR  partitionIndex = 177 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 162  OR  partitionIndex = 177 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.084447857 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 50:=======================================================>(72 + 1) / 73]                                                                                [Stage 51:=======================================================>(73 + 1) / 74]                                                                                Time elapsed: 12.37899308 seconds
res53: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 238  OR  partitionIndex = 253 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 238  OR  partitionIndex = 253 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.078676275 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 52:=======================================================>(71 + 1) / 72]                                                                                [Stage 53:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 14.185319775 seconds
res55: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 167  OR  partitionIndex = 182 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 167  OR  partitionIndex = 182 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05926157 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 54:=================================================>      (63 + 9) / 72]17/06/10 04:42:09 ERROR TaskSchedulerImpl: Lost executor 12 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:42:09 WARN TaskSetManager: Lost task 27.0 in stage 54.0 (TID 3955, 128.110.152.145): ExecutorLostFailure (executor 12 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:42:09 WARN TaskSetManager: Lost task 63.0 in stage 54.0 (TID 3991, 128.110.152.145): ExecutorLostFailure (executor 12 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:42:09 WARN TaskSetManager: Lost task 36.0 in stage 54.0 (TID 3964, 128.110.152.145): ExecutorLostFailure (executor 12 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:42:09 WARN TaskSetManager: Lost task 45.0 in stage 54.0 (TID 3973, 128.110.152.145): ExecutorLostFailure (executor 12 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:42:09 WARN TaskSetManager: Lost task 54.0 in stage 54.0 (TID 3982, 128.110.152.145): ExecutorLostFailure (executor 12 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:42:09 WARN TaskSetManager: Lost task 18.0 in stage 54.0 (TID 3946, 128.110.152.145): ExecutorLostFailure (executor 12 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:42:09 WARN TaskSetManager: Lost task 0.0 in stage 54.0 (TID 3928, 128.110.152.145): ExecutorLostFailure (executor 12 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:42:09 WARN TaskSetManager: Lost task 9.0 in stage 54.0 (TID 3937, 128.110.152.145): ExecutorLostFailure (executor 12 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 54:=======================================================>(71 + 1) / 72]                                                                                [Stage 55:=================================================>      (64 + 9) / 73][Stage 55:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 13.055983506 seconds
res57: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 252  OR  partitionIndex = 253 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 252  OR  partitionIndex = 253 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054117886 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 56:=======================================================>(71 + 1) / 72]                                                                                [Stage 57:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 13.328553523 seconds
res59: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 63  OR  partitionIndex = 72 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 63  OR  partitionIndex = 72 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.0633348 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 58:>                                                        (0 + 0) / 72][Stage 58:=======================================================>(71 + 1) / 72]                                                                                [Stage 59:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 8.527554188 seconds
res61: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 175  OR  partitionIndex = 190 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 175  OR  partitionIndex = 190 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.070981959 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 60:=======================================================>(71 + 1) / 72]                                                                                [Stage 61:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 16.299845874 seconds
res63: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 133  OR  partitionIndex = 148 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 133  OR  partitionIndex = 148 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056277902 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.741538091 seconds
res65: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 100  OR  partitionIndex = 101 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 100  OR  partitionIndex = 101 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053919768 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.591475274 seconds
res67: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 225  OR  partitionIndex = 240 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 225  OR  partitionIndex = 240 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051729734 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 66:=======================================================>(71 + 1) / 72]                                                                                [Stage 67:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 14.243503477 seconds
res69: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 75  OR  partitionIndex = 90 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 75  OR  partitionIndex = 90 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057688979 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.603288308 seconds
res71: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 158  OR  partitionIndex = 159 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 158  OR  partitionIndex = 159 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049132922 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 70:=======================================================>(71 + 1) / 72]                                                                                [Stage 71:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 16.405420898 seconds
res73: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68  OR  partitionIndex = 115 ", 2)) 
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68  OR  partitionIndex = 115 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056835181 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.608556742 seconds
res75: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 152  OR  partitionIndex = 153 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 152  OR  partitionIndex = 153 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048598445 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.551500282 seconds
res77: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 4  OR  partitionIndex = 51 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 4  OR  partitionIndex = 51 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.075797849 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 76:======================================================> (70 + 2) / 72][Stage 76:=======================================================>(71 + 1) / 72]                                                                                17/06/10 04:44:03 ERROR TaskSchedulerImpl: Lost executor 11 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:44:03 WARN TaskSetManager: Lost task 39.0 in stage 77.0 (TID 5642, 128.110.152.141): ExecutorLostFailure (executor 11 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 77:=====================================================>  (70 + 3) / 73][Stage 77:======================================================> (71 + 2) / 73][Stage 77:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 13.079062769 seconds
res79: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 5  OR  partitionIndex = 20 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 5  OR  partitionIndex = 20 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.065034439 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 78:===============================================>       (62 + 10) / 72][Stage 78:=================================================>      (63 + 9) / 72][Stage 78:=======================================================>(71 + 1) / 72]                                                                                [Stage 79:======================================================> (71 + 2) / 73][Stage 79:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 11.0706708 seconds
res81: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 196  OR  partitionIndex = 197 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 196  OR  partitionIndex = 197 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053706111 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 80:=======================================================>(72 + 1) / 73]                                                                                [Stage 81:=======================================================>(73 + 1) / 74]                                                                                Time elapsed: 13.059779322 seconds
res83: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 151  OR  partitionIndex = 164 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 151  OR  partitionIndex = 164 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.064930961 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 82:======================================================> (70 + 2) / 72][Stage 82:=======================================================>(71 + 1) / 72]                                                                                [Stage 83:======================================================> (71 + 2) / 73][Stage 83:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 14.360704393 seconds
res85: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 193  OR  partitionIndex = 208 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 193  OR  partitionIndex = 208 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051938657 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.613013895 seconds
res87: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 200  OR  partitionIndex = 201 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 200  OR  partitionIndex = 201 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049048906 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.732683088 seconds
res89: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 94  OR  partitionIndex = 95 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 94  OR  partitionIndex = 95 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05103568 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 88:=======================================================>(71 + 1) / 72]                                                                                [Stage 89:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 15.149981495 seconds
res91: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 74  OR  partitionIndex = 75 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 74  OR  partitionIndex = 75 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.063135087 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.575687686 seconds
res93: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 235  OR  partitionIndex = 250 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 235  OR  partitionIndex = 250 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050859181 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 92:=======================================================>(71 + 1) / 72]                                                                                [Stage 93:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 11.892983836 seconds
res95: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 23  OR  partitionIndex = 36 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 23  OR  partitionIndex = 36 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.062700309 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 94:=======================================================>(71 + 1) / 72]                                                                                [Stage 95:=======================================================>(72 + 1) / 73]17/06/10 04:45:51 ERROR TaskSchedulerImpl: Lost executor 7 on 128.110.152.152: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:45:51 WARN TaskSetManager: Lost task 0.0 in stage 95.0 (TID 6911, 128.110.152.152): ExecutorLostFailure (executor 7 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 21.893049937 seconds
res97: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 162  OR  partitionIndex = 163 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 162  OR  partitionIndex = 163 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058095502 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 96:=================================================>      (64 + 8) / 72]                                                                                Time elapsed: 5.885442954 seconds
res99: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 180  OR  partitionIndex = 181 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 180  OR  partitionIndex = 181 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047069313 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.700141488 seconds
res101: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 134  OR  partitionIndex = 149 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 134  OR  partitionIndex = 149 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049171767 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 100:======================================================>(71 + 1) / 72]17/06/10 04:46:19 ERROR TaskSchedulerImpl: Lost executor 13 on 128.110.152.144: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:46:19 WARN TaskSetManager: Lost task 27.0 in stage 100.0 (TID 7302, 128.110.152.144): ExecutorLostFailure (executor 13 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 101:================================================>      (65 + 8) / 73][Stage 101:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 27.520053276 seconds
res103: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 206  OR  partitionIndex = 221 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 206  OR  partitionIndex = 221 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.060281359 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.684741663 seconds
res105: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 163  OR  partitionIndex = 178 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 163  OR  partitionIndex = 178 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048141771 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 104:======================================================>(71 + 1) / 72]                                                                                [Stage 105:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 13.5900775 seconds
res107: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 126  OR  partitionIndex = 127 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 126  OR  partitionIndex = 127 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.066343743 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 106:======================================================>(71 + 1) / 72]                                                                                [Stage 107:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 14.379438052 seconds
res109: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 188  OR  partitionIndex = 189 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 188  OR  partitionIndex = 189 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.060905958 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 108:======================================================>(72 + 1) / 73]                                                                                [Stage 109:======================================================>(73 + 1) / 74]                                                                                Time elapsed: 12.313658978 seconds
res111: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 74  OR  partitionIndex = 89 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 74  OR  partitionIndex = 89 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.062389054 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.577710068 seconds
res113: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 166  OR  partitionIndex = 167 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 166  OR  partitionIndex = 167 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057114149 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 112:======================================================>(72 + 1) / 73]                                                                                [Stage 113:======================================================>(73 + 1) / 74]                                                                                Time elapsed: 13.139287103 seconds
res115: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 77  OR  partitionIndex = 92 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 77  OR  partitionIndex = 92 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055075554 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.54126763 seconds
res117: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 154  OR  partitionIndex = 155 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 154  OR  partitionIndex = 155 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051620424 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 116:=====================================================> (70 + 2) / 72][Stage 116:======================================================>(71 + 1) / 72]                                                                                [Stage 117:=====================================================> (71 + 2) / 73][Stage 117:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 16.719138772 seconds
res119: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 78  OR  partitionIndex = 93 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 78  OR  partitionIndex = 93 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04966105 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 118:======================================================>(71 + 1) / 72]                                                                                [Stage 119:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 14.674923996 seconds
res121: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 226  OR  partitionIndex = 241 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 226  OR  partitionIndex = 241 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.098591802 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 120:======================================================>(71 + 1) / 72]17/06/10 04:48:33 ERROR TaskSchedulerImpl: Lost executor 14 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:48:33 WARN TaskSetManager: Lost task 53.0 in stage 120.0 (TID 8783, 128.110.152.145): ExecutorLostFailure (executor 14 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 121:================================================>      (64 + 9) / 73][Stage 121:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 17.14319113 seconds
res123: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 6  OR  partitionIndex = 7 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 6  OR  partitionIndex = 7 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056688792 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 122:======================================================>(72 + 1) / 73]                                                                                [Stage 123:======================================================>(73 + 1) / 74]                                                                                Time elapsed: 11.00631371 seconds
res125: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 37  OR  partitionIndex = 52 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 37  OR  partitionIndex = 52 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053489761 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 124:=====================================================> (70 + 2) / 72][Stage 124:======================================================>(71 + 1) / 72]                                                                                [Stage 125:=====================================================> (71 + 2) / 73][Stage 125:======================================================>(72 + 1) / 73]17/06/10 04:49:12 ERROR TaskSchedulerImpl: Lost executor 18 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:49:12 WARN TaskSetManager: Lost task 22.0 in stage 125.0 (TID 9117, 128.110.152.145): ExecutorLostFailure (executor 18 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 20.194190307 seconds
res127: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 8  OR  partitionIndex = 119 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 8  OR  partitionIndex = 119 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05817491 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 126:=============================================>        (61 + 11) / 72][Stage 126:==============================================>       (62 + 10) / 72][Stage 126:=====================================================> (70 + 2) / 72]17/06/10 04:49:28 ERROR TaskSchedulerImpl: Lost executor 1 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:49:28 WARN TaskSetManager: Lost task 27.0 in stage 126.0 (TID 9196, 128.110.152.142): ExecutorLostFailure (executor 1 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:49:28 WARN TaskSetManager: Lost task 0.0 in stage 126.0 (TID 9169, 128.110.152.142): ExecutorLostFailure (executor 1 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 126:======================================================>(71 + 1) / 72]                                                                                [Stage 127:=============================================>        (62 + 11) / 73][Stage 127:==============================================>       (63 + 10) / 73][Stage 127:=====================================================> (71 + 2) / 73][Stage 127:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 21.275989155 seconds
res129: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 229  OR  partitionIndex = 244 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 229  OR  partitionIndex = 244 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056345895 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.831233743 seconds
res131: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 102  OR  partitionIndex = 117 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 102  OR  partitionIndex = 117 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048054197 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.675607384 seconds
res133: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 87  OR  partitionIndex = 100 ", 2)) 
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 87  OR  partitionIndex = 100 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046961439 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 132:======================================================>(71 + 1) / 72]17/06/10 04:49:57 ERROR TaskSchedulerImpl: Lost executor 4 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:49:57 WARN TaskSetManager: Lost task 9.0 in stage 132.0 (TID 9615, 128.110.152.168): ExecutorLostFailure (executor 4 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:50:05 ERROR TaskSchedulerImpl: Lost executor 15 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:50:05 WARN TaskSetManager: Lost task 9.1 in stage 132.0 (TID 9678, 128.110.152.141): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 133:=========================================>            (56 + 17) / 73][Stage 133:================================================>      (64 + 9) / 73][Stage 133:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 30.116261133 seconds
res135: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 30  OR  partitionIndex = 31 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 30  OR  partitionIndex = 31 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.089406992 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 134:======================================================>(71 + 1) / 72]                                                                                [Stage 135:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 14.015973655 seconds
res137: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 110  OR  partitionIndex = 111 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 110  OR  partitionIndex = 111 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052006048 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.678641817 seconds
res139: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 47  OR  partitionIndex = 62 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 47  OR  partitionIndex = 62 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04751816 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 138:=====================================================> (70 + 2) / 72][Stage 138:======================================================>(71 + 1) / 72]                                                                                [Stage 139:=====================================================> (71 + 2) / 73]17/06/10 04:50:53 ERROR TaskSchedulerImpl: Lost executor 2 on 128.110.152.160: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:50:53 WARN TaskSetManager: Lost task 54.0 in stage 139.0 (TID 10169, 128.110.152.160): ExecutorLostFailure (executor 2 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 139:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 16.574592838 seconds
res141: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 131  OR  partitionIndex = 146 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 131  OR  partitionIndex = 146 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049232875 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 140:================================================>      (64 + 8) / 72]                                                                                Time elapsed: 5.729361412 seconds
res143: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 55  OR  partitionIndex = 64 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 55  OR  partitionIndex = 64 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046849501 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 142:======================================================>(71 + 1) / 72]                                                                                [Stage 143:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 10.676251864 seconds
res145: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 1  OR  partitionIndex = 16 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 1  OR  partitionIndex = 16 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.06361646 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 144:====================================================>  (69 + 3) / 72][Stage 144:=====================================================> (70 + 2) / 72][Stage 144:======================================================>(71 + 1) / 72]                                                                                [Stage 145:====================================================>  (70 + 3) / 73][Stage 145:=====================================================> (71 + 2) / 73][Stage 145:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 17.114597205 seconds
res147: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 104  OR  partitionIndex = 105 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 104  OR  partitionIndex = 105 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05186967 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 146:==========================================>           (56 + 16) / 72][Stage 146:==========================================>           (57 + 15) / 72][Stage 146:===========================================>          (58 + 14) / 72]17/06/10 04:51:46 WARN TransportChannelHandler: Exception in connection from /128.110.152.165:45546
java.io.IOException: Connection reset by peer
	at sun.nio.ch.FileDispatcherImpl.read0(Native Method)
	at sun.nio.ch.SocketDispatcher.read(SocketDispatcher.java:39)
	at sun.nio.ch.IOUtil.readIntoNativeBuffer(IOUtil.java:223)
	at sun.nio.ch.IOUtil.read(IOUtil.java:192)
	at sun.nio.ch.SocketChannelImpl.read(SocketChannelImpl.java:380)
	at io.netty.buffer.PooledUnsafeDirectByteBuf.setBytes(PooledUnsafeDirectByteBuf.java:313)
	at io.netty.buffer.AbstractByteBuf.writeBytes(AbstractByteBuf.java:881)
	at io.netty.channel.socket.nio.NioSocketChannel.doReadBytes(NioSocketChannel.java:242)
	at io.netty.channel.nio.AbstractNioByteChannel$NioByteUnsafe.read(AbstractNioByteChannel.java:119)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:511)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 04:51:46 ERROR TransportResponseHandler: Still have 1 requests outstanding when connection from /128.110.152.165:45546 is closed
17/06/10 04:51:46 ERROR TaskSchedulerImpl: Lost executor 0 on 128.110.152.165: Command exited with code 137
17/06/10 04:51:46 WARN TaskSetManager: Lost task 59.0 in stage 146.0 (TID 10683, 128.110.152.165): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 04:51:46 WARN TaskSetManager: Lost task 32.0 in stage 146.0 (TID 10656, 128.110.152.165): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 04:51:46 WARN TaskSetManager: Lost task 41.0 in stage 146.0 (TID 10665, 128.110.152.165): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 04:51:46 WARN TaskSetManager: Lost task 68.0 in stage 146.0 (TID 10692, 128.110.152.165): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 04:51:46 WARN TaskSetManager: Lost task 23.0 in stage 146.0 (TID 10647, 128.110.152.165): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 04:51:46 WARN TaskSetManager: Lost task 14.0 in stage 146.0 (TID 10638, 128.110.152.165): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 04:51:46 WARN TaskSetManager: Lost task 50.0 in stage 146.0 (TID 10674, 128.110.152.165): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 04:51:46 WARN TaskSetManager: Lost task 5.0 in stage 146.0 (TID 10629, 128.110.152.165): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Command exited with code 137
[Stage 146:=================================================>     (65 + 7) / 72][Stage 146:======================================================>(71 + 1) / 72]                                                                                [Stage 147:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 18.076083196 seconds
res149: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 82  OR  partitionIndex = 83 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 82  OR  partitionIndex = 83 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054065025 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 148:================================================>      (63 + 9) / 72][Stage 148:======================================================>(71 + 1) / 72]                                                                                [Stage 149:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 16.096553339 seconds
res151: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 43  OR  partitionIndex = 58 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 43  OR  partitionIndex = 58 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057775216 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 150:=====================================================> (70 + 2) / 72][Stage 150:======================================================>(71 + 1) / 72]                                                                                [Stage 151:=====================================================> (71 + 2) / 73][Stage 151:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 15.645359405 seconds
res153: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 46  OR  partitionIndex = 47 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 46  OR  partitionIndex = 47 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049160558 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 152:======================================================>(71 + 1) / 72]                                                                                [Stage 153:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 10.940130176 seconds
res155: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 170  OR  partitionIndex = 185 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 170  OR  partitionIndex = 185 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.065591379 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.607615483 seconds
res157: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 156  OR  partitionIndex = 157 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 156  OR  partitionIndex = 157 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045829407 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 156:======================================================>(71 + 1) / 72]                                                                                [Stage 157:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 17.488144342 seconds
res159: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 194  OR  partitionIndex = 209 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 194  OR  partitionIndex = 209 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051806653 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 158:=====================================================> (70 + 2) / 72][Stage 158:======================================================>(71 + 1) / 72]                                                                                [Stage 159:=====================================================> (71 + 2) / 73][Stage 159:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 13.791860943 seconds
res161: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 102  OR  partitionIndex = 103 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 102  OR  partitionIndex = 103 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055923303 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 160:======================================================>(72 + 1) / 73]                                                                                [Stage 161:======================================================>(73 + 1) / 74]                                                                                Time elapsed: 14.685595269 seconds
res163: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 234  OR  partitionIndex = 235 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 234  OR  partitionIndex = 235 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047828643 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 162:======================================================>(72 + 1) / 73]                                                                                [Stage 163:======================================================>(73 + 1) / 74]                                                                                Time elapsed: 11.764296287 seconds
res165: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 36  OR  partitionIndex = 37 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 36  OR  partitionIndex = 37 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047307484 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 164:======================================================>(71 + 1) / 72]                                                                                [Stage 165:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 11.64848039 seconds
res167: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 240  OR  partitionIndex = 241 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 240  OR  partitionIndex = 241 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047763143 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.483863159 seconds
res169: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 132  OR  partitionIndex = 179 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 132  OR  partitionIndex = 179 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.044117152 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.486753752 seconds
res171: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 130  OR  partitionIndex = 131 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 130  OR  partitionIndex = 131 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052327112 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.462089473 seconds
res173: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68  OR  partitionIndex = 69 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68  OR  partitionIndex = 69 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045677069 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
17/06/10 04:54:19 ERROR TaskSchedulerImpl: Lost executor 22 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:54:19 WARN TaskSetManager: Lost task 9.0 in stage 172.0 (TID 12530, 128.110.152.141): ExecutorLostFailure (executor 22 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 172:======================================================>(71 + 1) / 72]                                                                                [Stage 173:================================================>      (64 + 9) / 73][Stage 173:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 15.469146641 seconds
res175: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 230  OR  partitionIndex = 245 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 230  OR  partitionIndex = 245 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054340608 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 174:======================================================>(71 + 1) / 72]                                                                                [Stage 175:======================================================>(72 + 1) / 73]17/06/10 04:54:53 ERROR TaskSchedulerImpl: Lost executor 17 on 128.110.152.144: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:54:53 WARN TaskSetManager: Lost task 53.0 in stage 175.0 (TID 12792, 128.110.152.144): ExecutorLostFailure (executor 17 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 21.95114782 seconds
res177: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 237  OR  partitionIndex = 252 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 237  OR  partitionIndex = 252 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.061255992 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 176:================================================>      (64 + 8) / 72]                                                                                Time elapsed: 5.634887822 seconds
res179: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 18  OR  partitionIndex = 19 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 18  OR  partitionIndex = 19 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047792525 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 178:>                                                       (0 + 0) / 72][Stage 178:======================================================>(71 + 1) / 72]                                                                                [Stage 179:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 11.774727375 seconds
res181: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 206  OR  partitionIndex = 207 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 206  OR  partitionIndex = 207 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.059981776 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 180:======================================================>(71 + 1) / 72]                                                                                [Stage 181:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 11.428441155 seconds
res183: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 38  OR  partitionIndex = 53 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 38  OR  partitionIndex = 53 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047370786 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 182:=====================================================> (70 + 2) / 72][Stage 182:======================================================>(71 + 1) / 72]                                                                                [Stage 183:=====================================================> (71 + 2) / 73][Stage 183:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 9.478557798 seconds
res185: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 138  OR  partitionIndex = 139 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 138  OR  partitionIndex = 139 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05459347 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 184:======================================================>(71 + 1) / 72]                                                                                [Stage 185:======================================================>(72 + 1) / 73]17/06/10 04:56:06 ERROR TaskSchedulerImpl: Lost executor 19 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:56:06 WARN TaskSetManager: Lost task 22.0 in stage 185.0 (TID 13487, 128.110.152.145): ExecutorLostFailure (executor 19 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 28.246674724 seconds
res187: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 78  OR  partitionIndex = 79 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 78  OR  partitionIndex = 79 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048457665 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 186:================================================>      (63 + 9) / 72][Stage 186:======================================================>(71 + 1) / 72]                                                                                [Stage 187:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 15.347908102 seconds
res189: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 26  OR  partitionIndex = 27 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 26  OR  partitionIndex = 27 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.043773057 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 188:=====================================================> (70 + 2) / 72][Stage 188:======================================================>(71 + 1) / 72]                                                                                [Stage 189:=====================================================> (71 + 2) / 73][Stage 189:======================================================>(72 + 1) / 73]17/06/10 04:56:47 ERROR TaskSchedulerImpl: Lost executor 20 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:56:47 WARN TaskSetManager: Lost task 13.0 in stage 189.0 (TID 13769, 128.110.152.142): ExecutorLostFailure (executor 20 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 19.229493887 seconds
res191: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 3  OR  partitionIndex = 18 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 3  OR  partitionIndex = 18 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.072132791 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 190:==============================================>       (62 + 10) / 72][Stage 190:================================================>      (63 + 9) / 72][Stage 190:======================================================>(71 + 1) / 72]                                                                                [Stage 191:=====================================================> (71 + 2) / 73][Stage 191:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 13.297421648 seconds
res193: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 99  OR  partitionIndex = 114 ", 2)) 
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 99  OR  partitionIndex = 114 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047865188 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.666895857 seconds
res195: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 201  OR  partitionIndex = 216 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 201  OR  partitionIndex = 216 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046187472 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.646949765 seconds
res197: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 144  OR  partitionIndex = 145 ", 2) )
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 144  OR  partitionIndex = 145 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.041622842 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 196:======================================================>(71 + 1) / 72]                                                                                [Stage 197:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 13.617368166 seconds
res199: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 33  OR  partitionIndex = 48 ", 2))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 33  OR  partitionIndex = 48 ",2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.066098526 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 198:======================================================>(71 + 1) / 72]                                                                                [Stage 199:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 11.480361189 seconds
res201: Int = 0

scala> 

scala> :quit
