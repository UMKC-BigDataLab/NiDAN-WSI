Using Spark's default log4j profile: org/apache/spark/log4j-defaults.properties
Setting default log level to "WARN".
To adjust logging level use sc.setLogLevel(newLevel).
17/06/10 03:35:52 WARN NativeCodeLoader: Unable to load native-hadoop library for your platform... using builtin-java classes where applicable
17/06/10 03:35:55 WARN SparkContext: Use an existing SparkContext, some configuration may not take effect.
Spark context Web UI available at http://128.110.152.156:4040
Spark context available as 'sc' (master = spark://ctl:7077, app id = app-20170610033555-0057).
Spark session available as 'spark'.
Welcome to
      ____              __
     / __/__  ___ _____/ /__
    _\ \/ _ \/ _ `/ __/  '_/
   /___/ .__/\_,_/_/ /_/\_\   version 2.0.2
      /_/
         
Using Scala version 2.11.8 (OpenJDK 64-Bit Server VM, Java 1.8.0_131)
Type in expressions to have them evaluated.
Type :help for more information.

scala>  
     | import java.io.File
import java.io.File

scala> import java.io.FileOutputStream
import java.io.FileOutputStream

scala> import org.apache.spark.sql._
import org.apache.spark.sql._

scala> 

scala> def show_timing[T](proc: => T): T = {
     |     val start=System.nanoTime()
     |     val res = proc
     |     val end = System.nanoTime()
     |     println("Time elapsed: " + (end-start)/1000000000.0 + " seconds")
     |     res
     | }
show_timing: [T](proc: => T)T

scala> 

scala> val writeToLocal = (in:(Array[Byte], Long, String)) =>{
     |     val bytes = in._1
     |     val output = in._3
     |     
     |     val writer = new FileOutputStream(output)
     |     writer.write(bytes)
     |     writer.close
     |     1
     |   }
writeToLocal: ((Array[Byte], Long, String)) => Int = <function1>

scala> 

scala> val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)
warning: there was one deprecation warning; re-run with -deprecation for details
sqlContext: org.apache.spark.sql.hive.HiveContext = org.apache.spark.sql.hive.HiveContext@984de01

scala>   
     | val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 175 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 175 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 16.13300751 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 0:>                                                        (0 + 0) / 105][Stage 0:>                                                      (0 + 104) / 105][Stage 0:====================================================>  (101 + 4) / 105][Stage 0:======================================================>(104 + 1) / 105]                                                                                [Stage 1:======================================================>(105 + 1) / 106]                                                                                Time elapsed: 21.607280917 seconds
res3: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 73 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 73 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.148198167 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 2:===============================>                       (60 + 44) / 104][Stage 2:======================================================>(103 + 1) / 104]                                                                                [Stage 3:======================================================>(104 + 1) / 105]                                                                                Time elapsed: 16.886064606 seconds
res5: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 148 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 148 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.166919008 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 1.216589482 seconds
res7: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 49 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 49 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.142527737 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 6:======================================================>(103 + 1) / 104]                                                                                [Stage 7:======================================================>(104 + 1) / 105]                                                                                Time elapsed: 12.746644754 seconds
res9: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 141 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 141 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.108488337 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 8:=====================================>                 (72 + 33) / 105]                                                                                Time elapsed: 1.237672778 seconds
res11: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 131 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 131 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.101729605 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 10:=====================================================>(104 + 1) / 105]                                                                                [Stage 11:=====================================================>(105 + 1) / 106]                                                                                Time elapsed: 20.059748835 seconds
res13: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 124 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 124 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.197101281 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 12:====================================================> (102 + 2) / 104][Stage 12:=====================================================>(103 + 1) / 104]                                                                                [Stage 13:=====================================================>(104 + 1) / 105]                                                                                Time elapsed: 16.121765492 seconds
res15: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 93 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 93 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.106134424 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 14:=====================================================>(103 + 1) / 104]                                                                                17/06/10 03:38:32 ERROR TaskSchedulerImpl: Lost executor 7 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:38:32 WARN TaskSetManager: Lost task 14.0 in stage 15.0 (TID 1585, 128.110.152.141): ExecutorLostFailure (executor 7 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 15:=====================================================>(104 + 1) / 105]                                                                                Time elapsed: 15.436323124 seconds
res17: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 8 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 8 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.084019709 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 16:==================================================>    (96 + 9) / 105][Stage 16:====================================================> (103 + 2) / 105][Stage 16:=====================================================>(104 + 1) / 105]                                                                                [Stage 17:====================================================> (104 + 2) / 106][Stage 17:=====================================================>(105 + 1) / 106]                                                                                Time elapsed: 12.528265397 seconds
res19: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 67 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 67 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.089583564 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.96827258 seconds
res21: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 58 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 58 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.078816836 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 20:=====================================================>(104 + 1) / 105][Stage 20:=====================================================>(104 + 1) / 105]17/06/10 03:40:16 ERROR TaskSchedulerImpl: Lost executor 12 on 128.110.152.155: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:40:16 WARN TaskSetManager: Lost task 13.0 in stage 20.0 (TID 2110, 128.110.152.155): ExecutorLostFailure (executor 12 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 21:==================================================>    (97 + 9) / 106][Stage 21:=====================================================>(105 + 1) / 106]                                                                                Time elapsed: 91.848535845 seconds
res23: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 116 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 116 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.075189784 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.931710205 seconds
res25: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 211 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 211 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.070252129 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.902736317 seconds
res27: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 234 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 234 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.084029616 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 26:=====================================================>(103 + 1) / 104]                                                                                [Stage 27:=====================================================>(104 + 1) / 105]                                                                                Time elapsed: 13.139983366 seconds
res29: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 155 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 155 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.076769765 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.930609202 seconds
res31: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 47 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 47 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.076201005 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 30:=====================================================>(104 + 1) / 105]                                                                                [Stage 31:=====================================================>(105 + 1) / 106]                                                                                Time elapsed: 13.984446145 seconds
res33: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 233 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 233 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.078078844 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 32:=====================================================>(104 + 1) / 105]                                                                                [Stage 33:=====================================================>(105 + 1) / 106]                                                                                Time elapsed: 12.535617546 seconds
res35: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 221 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 221 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.085537178 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.75950667 seconds
res37: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 122 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 122 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.061201541 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 36:=====================================================>(104 + 1) / 105]                                                                                [Stage 37:=====================================================>(105 + 1) / 106]                                                                                Time elapsed: 14.865469016 seconds
res39: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 17 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 17 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.086150379 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 38:=====================================================>(104 + 1) / 105]                                                                                [Stage 39:=====================================================>(105 + 1) / 106]                                                                                Time elapsed: 11.273675588 seconds
res41: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 237 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 237 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.08596106 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.708309256 seconds
res43: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 154 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 154 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.059782044 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 42:=====================================================>(103 + 1) / 104]17/06/10 03:42:17 ERROR TaskSchedulerImpl: Lost executor 13 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:42:17 WARN TaskSetManager: Lost task 38.0 in stage 42.0 (TID 4445, 128.110.152.141): ExecutorLostFailure (executor 13 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 43:==================================================>    (97 + 8) / 105][Stage 43:=====================================================>(104 + 1) / 105]                                                                                Time elapsed: 27.7433679 seconds
res45: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 223 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 223 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056036068 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 44:>                                                       (0 + 0) / 105]                                                                                Time elapsed: 0.872574942 seconds
res47: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 163 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 163 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.066482019 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.77825297 seconds
res49: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 137 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 137 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.060936624 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 48:=====================================================>(103 + 1) / 104]                                                                                [Stage 49:=====================================================>(104 + 1) / 105]                                                                                Time elapsed: 17.527466535 seconds
res51: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 230 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 230 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057550108 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.65897135 seconds
res53: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 142 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 142 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058113048 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.859197712 seconds
res55: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 191 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 191 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058720068 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.788283337 seconds
res57: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 226 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 226 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051465774 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 56:=====================================================>(104 + 1) / 105]                                                                                [Stage 57:=====================================================>(105 + 1) / 106]                                                                                Time elapsed: 15.286094194 seconds
res59: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 68 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.076027193 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 58:=====================================================>(104 + 1) / 105]                                                                                [Stage 59:=====================================================>(105 + 1) / 106]17/06/10 03:43:50 ERROR TaskSchedulerImpl: Lost executor 10 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:43:50 WARN TaskSetManager: Lost task 13.0 in stage 59.0 (TID 6204, 128.110.152.145): ExecutorLostFailure (executor 10 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 25.650973686 seconds
res61: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 201 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 201 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.068168302 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 60:==================================================>    (96 + 9) / 105][Stage 60:=====================================================>(104 + 1) / 105]                                                                                [Stage 61:=====================================================>(105 + 1) / 106]17/06/10 03:44:17 ERROR TaskSchedulerImpl: Lost executor 15 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:44:17 WARN TaskSetManager: Lost task 56.0 in stage 61.0 (TID 6459, 128.110.152.141): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 26.673281657 seconds
res63: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 19 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 19 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054036171 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 62:==================================================>    (97 + 8) / 105][Stage 62:=====================================================>(104 + 1) / 105]                                                                                [Stage 63:=====================================================>(105 + 1) / 106]                                                                                Time elapsed: 17.912070552 seconds
res65: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 216 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 216 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.075296323 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.759111176 seconds
res67: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 28 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 28 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.065525006 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 66:=====================================================>(104 + 1) / 105]                                                                                [Stage 67:=====================================================>(105 + 1) / 106]                                                                                Time elapsed: 12.227059417 seconds
res69: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 151 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 151 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.071299114 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 68:=====================================================>(104 + 1) / 105]                                                                                [Stage 69:=====================================================>(105 + 1) / 106]                                                                                Time elapsed: 14.800164534 seconds
res71: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 161 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 161 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055241892 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 70:=====================================================>(103 + 1) / 104]                                                                                [Stage 71:=====================================================>(104 + 1) / 105]                                                                                Time elapsed: 17.14956079 seconds
res73: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 127 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 127 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.07413191 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 72:=====================================================>(104 + 1) / 105]                                                                                [Stage 73:=====================================================>(105 + 1) / 106]17/06/10 03:45:57 ERROR TaskSchedulerImpl: Lost executor 17 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:45:57 WARN TaskSetManager: Lost task 39.0 in stage 73.0 (TID 7707, 128.110.152.141): ExecutorLostFailure (executor 17 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 21.556223924 seconds
res75: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 38 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 38 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.06166674 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 74:==================================================>    (97 + 8) / 105][Stage 74:===================================================>   (98 + 7) / 105][Stage 74:=====================================================>(104 + 1) / 105]                                                                                [Stage 75:=====================================================>(105 + 1) / 106]17/06/10 03:46:24 ERROR TaskSchedulerImpl: Lost executor 9 on 128.110.152.176: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:46:24 WARN TaskSetManager: Lost task 0.0 in stage 75.0 (TID 7880, 128.110.152.176): ExecutorLostFailure (executor 9 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 23.703312336 seconds
res77: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 241 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 241 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.068965145 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 76:=======================================================>(96 + 1) / 97]                                                                                [Stage 77:=======================================================>(97 + 1) / 98]                                                                                Time elapsed: 11.005952536 seconds
res79: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 70 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 70 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.070976482 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 78:=======================================================>(94 + 1) / 95]                                                                                [Stage 79:=======================================================>(95 + 1) / 96]17/06/10 03:47:19 ERROR TaskSchedulerImpl: Lost executor 18 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:47:19 WARN TaskSetManager: Lost task 14.0 in stage 79.0 (TID 8291, 128.110.152.141): ExecutorLostFailure (executor 18 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 40.929829407 seconds
res81: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 114 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 114 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.059819229 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 80:==================================================>     (87 + 9) / 96][Stage 80:=======================================================>(95 + 1) / 96]                                                                                [Stage 81:=======================================================>(96 + 1) / 97]                                                                                Time elapsed: 15.022575498 seconds
res83: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 208 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 208 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052387366 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 82:=======================================================>(94 + 1) / 95]                                                                                [Stage 83:=======================================================>(95 + 1) / 96]                                                                                Time elapsed: 11.934019659 seconds
res85: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 43 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 43 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.062176986 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 84:=======================================================>(94 + 1) / 95]                                                                                [Stage 85:=======================================================>(95 + 1) / 96]                                                                                Time elapsed: 9.508612872 seconds
res87: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 6 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 6 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050312812 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 86:=======================================================>(95 + 1) / 96]                                                                                [Stage 87:=======================================================>(96 + 1) / 97]                                                                                Time elapsed: 9.059888959 seconds
res89: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 144 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 144 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057731516 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.677639214 seconds
res91: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 159 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 159 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050188953 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 90:=======================================================>(95 + 1) / 96]                                                                                [Stage 91:=======================================================>(96 + 1) / 97]                                                                                Time elapsed: 30.509331344 seconds
res93: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 90 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 90 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053259128 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 92:=============================================>         (79 + 17) / 96][Stage 92:==============================================>        (82 + 14) / 96][Stage 92:===============================================>       (83 + 13) / 96][Stage 92:================================================>      (84 + 12) / 96][Stage 92:================================================>      (85 + 11) / 96][Stage 92:=================================================>     (86 + 10) / 96][Stage 92:==================================================>     (87 + 9) / 96][Stage 92:===================================================>    (88 + 8) / 96]17/06/10 03:49:43 WARN TransportChannelHandler: Exception in connection from /128.110.152.146:34236
java.io.IOException: Connection reset by peer
	at sun.nio.ch.FileDispatcherImpl.read0(Native Method)
	at sun.nio.ch.SocketDispatcher.read(SocketDispatcher.java:39)
	at sun.nio.ch.IOUtil.readIntoNativeBuffer(IOUtil.java:223)
	at sun.nio.ch.IOUtil.read(IOUtil.java:192)
	at sun.nio.ch.SocketChannelImpl.read(SocketChannelImpl.java:380)
	at io.netty.buffer.PooledUnsafeDirectByteBuf.setBytes(PooledUnsafeDirectByteBuf.java:313)
	at io.netty.buffer.AbstractByteBuf.writeBytes(AbstractByteBuf.java:881)
	at io.netty.channel.socket.nio.NioSocketChannel.doReadBytes(NioSocketChannel.java:242)
	at io.netty.channel.nio.AbstractNioByteChannel$NioByteUnsafe.read(AbstractNioByteChannel.java:119)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:511)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 03:49:43 ERROR TaskSchedulerImpl: Lost executor 2 on 128.110.152.146: Command exited with code 137
17/06/10 03:49:43 WARN TaskSetManager: Lost task 74.0 in stage 92.0 (TID 9600, 128.110.152.146): ExecutorLostFailure (executor 2 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 03:49:43 WARN TaskSetManager: Lost task 38.0 in stage 92.0 (TID 9564, 128.110.152.146): ExecutorLostFailure (executor 2 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 03:49:43 WARN TaskSetManager: Lost task 86.0 in stage 92.0 (TID 9612, 128.110.152.146): ExecutorLostFailure (executor 2 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 03:49:43 WARN TaskSetManager: Lost task 50.0 in stage 92.0 (TID 9576, 128.110.152.146): ExecutorLostFailure (executor 2 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 03:49:43 WARN TaskSetManager: Lost task 14.0 in stage 92.0 (TID 9540, 128.110.152.146): ExecutorLostFailure (executor 2 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 03:49:43 ERROR TransportResponseHandler: Still have 2 requests outstanding when connection from /128.110.152.146:34236 is closed
17/06/10 03:49:43 WARN TaskSetManager: Lost task 26.0 in stage 92.0 (TID 9552, 128.110.152.146): ExecutorLostFailure (executor 2 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 03:49:43 WARN TaskSetManager: Lost task 62.0 in stage 92.0 (TID 9588, 128.110.152.146): ExecutorLostFailure (executor 2 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 03:49:43 WARN TaskSetManager: Lost task 2.0 in stage 92.0 (TID 9528, 128.110.152.146): ExecutorLostFailure (executor 2 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 03:49:43 WARN BlockManagerMaster: Failed to remove broadcast 130 with removeFromMaster = true - Connection reset by peer
java.io.IOException: Connection reset by peer
	at sun.nio.ch.FileDispatcherImpl.read0(Native Method)
	at sun.nio.ch.SocketDispatcher.read(SocketDispatcher.java:39)
	at sun.nio.ch.IOUtil.readIntoNativeBuffer(IOUtil.java:223)
	at sun.nio.ch.IOUtil.read(IOUtil.java:192)
	at sun.nio.ch.SocketChannelImpl.read(SocketChannelImpl.java:380)
	at io.netty.buffer.PooledUnsafeDirectByteBuf.setBytes(PooledUnsafeDirectByteBuf.java:313)
	at io.netty.buffer.AbstractByteBuf.writeBytes(AbstractByteBuf.java:881)
	at io.netty.channel.socket.nio.NioSocketChannel.doReadBytes(NioSocketChannel.java:242)
	at io.netty.channel.nio.AbstractNioByteChannel$NioByteUnsafe.read(AbstractNioByteChannel.java:119)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:511)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 03:49:43 ERROR ContextCleaner: Error cleaning broadcast 130
org.apache.spark.SparkException: Exception thrown in awaitResult
	at org.apache.spark.rpc.RpcTimeout$$anonfun$1.applyOrElse(RpcTimeout.scala:77)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$1.applyOrElse(RpcTimeout.scala:75)
	at scala.runtime.AbstractPartialFunction.apply(AbstractPartialFunction.scala:36)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$addMessageIfTimeout$1.applyOrElse(RpcTimeout.scala:59)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$addMessageIfTimeout$1.applyOrElse(RpcTimeout.scala:59)
	at scala.PartialFunction$OrElse.apply(PartialFunction.scala:167)
	at org.apache.spark.rpc.RpcTimeout.awaitResult(RpcTimeout.scala:83)
	at org.apache.spark.storage.BlockManagerMaster.removeBroadcast(BlockManagerMaster.scala:143)
	at org.apache.spark.broadcast.TorrentBroadcast$.unpersist(TorrentBroadcast.scala:267)
	at org.apache.spark.broadcast.TorrentBroadcastFactory.unbroadcast(TorrentBroadcastFactory.scala:45)
	at org.apache.spark.broadcast.BroadcastManager.unbroadcast(BroadcastManager.scala:60)
	at org.apache.spark.ContextCleaner.doCleanupBroadcast(ContextCleaner.scala:232)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1$$anonfun$apply$mcV$sp$2.apply(ContextCleaner.scala:188)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1$$anonfun$apply$mcV$sp$2.apply(ContextCleaner.scala:179)
	at scala.Option.foreach(Option.scala:257)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1.apply$mcV$sp(ContextCleaner.scala:179)
	at org.apache.spark.util.Utils$.tryOrStopSparkContext(Utils.scala:1252)
	at org.apache.spark.ContextCleaner.org$apache$spark$ContextCleaner$$keepCleaning(ContextCleaner.scala:172)
	at org.apache.spark.ContextCleaner$$anon$1.run(ContextCleaner.scala:67)
Caused by: java.io.IOException: Connection reset by peer
	at sun.nio.ch.FileDispatcherImpl.read0(Native Method)
	at sun.nio.ch.SocketDispatcher.read(SocketDispatcher.java:39)
	at sun.nio.ch.IOUtil.readIntoNativeBuffer(IOUtil.java:223)
	at sun.nio.ch.IOUtil.read(IOUtil.java:192)
	at sun.nio.ch.SocketChannelImpl.read(SocketChannelImpl.java:380)
	at io.netty.buffer.PooledUnsafeDirectByteBuf.setBytes(PooledUnsafeDirectByteBuf.java:313)
	at io.netty.buffer.AbstractByteBuf.writeBytes(AbstractByteBuf.java:881)
	at io.netty.channel.socket.nio.NioSocketChannel.doReadBytes(NioSocketChannel.java:242)
	at io.netty.channel.nio.AbstractNioByteChannel$NioByteUnsafe.read(AbstractNioByteChannel.java:119)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:511)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
                                                                                [Stage 93:=======================================================>(96 + 1) / 97]                                                                                Time elapsed: 52.765991582 seconds
res95: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 20 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 20 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.075639765 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 94:===================================================>    (88 + 8) / 96][Stage 94:=======================================================>(95 + 1) / 96]                                                                                [Stage 95:=======================================================>(96 + 1) / 97]                                                                                Time elapsed: 16.080732244 seconds
res97: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 139 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 139 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052756293 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.774155769 seconds
res99: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 104 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 104 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049714499 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 98:=======================================================>(96 + 1) / 97]                                                                                [Stage 99:=======================================================>(97 + 1) / 98]                                                                                Time elapsed: 17.131058892 seconds
res101: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 253 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 253 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.067606744 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 100:======================================================>(94 + 1) / 95]17/06/10 03:50:39 ERROR TaskSchedulerImpl: Lost executor 14 on 128.110.152.155: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:50:39 WARN TaskSetManager: Lost task 76.0 in stage 100.0 (TID 10384, 128.110.152.155): ExecutorLostFailure (executor 14 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 101:=================================================>     (87 + 9) / 96]                                                                                Time elapsed: 17.280264007 seconds
res103: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 119 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 119 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.06037172 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 102:======================================================>(96 + 1) / 97]17/06/10 03:51:29 ERROR TaskSchedulerImpl: Lost executor 5 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:51:29 WARN TaskSetManager: Lost task 31.0 in stage 102.0 (TID 10531, 128.110.152.168): ExecutorLostFailure (executor 5 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:51:29 ERROR TaskSchedulerImpl: Lost executor 19 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:51:29 WARN TaskSetManager: Lost task 31.1 in stage 102.0 (TID 10597, 128.110.152.141): ExecutorLostFailure (executor 19 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 103:============================================>         (81 + 17) / 98]17/06/10 03:51:38 ERROR TaskSchedulerImpl: Lost executor 4 on 128.110.152.144: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:51:38 WARN TaskSetManager: Lost task 31.0 in stage 103.0 (TID 10630, 128.110.152.144): ExecutorLostFailure (executor 4 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 103:======================================================>(97 + 1) / 98]                                                                                Time elapsed: 55.137500077 seconds
res105: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 189 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 189 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.067834109 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 104:==================================================>    (87 + 8) / 95]                                                                                Time elapsed: 5.77060652 seconds
res107: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 225 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 225 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048485866 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.892735918 seconds
res109: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 174 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 174 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058287128 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 108:======================================================>(96 + 1) / 97]                                                                                [Stage 109:======================================================>(97 + 1) / 98]                                                                                Time elapsed: 15.916521334 seconds
res111: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 18 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 18 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057177731 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 110:======================================================>(96 + 1) / 97]                                                                                [Stage 111:======================================================>(97 + 1) / 98]                                                                                Time elapsed: 12.018673792 seconds
res113: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 185 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 185 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.076682214 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.685724119 seconds
res115: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 40 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 40 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050511444 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 114:======================================================>(95 + 1) / 96]                                                                                [Stage 115:======================================================>(96 + 1) / 97]                                                                                Time elapsed: 13.6110454 seconds
res117: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 222 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 222 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.059253189 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 116:======================================================>(95 + 1) / 96]                                                                                [Stage 117:======================================================>(96 + 1) / 97]17/06/10 03:53:02 ERROR TaskSchedulerImpl: Lost executor 20 on 128.110.152.146: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:53:02 WARN TaskSetManager: Lost task 72.0 in stage 117.0 (TID 12026, 128.110.152.146): ExecutorLostFailure (executor 20 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 16.570074037 seconds
res119: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 53 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 53 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.064316221 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 118:=================================================>     (87 + 9) / 96][Stage 118:======================================================>(95 + 1) / 96]                                                                                [Stage 119:======================================================>(96 + 1) / 97]                                                                                Time elapsed: 15.469728178 seconds
res121: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 157 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 157 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.060688288 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.827178553 seconds
res123: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 195 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 195 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058236953 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.735279245 seconds
res125: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 248 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 248 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045546156 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 124:======================================================>(95 + 1) / 96]                                                                                [Stage 125:======================================================>(96 + 1) / 97]                                                                                Time elapsed: 12.20154454 seconds
res127: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 128 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 128 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.071752169 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 126:======================================================>(96 + 1) / 97]                                                                                [Stage 127:======================================================>(97 + 1) / 98]                                                                                Time elapsed: 17.130793734 seconds
res129: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 97 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 97 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054360621 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.574768959 seconds
res131: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 140 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 140 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048214033 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 130:======================================================>(96 + 1) / 97]                                                                                [Stage 131:======================================================>(97 + 1) / 98]                                                                                Time elapsed: 17.817328598 seconds
res133: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 146 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 146 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048540393 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 132:======================================================>(96 + 1) / 97]                                                                                [Stage 133:======================================================>(97 + 1) / 98]                                                                                Time elapsed: 16.40138059 seconds
res135: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 199 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 199 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.07300567 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.564309899 seconds
res137: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 82 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 82 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055407081 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.508532539 seconds
res139: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 121 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 121 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048933793 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 138:======================================================>(95 + 1) / 96]                                                                                [Stage 139:======================================================>(96 + 1) / 97]                                                                                Time elapsed: 14.005440084 seconds
res141: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 251 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 251 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047023558 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.557876841 seconds
res143: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 162 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 162 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050387172 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 142:======================================================>(95 + 1) / 96]                                                                                [Stage 143:======================================================>(96 + 1) / 97]                                                                                Time elapsed: 13.072839979 seconds
res145: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 64 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 64 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.060493734 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 144:======================================================>(95 + 1) / 96]                                                                                [Stage 145:======================================================>(96 + 1) / 97]                                                                                Time elapsed: 10.176803004 seconds
res147: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 85 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 85 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05178251 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 146:======================================================>(96 + 1) / 97]                                                                                [Stage 147:======================================================>(97 + 1) / 98]                                                                                Time elapsed: 14.016473856 seconds
res149: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 164 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 164 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050271814 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 148:======================================================>(95 + 1) / 96]17/06/10 03:56:02 ERROR TaskSchedulerImpl: Lost executor 25 on 128.110.152.146: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:56:02 WARN TaskSetManager: Lost task 52.0 in stage 148.0 (TID 15007, 128.110.152.146): ExecutorLostFailure (executor 25 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:56:12 ERROR TaskSchedulerImpl: Lost executor 21 on 128.110.152.155: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:56:12 WARN TaskSetManager: Lost task 52.1 in stage 148.0 (TID 15051, 128.110.152.155): ExecutorLostFailure (executor 21 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 149:=================================================>     (88 + 9) / 97][Stage 149:======================================================>(96 + 1) / 97]                                                                                Time elapsed: 39.613381446 seconds
res151: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 168 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 168 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.069662544 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.797451062 seconds
res153: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 123 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 123 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.06573755 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.725110206 seconds
res155: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 100 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 100 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052322133 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 154:======================================================>(95 + 1) / 96]                                                                                [Stage 155:======================================================>(96 + 1) / 97]                                                                                Time elapsed: 15.586455267 seconds
res157: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 39 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 39 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051824734 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 156:======================================================>(96 + 1) / 97]                                                                                [Stage 157:======================================================>(97 + 1) / 98]                                                                                Time elapsed: 11.269186453 seconds
res159: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 252 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 252 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050824516 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 158:>                                                       (0 + 0) / 95][Stage 158:======================================================>(94 + 1) / 95]                                                                                [Stage 159:======================================================>(95 + 1) / 96]                                                                                Time elapsed: 11.040693856 seconds
res161: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 203 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 203 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056605427 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 160:======================================================>(96 + 1) / 97]                                                                                [Stage 161:======================================================>(97 + 1) / 98]                                                                                Time elapsed: 16.139059503 seconds
res163: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 184 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 184 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.060635041 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.64851685 seconds
res165: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 117 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 117 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046053085 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 164:======================================================>(95 + 1) / 96]17/06/10 03:57:54 ERROR TaskSchedulerImpl: Lost executor 16 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:57:54 WARN TaskSetManager: Lost task 37.0 in stage 164.0 (TID 16538, 128.110.152.145): ExecutorLostFailure (executor 16 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 165:=================================================>     (88 + 9) / 97][Stage 165:======================================================>(96 + 1) / 97]                                                                                Time elapsed: 20.834215695 seconds
res167: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 250 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 250 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048128603 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 166:======================================================>(96 + 1) / 97]                                                                                [Stage 167:======================================================>(97 + 1) / 98]                                                                                Time elapsed: 11.117224271 seconds
res169: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 178 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 178 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047837685 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 168:======================================================>(96 + 1) / 97]                                                                                [Stage 169:======================================================>(97 + 1) / 98]17/06/10 03:58:33 ERROR TaskSchedulerImpl: Lost executor 0 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:58:33 WARN TaskSetManager: Lost task 57.0 in stage 169.0 (TID 17044, 128.110.152.142): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 18.23032908 seconds
res171: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 57 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 57 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049519243 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 170:=================================================>     (88 + 9) / 97][Stage 170:======================================================>(96 + 1) / 97]                                                                                [Stage 171:======================================================>(97 + 1) / 98]                                                                                Time elapsed: 14.779001819 seconds
res173: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 15 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 15 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.060086827 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 172:=====================================================> (95 + 2) / 97][Stage 172:======================================================>(96 + 1) / 97]                                                                                [Stage 173:=====================================================> (96 + 2) / 98][Stage 173:======================================================>(97 + 1) / 98]                                                                                Time elapsed: 11.584143783 seconds
res175: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 77 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 77 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.061613565 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.771435209 seconds
res177: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 197 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 197 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042154275 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 176:======================================================>(95 + 1) / 96]                                                                                [Stage 177:======================================================>(96 + 1) / 97]                                                                                Time elapsed: 13.619106507 seconds
res179: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 115 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 115 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049144565 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 178:======================================================>(96 + 1) / 97]                                                                                [Stage 179:======================================================>(97 + 1) / 98]17/06/10 03:59:50 ERROR TaskSchedulerImpl: Lost executor 26 on 128.110.152.146: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 03:59:50 WARN TaskSetManager: Lost task 31.0 in stage 179.0 (TID 17990, 128.110.152.146): ExecutorLostFailure (executor 26 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 25.347459889 seconds
res181: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 113 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 113 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057250894 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 180:=================================================>     (87 + 9) / 96][Stage 180:======================================================>(95 + 1) / 96]                                                                                [Stage 181:=================================================>     (88 + 9) / 97][Stage 181:==================================================>    (89 + 8) / 97][Stage 181:==================================================>    (89 + 8) / 97][Stage 181:==================================================>    (89 + 8) / 97]17/06/10 04:02:18 ERROR TaskSchedulerImpl: Lost executor 22 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:02:18 WARN TaskSetManager: Lost task 88.0 in stage 181.0 (TID 18242, 128.110.152.168): ExecutorLostFailure (executor 22 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:02:18 WARN TaskSetManager: Lost task 64.0 in stage 181.0 (TID 18218, 128.110.152.168): ExecutorLostFailure (executor 22 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:02:18 WARN TaskSetManager: Lost task 28.0 in stage 181.0 (TID 18182, 128.110.152.168): ExecutorLostFailure (executor 22 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:02:18 WARN TaskSetManager: Lost task 40.0 in stage 181.0 (TID 18194, 128.110.152.168): ExecutorLostFailure (executor 22 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:02:18 WARN TaskSetManager: Lost task 4.0 in stage 181.0 (TID 18158, 128.110.152.168): ExecutorLostFailure (executor 22 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:02:18 WARN TaskSetManager: Lost task 76.0 in stage 181.0 (TID 18230, 128.110.152.168): ExecutorLostFailure (executor 22 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:02:18 WARN TaskSetManager: Lost task 16.0 in stage 181.0 (TID 18170, 128.110.152.168): ExecutorLostFailure (executor 22 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:02:18 WARN TaskSetManager: Lost task 52.0 in stage 181.0 (TID 18206, 128.110.152.168): ExecutorLostFailure (executor 22 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 138.210974529 seconds
res183: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 118 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 118 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.08574862 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 182:======================================================>(87 + 1) / 88]                                                                                [Stage 183:==================================================>    (81 + 8) / 89][Stage 183:======================================================>(88 + 1) / 89]                                                                                Time elapsed: 14.381298354 seconds
res185: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 50 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 50 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046691955 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 184:======================================================>(96 + 1) / 97]                                                                                [Stage 185:======================================================>(97 + 1) / 98]                                                                                Time elapsed: 11.527989465 seconds
res187: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 133 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 133 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057354382 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 186:======================================================>(95 + 1) / 96]                                                                                [Stage 187:======================================================>(96 + 1) / 97]                                                                                Time elapsed: 13.741562624 seconds
res189: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 249 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 249 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.043424401 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.665612258 seconds
res191: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 59 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 59 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042043643 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 190:======================================================>(95 + 1) / 96]                                                                                [Stage 191:======================================================>(96 + 1) / 97]                                                                                Time elapsed: 16.04231312 seconds
res193: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 235 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 235 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045690219 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 192:======================================================>(95 + 1) / 96]                                                                                [Stage 193:======================================================>(96 + 1) / 97]                                                                                Time elapsed: 11.125661956 seconds
res195: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 136 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 136 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.056956904 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.596977667 seconds
res197: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 2 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 2 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042900883 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 196:=====================================================> (94 + 2) / 96][Stage 196:======================================================>(95 + 1) / 96]                                                                                [Stage 197:=====================================================> (95 + 2) / 97][Stage 197:======================================================>(96 + 1) / 97]                                                                                Time elapsed: 7.571707622 seconds
res199: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.R10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.R10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 76 ", 1))
queries: List[(String, Int)] = List(("SELECT imageBytes FROM data WHERE  partitionIndex = 76 ",1))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05256147 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 198:======================================================>(95 + 1) / 96]                                                                                [Stage 199:======================================================>(96 + 1) / 97]                                                                                Time elapsed: 14.671673857 seconds
res201: Int = 0

scala> 

scala> :quit
