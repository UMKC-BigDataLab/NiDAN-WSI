Using Spark's default log4j profile: org/apache/spark/log4j-defaults.properties
Setting default log level to "WARN".
To adjust logging level use sc.setLogLevel(newLevel).
17/06/10 04:58:04 WARN NativeCodeLoader: Unable to load native-hadoop library for your platform... using builtin-java classes where applicable
17/06/10 04:58:07 WARN SparkContext: Use an existing SparkContext, some configuration may not take effect.
Spark context Web UI available at http://128.110.152.156:4040
Spark context available as 'sc' (master = spark://ctl:7077, app id = app-20170610045806-0060).
Spark session available as 'spark'.
Welcome to
      ____              __
     / __/__  ___ _____/ /__
    _\ \/ _ \/ _ `/ __/  '_/
   /___/ .__/\_,_/_/ /_/\_\   version 2.0.2
      /_/
         
Using Scala version 2.11.8 (OpenJDK 64-Bit Server VM, Java 1.8.0_131)
Type in expressions to have them evaluated.
Type :help for more information.

scala>  
     | import java.io.File
import java.io.File

scala> import java.io.FileOutputStream
import java.io.FileOutputStream

scala> import org.apache.spark.sql._
import org.apache.spark.sql._

scala> 

scala> def show_timing[T](proc: => T): T = {
     |     val start=System.nanoTime()
     |     val res = proc
     |     val end = System.nanoTime()
     |     println("Time elapsed: " + (end-start)/1000000000.0 + " seconds")
     |     res
     | }
show_timing: [T](proc: => T)T

scala> 

scala> val writeToLocal = (in:(Array[Byte], Long, String)) =>{
     |     val bytes = in._1
     |     val output = in._3
     |     
     |     val writer = new FileOutputStream(output)
     |     writer.write(bytes)
     |     writer.close
     |     1
     |   }
writeToLocal: ((Array[Byte], Long, String)) => Int = <function1>

scala> 

scala> val sqlContext = new org.apache.spark.sql.hive.HiveContext(sc)
warning: there was one deprecation warning; re-run with -deprecation for details
sqlContext: org.apache.spark.sql.hive.HiveContext = org.apache.spark.sql.hive.HiveContext@74cd798f

scala>   
     | val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=62 AND partitionZIndex<=63", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=62 AND partitionZIndex<=63,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 15.56609016 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 0:>                                                         (0 + 0) / 73][Stage 0:>                                                        (0 + 72) / 73][Stage 0:==========================================>             (55 + 18) / 73][Stage 0:======================================================>  (70 + 3) / 73][Stage 0:=======================================================> (71 + 2) / 73][Stage 0:========================================================>(72 + 1) / 73]                                                                                [Stage 1:======================================================>  (71 + 3) / 74][Stage 1:=======================================================> (72 + 2) / 74][Stage 1:========================================================>(73 + 1) / 74]17/06/10 04:59:05 ERROR TaskSchedulerImpl: Lost executor 6 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 04:59:06 WARN TaskSetManager: Lost task 27.0 in stage 1.0 (TID 100, 128.110.152.141): ExecutorLostFailure (executor 6 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 34.102949332 seconds
res3: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=115 AND partitionZIndex<=116", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=115 AND partitionZIndex<=116,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.130012703 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 2:=================================================>       (63 + 9) / 72][Stage 2:=======================================================> (70 + 2) / 72][Stage 2:========================================================>(71 + 1) / 72]                                                                                [Stage 3:=======================================================> (71 + 2) / 73][Stage 3:========================================================>(72 + 1) / 73]                                                                                Time elapsed: 22.184233451 seconds
res5: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=13 AND partitionZIndex<=14", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=13 AND partitionZIndex<=14,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.132824659 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 4:=======================================================> (70 + 2) / 72][Stage 4:========================================================>(71 + 1) / 72]                                                                                [Stage 5:=======================================================> (71 + 2) / 73][Stage 5:========================================================>(72 + 1) / 73]                                                                                Time elapsed: 12.832277102 seconds
res7: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=189 AND partitionZIndex<=190", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=189 AND partitionZIndex<=190,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.128129231 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 1.432800888 seconds
res9: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=20 AND partitionZIndex<=21", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=20 AND partitionZIndex<=21,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.100828212 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 8:========================================================>(71 + 1) / 72]                                                                                [Stage 9:========================================================>(72 + 1) / 73]                                                                                Time elapsed: 12.432921701 seconds
res11: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=181 AND partitionZIndex<=182", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=181 AND partitionZIndex<=182,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.091965353 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 10:=====================================================>  (69 + 3) / 72][Stage 10:======================================================> (70 + 2) / 72][Stage 10:=======================================================>(71 + 1) / 72]                                                                                [Stage 11:=====================================================>  (70 + 3) / 73][Stage 11:======================================================> (71 + 2) / 73][Stage 11:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 17.223678615 seconds
res13: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=212 AND partitionZIndex<=213", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=212 AND partitionZIndex<=213,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.096022645 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 1.131044892 seconds
res15: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=89 AND partitionZIndex<=90", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=89 AND partitionZIndex<=90,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.12060621 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 14:=====================================================>  (69 + 3) / 72][Stage 14:======================================================> (70 + 2) / 72][Stage 14:=======================================================>(71 + 1) / 72]                                                                                [Stage 15:=====================================================>  (70 + 3) / 73][Stage 15:======================================================> (71 + 2) / 73][Stage 15:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 17.008035908 seconds
res17: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=88 AND partitionZIndex<=89", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=88 AND partitionZIndex<=89,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.075979792 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 16:=====================================================>  (69 + 3) / 72][Stage 16:======================================================> (70 + 2) / 72][Stage 16:=======================================================>(71 + 1) / 72]                                                                                [Stage 17:=====================================================>  (70 + 3) / 73][Stage 17:======================================================> (71 + 2) / 73][Stage 17:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 18.944443867 seconds
res19: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=110 AND partitionZIndex<=111", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=110 AND partitionZIndex<=111,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.087213407 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 18:======================================================> (70 + 2) / 72][Stage 18:=======================================================>(71 + 1) / 72]                                                                                17/06/10 05:01:36 ERROR TaskSchedulerImpl: Lost executor 9 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:01:36 WARN TaskSetManager: Lost task 9.0 in stage 19.0 (TID 1389, 128.110.152.141): ExecutorLostFailure (executor 9 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 19:======================================================> (71 + 2) / 73][Stage 19:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 17.455467231 seconds
res21: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=84 AND partitionZIndex<=85", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=84 AND partitionZIndex<=85,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.073547158 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 20:=================================================>      (64 + 8) / 72]                                                                                Time elapsed: 5.847101928 seconds
res23: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=30 AND partitionZIndex<=31", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=30 AND partitionZIndex<=31,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.073956558 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 22:======================================================> (70 + 2) / 72][Stage 22:=======================================================>(71 + 1) / 72]                                                                                [Stage 23:======================================================> (71 + 2) / 73][Stage 23:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 15.194954527 seconds
res25: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=97 AND partitionZIndex<=98", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=97 AND partitionZIndex<=98,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.074623136 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.788926153 seconds
res27: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=149 AND partitionZIndex<=150", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=149 AND partitionZIndex<=150,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.06389762 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 26:=================================================>      (64 + 8) / 72]                                                                                Time elapsed: 3.102408813 seconds
res29: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=126 AND partitionZIndex<=127", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=126 AND partitionZIndex<=127,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.074189518 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 28:=========================>                             (34 + 38) / 72][Stage 28:==========================>                            (35 + 37) / 72][Stage 28:===========================>                           (36 + 36) / 72][Stage 28:============================>                          (37 + 35) / 72][Stage 28:=============================>                         (38 + 34) / 72][Stage 28:=============================>                         (39 + 33) / 72][Stage 28:==============================>                        (40 + 32) / 72][Stage 28:===============================>                       (41 + 31) / 72][Stage 28:================================>                      (42 + 30) / 72][Stage 28:===================================>                   (47 + 25) / 72][Stage 28:====================================>                  (48 + 24) / 72][Stage 28:=====================================>                 (49 + 23) / 72][Stage 28:======================================>                (50 + 22) / 72][Stage 28:======================================>                (51 + 21) / 72][Stage 28:=======================================>               (52 + 20) / 72][Stage 28:========================================>              (53 + 19) / 72][Stage 28:=========================================>             (54 + 18) / 72][Stage 28:==========================================>            (55 + 17) / 72][Stage 28:==========================================>            (56 + 16) / 72][Stage 28:===========================================>           (57 + 15) / 72][Stage 28:============================================>          (58 + 14) / 72][Stage 28:=============================================>         (59 + 13) / 72][Stage 28:=============================================>         (60 + 12) / 72][Stage 28:==============================================>        (61 + 11) / 72][Stage 28:=================================================>      (63 + 9) / 72][Stage 28:=================================================>      (63 + 9) / 72][Stage 28:=======================================================>(71 + 1) / 72]                                                                                [Stage 29:==============================>                        (41 + 32) / 73][Stage 29:===============================>                       (42 + 31) / 73][Stage 29:================================>                      (43 + 30) / 73][Stage 29:=================================>                     (44 + 29) / 73][Stage 29:==================================>                    (46 + 27) / 73][Stage 29:===================================>                   (47 + 26) / 73][Stage 29:====================================>                  (49 + 24) / 73][Stage 29:=====================================>                 (50 + 23) / 73][Stage 29:======================================>                (51 + 22) / 73][Stage 29:========================================>              (54 + 19) / 73][Stage 29:=========================================>             (55 + 18) / 73][Stage 29:==========================================>            (56 + 17) / 73][Stage 29:==========================================>            (57 + 16) / 73][Stage 29:===========================================>           (58 + 15) / 73][Stage 29:============================================>          (59 + 14) / 73]17/06/10 05:04:45 ERROR TaskSchedulerImpl: Lost executor 8 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:04:45 WARN TaskSetManager: Lost task 59.0 in stage 29.0 (TID 2165, 128.110.152.145): ExecutorLostFailure (executor 8 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:04:45 WARN TaskSetManager: Lost task 50.0 in stage 29.0 (TID 2156, 128.110.152.145): ExecutorLostFailure (executor 8 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:04:45 WARN TaskSetManager: Lost task 23.0 in stage 29.0 (TID 2129, 128.110.152.145): ExecutorLostFailure (executor 8 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:04:45 WARN TaskSetManager: Lost task 14.0 in stage 29.0 (TID 2120, 128.110.152.145): ExecutorLostFailure (executor 8 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:04:45 WARN TaskSetManager: Lost task 5.0 in stage 29.0 (TID 2111, 128.110.152.145): ExecutorLostFailure (executor 8 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:04:45 WARN TaskSetManager: Lost task 41.0 in stage 29.0 (TID 2147, 128.110.152.145): ExecutorLostFailure (executor 8 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:04:45 WARN TaskSetManager: Lost task 32.0 in stage 29.0 (TID 2138, 128.110.152.145): ExecutorLostFailure (executor 8 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:04:45 WARN TaskSetManager: Lost task 68.0 in stage 29.0 (TID 2174, 128.110.152.145): ExecutorLostFailure (executor 8 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 29:=================================================>      (64 + 9) / 73][Stage 29:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 151.520680751 seconds
res31: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=80 AND partitionZIndex<=81", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=80 AND partitionZIndex<=81,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.069179274 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 30:==============================================>        (61 + 11) / 72][Stage 30:======================================================> (70 + 2) / 72][Stage 30:=======================================================>(71 + 1) / 72]                                                                                [Stage 31:=====================================================>  (70 + 3) / 73][Stage 31:======================================================> (71 + 2) / 73][Stage 31:=======================================================>(72 + 1) / 73]17/06/10 05:05:13 ERROR TaskSchedulerImpl: Lost executor 1 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:05:13 WARN TaskSetManager: Lost task 27.0 in stage 31.0 (TID 2286, 128.110.152.142): ExecutorLostFailure (executor 1 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 25.346782345 seconds
res33: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=70 AND partitionZIndex<=71", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=70 AND partitionZIndex<=71,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.060590273 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 32:===============================================>       (63 + 10) / 73][Stage 32:=====================================================>  (70 + 3) / 73][Stage 32:======================================================> (71 + 2) / 73][Stage 32:=======================================================>(72 + 1) / 73]                                                                                [Stage 33:=====================================================>  (71 + 3) / 74][Stage 33:======================================================> (72 + 2) / 74][Stage 33:=======================================================>(73 + 1) / 74]17/06/10 05:05:47 ERROR TaskSchedulerImpl: Lost executor 10 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:05:47 WARN TaskSetManager: Lost task 27.0 in stage 33.0 (TID 2433, 128.110.152.141): ExecutorLostFailure (executor 10 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 29.413670271 seconds
res35: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=198 AND partitionZIndex<=199", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=198 AND partitionZIndex<=199,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.075046164 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 34:=================================================>      (64 + 8) / 72]                                                                                Time elapsed: 5.846432485 seconds
res37: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=135 AND partitionZIndex<=136", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=135 AND partitionZIndex<=136,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.083436086 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.805474064 seconds
res39: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=233 AND partitionZIndex<=234", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=233 AND partitionZIndex<=234,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.072508889 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 38:======================================================> (70 + 2) / 72][Stage 38:=======================================================>(71 + 1) / 72]                                                                                [Stage 39:======================================================> (71 + 2) / 73][Stage 39:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 13.142890384 seconds
res41: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=72 AND partitionZIndex<=73", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=72 AND partitionZIndex<=73,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.072735489 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.702993804 seconds
res43: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=232 AND partitionZIndex<=233", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=232 AND partitionZIndex<=233,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.062203771 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 42:======================================================> (71 + 2) / 73][Stage 42:=======================================================>(72 + 1) / 73]                                                                                [Stage 43:======================================================> (72 + 2) / 74][Stage 43:=======================================================>(73 + 1) / 74]                                                                                Time elapsed: 13.241179513 seconds
res45: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=208 AND partitionZIndex<=209", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=208 AND partitionZIndex<=209,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058988718 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.63978788 seconds
res47: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=229 AND partitionZIndex<=230", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=229 AND partitionZIndex<=230,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057767901 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 46:======================================================> (70 + 2) / 72][Stage 46:=======================================================>(71 + 1) / 72]                                                                                [Stage 47:======================================================> (71 + 2) / 73][Stage 47:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 12.801102291 seconds
res49: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=247 AND partitionZIndex<=248", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=247 AND partitionZIndex<=248,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.062875491 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 48:=======================================================>(71 + 1) / 72]                                                                                [Stage 49:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 11.047990771 seconds
res51: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=140 AND partitionZIndex<=141", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=140 AND partitionZIndex<=141,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.059429238 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 50:======================================================> (71 + 2) / 73][Stage 50:=======================================================>(72 + 1) / 73]                                                                                [Stage 51:======================================================> (72 + 2) / 74][Stage 51:=======================================================>(73 + 1) / 74]                                                                                Time elapsed: 13.8966407 seconds
res53: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=252 AND partitionZIndex<=253", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=252 AND partitionZIndex<=253,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.060918195 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 52:=======================================================>(71 + 1) / 72]                                                                                [Stage 53:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 11.898894146 seconds
res55: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=158 AND partitionZIndex<=159", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=158 AND partitionZIndex<=159,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.080130777 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 54:======================================================> (70 + 2) / 72][Stage 54:=======================================================>(71 + 1) / 72]17/06/10 05:07:53 ERROR TaskSchedulerImpl: Lost executor 13 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:07:53 WARN TaskSetManager: Lost task 27.0 in stage 54.0 (TID 3962, 128.110.152.141): ExecutorLostFailure (executor 13 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 55:===============================================>       (63 + 10) / 73][Stage 55:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 23.379227118 seconds
res57: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=251 AND partitionZIndex<=252", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=251 AND partitionZIndex<=252,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.062110314 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 56:=======================================================>(71 + 1) / 72]                                                                                [Stage 57:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 13.923080197 seconds
res59: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=96 AND partitionZIndex<=97", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=96 AND partitionZIndex<=97,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.071766036 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.788475091 seconds
res61: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=222 AND partitionZIndex<=223", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=222 AND partitionZIndex<=223,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057292744 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 60:======================================================> (70 + 2) / 72][Stage 60:=======================================================>(71 + 1) / 72]                                                                                [Stage 61:======================================================> (71 + 2) / 73][Stage 61:=======================================================>(72 + 1) / 73]17/06/10 05:08:44 ERROR TaskSchedulerImpl: Lost executor 4 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:08:44 WARN TaskSetManager: Lost task 38.0 in stage 61.0 (TID 4481, 128.110.152.168): ExecutorLostFailure (executor 4 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 24.794245431 seconds
res63: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=146 AND partitionZIndex<=147", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=146 AND partitionZIndex<=147,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.065746008 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 62:>                                                        (0 + 0) / 72][Stage 62:=================================================>      (64 + 8) / 72]                                                                                Time elapsed: 5.780361014 seconds
res65: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=57 AND partitionZIndex<=58", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=57 AND partitionZIndex<=58,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.068498163 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 64:=======================================================>(71 + 1) / 72]                                                                                [Stage 65:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 10.735203969 seconds
res67: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=170 AND partitionZIndex<=171", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=170 AND partitionZIndex<=171,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058574383 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 66:=====================================================>  (69 + 3) / 72][Stage 66:======================================================> (70 + 2) / 72][Stage 66:=======================================================>(71 + 1) / 72]                                                                                [Stage 67:=====================================================>  (70 + 3) / 73]17/06/10 05:09:32 ERROR TaskSchedulerImpl: Lost executor 12 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:09:32 WARN TaskSetManager: Lost task 54.0 in stage 67.0 (TID 4933, 128.110.152.142): ExecutorLostFailure (executor 12 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 67:======================================================> (71 + 2) / 73][Stage 67:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 23.722370027 seconds
res69: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=102 AND partitionZIndex<=103", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=102 AND partitionZIndex<=103,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.087524266 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 68:=================================================>      (64 + 8) / 72]                                                                                Time elapsed: 5.735355403 seconds
res71: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=215 AND partitionZIndex<=216", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=215 AND partitionZIndex<=216,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055005591 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 70:======================================================> (70 + 2) / 72][Stage 70:=======================================================>(71 + 1) / 72]                                                                                [Stage 71:======================================================> (71 + 2) / 73][Stage 71:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 16.934513728 seconds
res73: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=48 AND partitionZIndex<=49", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=48 AND partitionZIndex<=49,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055345591 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 72:=====================================================>  (69 + 3) / 72][Stage 72:======================================================> (70 + 2) / 72][Stage 72:=======================================================>(71 + 1) / 72]                                                                                [Stage 73:=====================================================>  (70 + 3) / 73]17/06/10 05:10:20 ERROR TaskSchedulerImpl: Lost executor 3 on 128.110.152.144: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:10:20 WARN TaskSetManager: Lost task 57.0 in stage 73.0 (TID 5372, 128.110.152.144): ExecutorLostFailure (executor 3 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:10:22 ERROR TaskSchedulerImpl: Lost executor 5 on 128.110.152.157: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:10:22 WARN TaskSetManager: Lost task 25.0 in stage 73.0 (TID 5340, 128.110.152.157): ExecutorLostFailure (executor 5 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:10:23 ERROR TaskSchedulerImpl: Lost executor 14 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:10:23 WARN TaskSetManager: Lost task 42.0 in stage 73.0 (TID 5357, 128.110.152.141): ExecutorLostFailure (executor 14 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 73:======================================================> (71 + 2) / 73][Stage 73:=======================================================>(72 + 1) / 73]17/06/10 05:10:30 ERROR TaskSchedulerImpl: Lost executor 0 on 128.110.152.165: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:10:30 WARN TaskSetManager: Lost task 25.1 in stage 73.0 (TID 5389, 128.110.152.165): ExecutorLostFailure (executor 0 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 28.733978166 seconds
res75: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=195 AND partitionZIndex<=196", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=195 AND partitionZIndex<=196,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053365076 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 74:==============================>                        (40 + 32) / 72][Stage 74:=================================================>      (64 + 8) / 72]                                                                                Time elapsed: 5.876448573 seconds
res77: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=16 AND partitionZIndex<=17", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=16 AND partitionZIndex<=17,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049574163 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 76:=====================================================>  (69 + 3) / 72][Stage 76:======================================================> (70 + 2) / 72][Stage 76:=======================================================>(71 + 1) / 72]                                                                                [Stage 77:=====================================================>  (70 + 3) / 73][Stage 77:======================================================> (71 + 2) / 73][Stage 77:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 13.087242762 seconds
res79: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=18 AND partitionZIndex<=19", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=18 AND partitionZIndex<=19,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.058895005 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 78:=======================================================>(71 + 1) / 72]                                                                                [Stage 79:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 11.606346942 seconds
res81: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=177 AND partitionZIndex<=178", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=177 AND partitionZIndex<=178,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.065500793 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 80:=====================================================>  (70 + 3) / 73][Stage 80:======================================================> (71 + 2) / 73][Stage 80:=======================================================>(72 + 1) / 73]                                                                                [Stage 81:=====================================================>  (71 + 3) / 74]17/06/10 05:11:31 ERROR TaskSchedulerImpl: Lost executor 11 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:11:31 WARN TaskSetManager: Lost task 56.0 in stage 81.0 (TID 5956, 128.110.152.145): ExecutorLostFailure (executor 11 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 81:======================================================> (72 + 2) / 74][Stage 81:=======================================================>(73 + 1) / 74]                                                                                Time elapsed: 18.397003621 seconds
res83: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=152 AND partitionZIndex<=153", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=152 AND partitionZIndex<=153,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057240509 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 82:=================================================>      (63 + 9) / 72][Stage 82:======================================================> (70 + 2) / 72][Stage 82:=======================================================>(71 + 1) / 72]                                                                                [Stage 83:======================================================> (71 + 2) / 73]                                                                                Time elapsed: 19.455463407 seconds
res85: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=162 AND partitionZIndex<=163", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=162 AND partitionZIndex<=163,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054139896 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.69229203 seconds
res87: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=225 AND partitionZIndex<=226", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=225 AND partitionZIndex<=226,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049449425 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.860654567 seconds
res89: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=119 AND partitionZIndex<=120", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=119 AND partitionZIndex<=120,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051075342 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 88:======================================================> (70 + 2) / 72][Stage 88:=======================================================>(71 + 1) / 72]17/06/10 05:12:13 ERROR TaskSchedulerImpl: Lost executor 19 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:12:13 WARN TaskSetManager: Lost task 27.0 in stage 88.0 (TID 6437, 128.110.152.141): ExecutorLostFailure (executor 19 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 89:===============================================>       (63 + 10) / 73][Stage 89:======================================================> (71 + 2) / 73][Stage 89:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 22.219630889 seconds
res91: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=101 AND partitionZIndex<=102", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=101 AND partitionZIndex<=102,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051075683 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.715061975 seconds
res93: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=238 AND partitionZIndex<=239", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=238 AND partitionZIndex<=239,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051338382 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 92:======================================================> (70 + 2) / 72][Stage 92:=======================================================>(71 + 1) / 72]                                                                                [Stage 93:======================================================> (71 + 2) / 73][Stage 93:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 16.697403957 seconds
res95: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=24 AND partitionZIndex<=25", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=24 AND partitionZIndex<=25,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055139555 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 94:=======================================================>(71 + 1) / 72]                                                                                [Stage 95:=======================================================>(72 + 1) / 73]                                                                                Time elapsed: 13.826805685 seconds
res97: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=141 AND partitionZIndex<=142", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=141 AND partitionZIndex<=142,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.061870363 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.633324801 seconds
res99: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=155 AND partitionZIndex<=156", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=155 AND partitionZIndex<=156,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.049550646 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.600031704 seconds
res101: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=148 AND partitionZIndex<=149", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=148 AND partitionZIndex<=149,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048746867 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 100:=====================================================> (70 + 2) / 72][Stage 100:======================================================>(71 + 1) / 72]                                                                                [Stage 101:=====================================================> (71 + 2) / 73][Stage 101:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 14.367704289 seconds
res103: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=244 AND partitionZIndex<=245", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=244 AND partitionZIndex<=245,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.07990721 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.533747295 seconds
res105: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=142 AND partitionZIndex<=143", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=142 AND partitionZIndex<=143,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047261511 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 104:=====================================================> (70 + 2) / 72][Stage 104:======================================================>(71 + 1) / 72]                                                                                [Stage 105:=====================================================> (71 + 2) / 73][Stage 105:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 14.725750009 seconds
res107: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=127 AND partitionZIndex<=128", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=127 AND partitionZIndex<=128,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050666345 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 106:======================================================>(71 + 1) / 72]                                                                                [Stage 107:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 14.826798483 seconds
res109: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=219 AND partitionZIndex<=220", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=219 AND partitionZIndex<=220,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054128179 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 108:=====================================================> (71 + 2) / 73][Stage 108:======================================================>(72 + 1) / 73]17/06/10 05:14:12 ERROR TaskSchedulerImpl: Lost executor 21 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:14:12 WARN TaskSetManager: Lost task 56.0 in stage 108.0 (TID 7917, 128.110.152.145): ExecutorLostFailure (executor 21 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 109:==============================================>       (64 + 10) / 74][Stage 109:================================================>      (65 + 9) / 74][Stage 109:======================================================>(73 + 1) / 74]                                                                                Time elapsed: 19.322815313 seconds
res111: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=100 AND partitionZIndex<=101", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=100 AND partitionZIndex<=101,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.061179706 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.738944605 seconds
res113: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=157 AND partitionZIndex<=158", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=157 AND partitionZIndex<=158,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051700804 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 112:=====================================================> (71 + 2) / 73][Stage 112:======================================================>(72 + 1) / 73]                                                                                [Stage 113:=====================================================> (72 + 2) / 74][Stage 113:======================================================>(73 + 1) / 74]                                                                                Time elapsed: 14.615495845 seconds
res115: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=114 AND partitionZIndex<=115", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=114 AND partitionZIndex<=115,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048078011 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.647205041 seconds
res117: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=199 AND partitionZIndex<=200", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=199 AND partitionZIndex<=200,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055323717 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 116:====================================================>  (69 + 3) / 72][Stage 116:=====================================================> (70 + 2) / 72][Stage 116:======================================================>(71 + 1) / 72]                                                                                [Stage 117:=============================================>        (62 + 11) / 73][Stage 117:==============================================>       (63 + 10) / 73][Stage 117:================================================>      (64 + 9) / 73]17/06/10 05:15:12 ERROR TaskSchedulerImpl: Lost executor 17 on 128.110.152.144: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:15:12 WARN TaskSetManager: Lost task 38.0 in stage 117.0 (TID 8556, 128.110.152.144): ExecutorLostFailure (executor 17 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:15:13 ERROR TaskSchedulerImpl: Lost executor 15 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:15:13 WARN TaskSetManager: Lost task 38.1 in stage 117.0 (TID 8591, 128.110.152.168): ExecutorLostFailure (executor 15 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 117:================================================>      (65 + 8) / 73][Stage 117:================================================>      (65 + 8) / 73][Stage 117:================================================>      (65 + 8) / 73][Stage 117:================================================>      (65 + 8) / 73][Stage 117:================================================>      (65 + 8) / 73][Stage 117:================================================>      (65 + 8) / 73][Stage 117:================================================>      (65 + 8) / 73][Stage 117:================================================>      (65 + 8) / 73][Stage 117:================================================>      (65 + 8) / 73][Stage 117:================================================>      (65 + 8) / 73]17/06/10 05:24:35 ERROR TaskSchedulerImpl: Lost executor 22 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:24:35 WARN TaskSetManager: Lost task 70.0 in stage 117.0 (TID 8588, 128.110.152.141): ExecutorLostFailure (executor 22 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:24:35 WARN TaskSetManager: Lost task 61.0 in stage 117.0 (TID 8579, 128.110.152.141): ExecutorLostFailure (executor 22 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:24:35 WARN TaskSetManager: Lost task 52.0 in stage 117.0 (TID 8570, 128.110.152.141): ExecutorLostFailure (executor 22 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:24:35 WARN TaskSetManager: Lost task 43.0 in stage 117.0 (TID 8561, 128.110.152.141): ExecutorLostFailure (executor 22 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:24:35 WARN TaskSetManager: Lost task 16.0 in stage 117.0 (TID 8534, 128.110.152.141): ExecutorLostFailure (executor 22 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:24:35 WARN TaskSetManager: Lost task 7.0 in stage 117.0 (TID 8525, 128.110.152.141): ExecutorLostFailure (executor 22 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:24:35 WARN TaskSetManager: Lost task 25.0 in stage 117.0 (TID 8543, 128.110.152.141): ExecutorLostFailure (executor 22 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:24:35 WARN TaskSetManager: Lost task 34.0 in stage 117.0 (TID 8552, 128.110.152.141): ExecutorLostFailure (executor 22 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:24:35 ERROR TransportResponseHandler: Still have 1 requests outstanding when connection from /128.110.152.141:34694 is closed
17/06/10 05:24:35 WARN BlockManagerMaster: Failed to remove broadcast 175 with removeFromMaster = true - Connection from /128.110.152.141:34694 closed
java.io.IOException: Connection from /128.110.152.141:34694 closed
	at org.apache.spark.network.client.TransportResponseHandler.channelInactive(TransportResponseHandler.java:128)
	at org.apache.spark.network.server.TransportChannelHandler.channelInactive(TransportChannelHandler.java:109)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at io.netty.handler.timeout.IdleStateHandler.channelInactive(IdleStateHandler.java:257)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at org.apache.spark.network.util.TransportFrameDecoder.channelInactive(TransportFrameDecoder.java:182)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.DefaultChannelPipeline.fireChannelInactive(DefaultChannelPipeline.java:828)
	at io.netty.channel.AbstractChannel$AbstractUnsafe$7.run(AbstractChannel.java:621)
	at io.netty.util.concurrent.SingleThreadEventExecutor.runAllTasks(SingleThreadEventExecutor.java:357)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:357)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 05:24:35 ERROR ContextCleaner: Error cleaning broadcast 175
org.apache.spark.SparkException: Exception thrown in awaitResult
	at org.apache.spark.rpc.RpcTimeout$$anonfun$1.applyOrElse(RpcTimeout.scala:77)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$1.applyOrElse(RpcTimeout.scala:75)
	at scala.runtime.AbstractPartialFunction.apply(AbstractPartialFunction.scala:36)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$addMessageIfTimeout$1.applyOrElse(RpcTimeout.scala:59)
	at org.apache.spark.rpc.RpcTimeout$$anonfun$addMessageIfTimeout$1.applyOrElse(RpcTimeout.scala:59)
	at scala.PartialFunction$OrElse.apply(PartialFunction.scala:167)
	at org.apache.spark.rpc.RpcTimeout.awaitResult(RpcTimeout.scala:83)
	at org.apache.spark.storage.BlockManagerMaster.removeBroadcast(BlockManagerMaster.scala:143)
	at org.apache.spark.broadcast.TorrentBroadcast$.unpersist(TorrentBroadcast.scala:267)
	at org.apache.spark.broadcast.TorrentBroadcastFactory.unbroadcast(TorrentBroadcastFactory.scala:45)
	at org.apache.spark.broadcast.BroadcastManager.unbroadcast(BroadcastManager.scala:60)
	at org.apache.spark.ContextCleaner.doCleanupBroadcast(ContextCleaner.scala:232)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1$$anonfun$apply$mcV$sp$2.apply(ContextCleaner.scala:188)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1$$anonfun$apply$mcV$sp$2.apply(ContextCleaner.scala:179)
	at scala.Option.foreach(Option.scala:257)
	at org.apache.spark.ContextCleaner$$anonfun$org$apache$spark$ContextCleaner$$keepCleaning$1.apply$mcV$sp(ContextCleaner.scala:179)
	at org.apache.spark.util.Utils$.tryOrStopSparkContext(Utils.scala:1252)
	at org.apache.spark.ContextCleaner.org$apache$spark$ContextCleaner$$keepCleaning(ContextCleaner.scala:172)
	at org.apache.spark.ContextCleaner$$anon$1.run(ContextCleaner.scala:67)
Caused by: java.io.IOException: Connection from /128.110.152.141:34694 closed
	at org.apache.spark.network.client.TransportResponseHandler.channelInactive(TransportResponseHandler.java:128)
	at org.apache.spark.network.server.TransportChannelHandler.channelInactive(TransportChannelHandler.java:109)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at io.netty.handler.timeout.IdleStateHandler.channelInactive(IdleStateHandler.java:257)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.ChannelInboundHandlerAdapter.channelInactive(ChannelInboundHandlerAdapter.java:75)
	at org.apache.spark.network.util.TransportFrameDecoder.channelInactive(TransportFrameDecoder.java:182)
	at io.netty.channel.AbstractChannelHandlerContext.invokeChannelInactive(AbstractChannelHandlerContext.java:208)
	at io.netty.channel.AbstractChannelHandlerContext.fireChannelInactive(AbstractChannelHandlerContext.java:194)
	at io.netty.channel.DefaultChannelPipeline.fireChannelInactive(DefaultChannelPipeline.java:828)
	at io.netty.channel.AbstractChannel$AbstractUnsafe$7.run(AbstractChannel.java:621)
	at io.netty.util.concurrent.SingleThreadEventExecutor.runAllTasks(SingleThreadEventExecutor.java:357)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:357)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
[Stage 117:=====================================================> (71 + 2) / 73]                                                                                Time elapsed: 591.700230976 seconds
res119: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=116 AND partitionZIndex<=117", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=116 AND partitionZIndex<=117,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.066060372 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 118:==============================================>       (62 + 10) / 72][Stage 118:=====================================================> (70 + 2) / 72][Stage 118:======================================================>(71 + 1) / 72]                                                                                [Stage 119:=====================================================> (71 + 2) / 73]                                                                                Time elapsed: 15.757498165 seconds
res121: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=172 AND partitionZIndex<=173", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=172 AND partitionZIndex<=173,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052965114 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 120:====================================================>  (69 + 3) / 72][Stage 120:=====================================================> (70 + 2) / 72][Stage 120:======================================================>(71 + 1) / 72]17/06/10 05:25:09 ERROR TaskSchedulerImpl: Lost executor 2 on 128.110.152.160: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:25:09 WARN TaskSetManager: Lost task 27.0 in stage 120.0 (TID 8773, 128.110.152.160): ExecutorLostFailure (executor 2 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 120:======================================================>(71 + 0) / 72][Stage 120:======================================================>(71 + 1) / 72]                                                                                [Stage 121:==============================================>       (63 + 10) / 73][Stage 121:====================================================>  (70 + 3) / 73][Stage 121:=====================================================> (71 + 2) / 73][Stage 121:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 29.936277455 seconds
res123: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=21 AND partitionZIndex<=22", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=21 AND partitionZIndex<=22,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.054051973 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 122:======================================================>(72 + 1) / 73]                                                                                [Stage 123:======================================================>(73 + 1) / 74]                                                                                Time elapsed: 11.26752624 seconds
res125: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=26 AND partitionZIndex<=27", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=26 AND partitionZIndex<=27,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.051339878 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 124:=====================================================> (70 + 2) / 72][Stage 124:======================================================>(71 + 1) / 72]                                                                                [Stage 125:=====================================================> (71 + 2) / 73][Stage 125:======================================================>(72 + 1) / 73]17/06/10 05:25:58 ERROR TaskSchedulerImpl: Lost executor 26 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:25:58 WARN TaskSetManager: Lost task 25.0 in stage 125.0 (TID 9136, 128.110.152.141): ExecutorLostFailure (executor 26 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 20.975247038 seconds
res127: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=64 AND partitionZIndex<=65", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=64 AND partitionZIndex<=65,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.055863531 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 126:=============================================>        (61 + 11) / 72][Stage 126:====================================================>  (69 + 3) / 72]17/06/10 05:26:16 ERROR TaskSchedulerImpl: Lost executor 7 on 128.110.152.152: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 126:======================================================>(71 + 1) / 72]17/06/10 05:26:16 WARN TaskSetManager: Lost task 12.0 in stage 126.0 (TID 9197, 128.110.152.152): ExecutorLostFailure (executor 7 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                17/06/10 05:26:23 ERROR TaskSchedulerImpl: Lost executor 16 on 128.110.152.142: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:26:23 WARN TaskSetManager: Lost task 0.0 in stage 127.0 (TID 9258, 128.110.152.142): ExecutorLostFailure (executor 16 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:26:23 WARN TaskSetManager: Lost task 27.0 in stage 127.0 (TID 9285, 128.110.152.142): ExecutorLostFailure (executor 16 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 127:=============================================>        (62 + 11) / 73][Stage 127:====================================================>  (70 + 3) / 73][Stage 127:=====================================================> (71 + 2) / 73][Stage 127:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 22.385522327 seconds
res129: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=186 AND partitionZIndex<=187", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=186 AND partitionZIndex<=187,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.06324258 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 128:================================================>      (64 + 8) / 72][Stage 128:======================================================>(71 + 1) / 72]                                                                                Time elapsed: 5.61083 seconds
res131: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=60 AND partitionZIndex<=61", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=60 AND partitionZIndex<=61,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046379706 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 130:======================================================>(71 + 1) / 72]                                                                                [Stage 131:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 10.901775765 seconds
res133: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=56 AND partitionZIndex<=57", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=56 AND partitionZIndex<=57,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047450105 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 132:====================================================>  (69 + 3) / 72][Stage 132:=====================================================> (70 + 2) / 72][Stage 132:======================================================>(71 + 1) / 72]                                                                                [Stage 133:====================================================>  (70 + 3) / 73][Stage 133:=====================================================> (71 + 2) / 73][Stage 133:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 17.653991915 seconds
res135: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=87 AND partitionZIndex<=88", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=87 AND partitionZIndex<=88,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.079767275 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 134:====================================================>  (69 + 3) / 72]17/06/10 05:27:14 ERROR TaskSchedulerImpl: Lost executor 23 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:27:14 WARN TaskSetManager: Lost task 0.0 in stage 134.0 (TID 9768, 128.110.152.145): ExecutorLostFailure (executor 23 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:27:14 WARN TaskSetManager: Lost task 27.0 in stage 134.0 (TID 9795, 128.110.152.145): ExecutorLostFailure (executor 23 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:27:14 WARN TransportChannelHandler: Exception in connection from /128.110.152.168:42264
java.io.IOException: Connection reset by peer
	at sun.nio.ch.FileDispatcherImpl.read0(Native Method)
	at sun.nio.ch.SocketDispatcher.read(SocketDispatcher.java:39)
	at sun.nio.ch.IOUtil.readIntoNativeBuffer(IOUtil.java:223)
	at sun.nio.ch.IOUtil.read(IOUtil.java:192)
	at sun.nio.ch.SocketChannelImpl.read(SocketChannelImpl.java:380)
	at io.netty.buffer.PooledUnsafeDirectByteBuf.setBytes(PooledUnsafeDirectByteBuf.java:313)
	at io.netty.buffer.AbstractByteBuf.writeBytes(AbstractByteBuf.java:881)
	at io.netty.channel.socket.nio.NioSocketChannel.doReadBytes(NioSocketChannel.java:242)
	at io.netty.channel.nio.AbstractNioByteChannel$NioByteUnsafe.read(AbstractNioByteChannel.java:119)
	at io.netty.channel.nio.NioEventLoop.processSelectedKey(NioEventLoop.java:511)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeysOptimized(NioEventLoop.java:468)
	at io.netty.channel.nio.NioEventLoop.processSelectedKeys(NioEventLoop.java:382)
	at io.netty.channel.nio.NioEventLoop.run(NioEventLoop.java:354)
	at io.netty.util.concurrent.SingleThreadEventExecutor$2.run(SingleThreadEventExecutor.java:111)
	at java.lang.Thread.run(Thread.java:748)
17/06/10 05:27:14 ERROR TaskSchedulerImpl: Lost executor 25 on 128.110.152.168: Command exited with code 137
17/06/10 05:27:14 WARN TaskSetManager: Lost task 27.1 in stage 134.0 (TID 9840, 128.110.152.168): ExecutorLostFailure (executor 25 exited caused by one of the running tasks) Reason: Command exited with code 137
17/06/10 05:27:14 WARN TaskSetManager: Lost task 12.0 in stage 134.0 (TID 9780, 128.110.152.168): ExecutorLostFailure (executor 25 exited caused by one of the running tasks) Reason: Command exited with code 137
[Stage 134:=====================================================> (70 + 2) / 72][Stage 134:======================================================>(71 + 1) / 72]                                                                                [Stage 135:========================================>             (55 + 18) / 73][Stage 135:==============================================>       (63 + 10) / 73][Stage 135:====================================================>  (70 + 3) / 73]17/06/10 05:27:29 ERROR TaskSchedulerImpl: Lost executor 28 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:27:29 WARN TaskSetManager: Lost task 0.0 in stage 135.0 (TID 9844, 128.110.152.141): ExecutorLostFailure (executor 28 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:27:29 WARN TaskSetManager: Lost task 27.0 in stage 135.0 (TID 9871, 128.110.152.141): ExecutorLostFailure (executor 28 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 135:=====================================================> (71 + 2) / 73][Stage 135:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 23.756220537 seconds
res137: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=125 AND partitionZIndex<=126", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=125 AND partitionZIndex<=126,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.060805805 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 136:================================================>      (64 + 8) / 72]                                                                                Time elapsed: 5.655721176 seconds
res139: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=94 AND partitionZIndex<=95", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=94 AND partitionZIndex<=95,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048978884 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.769854118 seconds
res141: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=134 AND partitionZIndex<=135", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=134 AND partitionZIndex<=135,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045524169 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.777496646 seconds
res143: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=32 AND partitionZIndex<=33", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=32 AND partitionZIndex<=33,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050357221 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 142:======================================================>(71 + 1) / 72]                                                                                [Stage 143:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 14.484515096 seconds
res145: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=2 AND partitionZIndex<=3", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=2 AND partitionZIndex<=3,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.062147423 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 144:====================================================>  (69 + 3) / 72][Stage 144:=====================================================> (70 + 2) / 72][Stage 144:======================================================>(71 + 1) / 72]                                                                                [Stage 145:====================================================>  (70 + 3) / 73][Stage 145:=====================================================> (71 + 2) / 73][Stage 145:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 10.185313231 seconds
res147: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=105 AND partitionZIndex<=106", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=105 AND partitionZIndex<=106,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050862441 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 146:=====================================================> (70 + 2) / 72][Stage 146:======================================================>(71 + 1) / 72]                                                                                [Stage 147:=====================================================> (71 + 2) / 73][Stage 147:======================================================>(72 + 1) / 73]17/06/10 05:28:43 ERROR TaskSchedulerImpl: Lost executor 34 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:28:43 WARN TaskSetManager: Lost task 22.0 in stage 147.0 (TID 10738, 128.110.152.141): ExecutorLostFailure (executor 34 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 28.056121394 seconds
res149: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=39 AND partitionZIndex<=40", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=39 AND partitionZIndex<=40,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050892962 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 148:================================================>      (63 + 9) / 72][Stage 148:=====================================================> (70 + 2) / 72]17/06/10 05:29:00 ERROR TaskSchedulerImpl: Lost executor 20 on 128.110.152.165: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:29:00 WARN TaskSetManager: Lost task 0.0 in stage 148.0 (TID 10790, 128.110.152.165): ExecutorLostFailure (executor 20 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:29:06 ERROR TaskSchedulerImpl: Lost executor 35 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:29:06 WARN TaskSetManager: Lost task 0.1 in stage 148.0 (TID 10862, 128.110.152.141): ExecutorLostFailure (executor 35 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:29:06 WARN TaskSetManager: Lost task 12.0 in stage 148.0 (TID 10802, 128.110.152.141): ExecutorLostFailure (executor 35 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 148:======================================================>(71 + 1) / 72]                                                                                [Stage 149:================================================>      (64 + 9) / 73][Stage 149:=====================================================> (71 + 2) / 73][Stage 149:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 37.648294296 seconds
res151: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=78 AND partitionZIndex<=79", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=78 AND partitionZIndex<=79,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052640341 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 150:====================================================>  (69 + 3) / 72]17/06/10 05:29:34 ERROR TaskSchedulerImpl: Lost executor 31 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:29:34 WARN TaskSetManager: Lost task 9.0 in stage 150.0 (TID 10947, 128.110.152.145): ExecutorLostFailure (executor 31 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:29:34 WARN TaskSetManager: Lost task 0.0 in stage 150.0 (TID 10938, 128.110.152.145): ExecutorLostFailure (executor 31 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:29:34 ERROR TaskSchedulerImpl: Lost executor 37 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:29:34 WARN TaskSetManager: Lost task 9.1 in stage 150.0 (TID 11011, 128.110.152.141): ExecutorLostFailure (executor 37 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 150:=====================================================> (70 + 2) / 72][Stage 150:======================================================>(71 + 1) / 72]                                                                                [Stage 151:=========================================>            (56 + 17) / 73][Stage 151:====================================================>  (70 + 3) / 73][Stage 151:=====================================================> (71 + 2) / 73]17/06/10 05:29:53 ERROR TaskSchedulerImpl: Lost executor 39 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:29:53 WARN TaskSetManager: Lost task 9.0 in stage 151.0 (TID 11022, 128.110.152.141): ExecutorLostFailure (executor 39 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:29:53 WARN TaskSetManager: Lost task 0.0 in stage 151.0 (TID 11013, 128.110.152.141): ExecutorLostFailure (executor 39 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 151:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 27.091671887 seconds
res153: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=93 AND partitionZIndex<=94", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=93 AND partitionZIndex<=94,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050917205 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 152:================================================>      (64 + 8) / 72][Stage 152:=====================================================> (70 + 2) / 72]                                                                                Time elapsed: 5.741083012 seconds
res155: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=204 AND partitionZIndex<=205", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=204 AND partitionZIndex<=205,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04816797 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.729328143 seconds
res157: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=211 AND partitionZIndex<=212", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=211 AND partitionZIndex<=212,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05365934 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 156:====================================================>  (69 + 3) / 72][Stage 156:=====================================================> (70 + 2) / 72][Stage 156:======================================================>(71 + 1) / 72]                                                                                [Stage 157:====================================================>  (70 + 3) / 73][Stage 157:=====================================================> (71 + 2) / 73][Stage 157:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 16.785855061 seconds
res159: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=164 AND partitionZIndex<=165", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=164 AND partitionZIndex<=165,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.047000673 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 158:====================================================>  (69 + 3) / 72][Stage 158:=====================================================> (70 + 2) / 72][Stage 158:======================================================>(71 + 1) / 72]                                                                                [Stage 159:====================================================>  (70 + 3) / 73][Stage 159:=====================================================> (71 + 2) / 73][Stage 159:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 14.034643897 seconds
res161: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=61 AND partitionZIndex<=62", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=61 AND partitionZIndex<=62,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.050566086 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 160:====================================================>  (70 + 3) / 73][Stage 160:=====================================================> (71 + 2) / 73][Stage 160:======================================================>(72 + 1) / 73]17/06/10 05:30:55 ERROR TaskSchedulerImpl: Lost executor 24 on 128.110.152.144: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:30:55 WARN TaskSetManager: Lost task 27.0 in stage 160.0 (TID 11695, 128.110.152.144): ExecutorLostFailure (executor 24 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:31:03 ERROR TaskSchedulerImpl: Lost executor 38 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:31:03 WARN TaskSetManager: Lost task 27.1 in stage 160.0 (TID 11741, 128.110.152.145): ExecutorLostFailure (executor 38 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 161:========================================>             (56 + 18) / 74][Stage 161:=========================================>            (57 + 17) / 74][Stage 161:=====================================================> (72 + 2) / 74][Stage 161:======================================================>(73 + 1) / 74]                                                                                Time elapsed: 34.964249204 seconds
res163: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=5.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=5.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=237 AND partitionZIndex<=238", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=237 AND partitionZIndex<=238,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045186036 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 162:>                                                       (0 + 0) / 73][Stage 162:=====================================================> (71 + 2) / 73]                                                                                [Stage 163:=====================================================> (72 + 2) / 74][Stage 163:======================================================>(73 + 1) / 74]                                                                                Time elapsed: 12.061236659 seconds
res165: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=3.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=3.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=25 AND partitionZIndex<=26", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=25 AND partitionZIndex<=26,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04913831 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 164:=====================================================> (70 + 2) / 72][Stage 164:======================================================>(71 + 1) / 72]                                                                                [Stage 165:=====================================================> (71 + 2) / 73][Stage 165:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 14.546009768 seconds
res167: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=9.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=9.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=171 AND partitionZIndex<=172", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=171 AND partitionZIndex<=172,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.052186405 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.611948878 seconds
res169: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=144 AND partitionZIndex<=145", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=144 AND partitionZIndex<=145,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.042993102 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.562052231 seconds
res171: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=133 AND partitionZIndex<=134", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=133 AND partitionZIndex<=134,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053621702 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.634847157 seconds
res173: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=49 AND partitionZIndex<=50", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=49 AND partitionZIndex<=50,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.045534096 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 172:====================================================>  (69 + 3) / 72][Stage 172:=====================================================> (70 + 2) / 72][Stage 172:======================================================>(71 + 1) / 72]                                                                                [Stage 173:====================================================>  (70 + 3) / 73]17/06/10 05:32:17 ERROR TaskSchedulerImpl: Lost executor 40 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:32:17 WARN TaskSetManager: Lost task 9.0 in stage 173.0 (TID 12625, 128.110.152.141): ExecutorLostFailure (executor 40 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:32:17 WARN TaskSetManager: Lost task 0.0 in stage 173.0 (TID 12616, 128.110.152.141): ExecutorLostFailure (executor 40 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 173:=====================================================> (71 + 2) / 73][Stage 173:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 22.964843629 seconds
res175: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=188 AND partitionZIndex<=189", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=188 AND partitionZIndex<=189,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.046686795 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 174:=============================================>        (61 + 11) / 72][Stage 174:====================================================>  (69 + 3) / 72][Stage 174:=====================================================> (70 + 2) / 72][Stage 174:======================================================>(71 + 1) / 72]17/06/10 05:32:35 ERROR TaskSchedulerImpl: Lost executor 32 on 128.110.152.168: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:32:35 WARN TaskSetManager: Lost task 41.0 in stage 174.0 (TID 12732, 128.110.152.168): ExecutorLostFailure (executor 32 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 175:==============================================>       (63 + 10) / 73][Stage 175:====================================================>  (70 + 3) / 73][Stage 175:=====================================================> (71 + 2) / 73]17/06/10 05:32:50 ERROR TaskSchedulerImpl: Lost executor 42 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:32:50 WARN TaskSetManager: Lost task 27.0 in stage 175.0 (TID 12791, 128.110.152.145): ExecutorLostFailure (executor 42 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 175:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 29.626775892 seconds
res177: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=250 AND partitionZIndex<=251", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=250 AND partitionZIndex<=251,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.04960473 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 176:================================================>      (64 + 8) / 72]                                                                                Time elapsed: 5.732465094 seconds
res179: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=10.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=10.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=7 AND partitionZIndex<=8", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=7 AND partitionZIndex<=8,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.044705999 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 178:=====================================================> (70 + 2) / 72][Stage 178:======================================================>(71 + 1) / 72]                                                                                [Stage 179:=====================================================> (71 + 2) / 73][Stage 179:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 11.417829066 seconds
res181: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=245 AND partitionZIndex<=246", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=245 AND partitionZIndex<=246,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.048871691 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 180:======================================================>(71 + 1) / 72]                                                                                [Stage 181:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 11.299384719 seconds
res183: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=28 AND partitionZIndex<=29", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=28 AND partitionZIndex<=29,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.063492405 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 182:=====================================================> (70 + 2) / 72][Stage 182:======================================================>(71 + 1) / 72]                                                                                [Stage 183:=====================================================> (71 + 2) / 73][Stage 183:======================================================>(72 + 1) / 73]                                                                                Time elapsed: 11.262336106 seconds
res185: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=197 AND partitionZIndex<=198", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=197 AND partitionZIndex<=198,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.059424993 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 184:====================================================>  (69 + 3) / 72][Stage 184:=====================================================> (70 + 2) / 72][Stage 184:======================================================>(71 + 1) / 72]                                                                                [Stage 185:====================================================>  (70 + 3) / 73][Stage 185:=====================================================> (71 + 2) / 73][Stage 185:======================================================>(72 + 1) / 73]17/06/10 05:34:06 ERROR TaskSchedulerImpl: Lost executor 41 on 128.110.152.144: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:34:06 WARN TaskSetManager: Lost task 39.0 in stage 185.0 (TID 13529, 128.110.152.144): ExecutorLostFailure (executor 41 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:34:06 ERROR TaskSchedulerImpl: Lost executor 18 on 128.110.152.157: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:34:06 WARN TaskSetManager: Lost task 39.1 in stage 185.0 (TID 13563, 128.110.152.157): ExecutorLostFailure (executor 18 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                Time elapsed: 27.890262797 seconds
res187: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=117 AND partitionZIndex<=118", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=117 AND partitionZIndex<=118,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.053267924 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 186:===============================================>       (55 + 9) / 64][Stage 186:=====================================================> (62 + 2) / 64][Stage 186:======================================================>(63 + 1) / 64]                                                                                [Stage 187:=====================================================> (63 + 2) / 65][Stage 187:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 23.702107323 seconds
res189: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=2.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=2.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=71 AND partitionZIndex<=72", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=71 AND partitionZIndex<=72,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057374398 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
Time elapsed: 0.622801106 seconds
res191: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=1.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=1.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=6 AND partitionZIndex<=7", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=6 AND partitionZIndex<=7,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.040763607 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 190:=====================================================> (62 + 2) / 64]17/06/10 05:34:46 ERROR TaskSchedulerImpl: Lost executor 43 on 128.110.152.141: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:34:46 WARN TaskSetManager: Lost task 0.0 in stage 190.0 (TID 13823, 128.110.152.141): ExecutorLostFailure (executor 43 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:34:46 WARN TaskSetManager: Lost task 56.0 in stage 190.0 (TID 13879, 128.110.152.141): ExecutorLostFailure (executor 43 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 190:======================================================>(63 + 1) / 64]                                                                                [Stage 191:=============================================>        (55 + 10) / 65][Stage 191:===============================================>       (56 + 9) / 65][Stage 191:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.704289338 seconds
res193: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=6.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=6.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=46 AND partitionZIndex<=47", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=46 AND partitionZIndex<=47,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.057052419 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 192:====================================================>  (61 + 3) / 64][Stage 192:=====================================================> (62 + 2) / 64][Stage 192:======================================================>(63 + 1) / 64]17/06/10 05:35:08 ERROR TaskSchedulerImpl: Lost executor 29 on 128.110.152.152: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:35:08 WARN TaskSetManager: Lost task 25.0 in stage 192.0 (TID 13979, 128.110.152.152): ExecutorLostFailure (executor 29 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
                                                                                [Stage 193:====================================================>  (62 + 3) / 65]17/06/10 05:35:17 ERROR TaskSchedulerImpl: Lost executor 45 on 128.110.152.145: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:35:17 WARN TaskSetManager: Lost task 39.0 in stage 193.0 (TID 14058, 128.110.152.145): ExecutorLostFailure (executor 45 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
17/06/10 05:35:17 WARN TaskSetManager: Lost task 25.0 in stage 193.0 (TID 14044, 128.110.152.145): ExecutorLostFailure (executor 45 exited caused by one of the running tasks) Reason: Remote RPC client disassociated. Likely due to containers exceeding thresholds, or network issues. Check driver logs for WARN messages.
[Stage 193:=====================================================> (63 + 2) / 65][Stage 193:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 19.122947403 seconds
res195: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=4.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=4.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=226 AND partitionZIndex<=227", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=226 AND partitionZIndex<=227,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.043479543 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 194:========================================>             (48 + 16) / 64]                                                                                Time elapsed: 5.669237277 seconds
res197: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=8.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=8.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=131 AND partitionZIndex<=132", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=131 AND partitionZIndex<=132,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.044472301 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 196:======================================================>(63 + 1) / 64]                                                                                [Stage 197:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 15.279903272 seconds
res199: Int = 0

scala> 

scala> val dataSource = "/nidan/orc/KUDB.Z10.orc/imageId=7.svs"
dataSource: String = /nidan/orc/KUDB.Z10.orc/imageId=7.svs

scala> val queries = List(("SELECT imageBytes FROM data WHERE partitionZIndex>=10 AND partitionZIndex<=11", 2))
queries: List[(String, Int)] = List((SELECT imageBytes FROM data WHERE partitionZIndex>=10 AND partitionZIndex<=11,2))

scala> 

scala> 

scala> show_timing{sqlContext.read.orc(s"hdfs://ctl:9000$dataSource").createOrReplaceTempView("data")}
Time elapsed: 0.05056655 seconds

scala> show_timing{sqlContext.sql(queries(0)._1).map(_.getAs[Array[Byte]](0)).rdd.zipWithIndex.map{case (bytes, ind ex) => (bytes, index, s"o6_${index}.JPEG")}.collect.map(writeToLocal).filter(_ => false).size}
[Stage 198:=====================================================> (62 + 2) / 64][Stage 198:======================================================>(63 + 1) / 64]                                                                                [Stage 199:=====================================================> (63 + 2) / 65][Stage 199:======================================================>(64 + 1) / 65]                                                                                Time elapsed: 11.353352467 seconds
res201: Int = 0

scala> 

scala> :quit
